#!/usr/bin/env node

/**
 * Authentication Flow Test Script
 * Tests the complete authentication flow: Registration → Email Verification → Login → OTP → Dashboard
 */

const axios = require('axios');
const colors = require('colors');

// Configuration
const BASE_URL = 'http://localhost:5000';
const FRONTEND_URL = 'http://localhost:3000';
const TEST_USER = {
  firstName: 'Test',
  lastName: 'User',
  email: 'testuser@example.com',
  password: 'TestPassword123!',
  phoneNumber: '+1234567890'
};

// Track test state
let testResults = {
  registration: false,
  emailVerification: false,
  login: false,
  otpVerification: false,
  dashboard: false
};

let userTokens = {};
let verificationToken = '';
let otpCode = '';
let userId = '';

/**
 * Utility functions
 */
const log = {
  info: (msg) => console.log('ℹ️ '.blue + msg),
  success: (msg) => console.log('✅'.green + ' ' + msg.green),
  error: (msg) => console.log('❌'.red + ' ' + msg.red),
  warn: (msg) => console.log('⚠️ '.yellow + ' ' + msg.yellow),
  step: (msg) => console.log('\n🔄'.cyan + ' ' + msg.cyan.bold)
};

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * API Helper functions
 */
async function apiRequest(method, endpoint, data = null, headers = {}) {
  try {
    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data || error.message,
      status: error.response?.status
    };
  }
}

/**
 * Test Functions
 */

// 1. Test User Registration
async function testRegistration() {
  log.step('Testing User Registration');
  
  const result = await apiRequest('POST', '/api/auth/register', TEST_USER);
  
  if (result.success && result.data.success) {
    log.success('Registration successful');
    log.info(`User registered: ${TEST_USER.email}`);
    testResults.registration = true;
    
    // Check if verification token is in response (for testing)
    if (result.data.verificationToken) {
      verificationToken = result.data.verificationToken;
      log.info(`Verification token: ${verificationToken}`);
    }
    
    return true;
  } else {
    log.error(`Registration failed: ${result.error?.message || result.error}`);
    return false;
  }
}

// 2. Test Email Verification
async function testEmailVerification() {
  log.step('Testing Email Verification');
  
  if (!verificationToken) {
    log.warn('No verification token available. Checking database or email logs...');
    // In real scenario, user would get token from email
    log.info('In production, user would click link in verification email');
    // For testing, we'll simulate finding the token
    verificationToken = 'simulated-token'; // This would need to be extracted from logs/database
  }
  
  const result = await apiRequest('GET', `/api/auth/verify-email/${verificationToken}`);
  
  if (result.success && result.data.success) {
    log.success('Email verification successful');
    testResults.emailVerification = true;
    return true;
  } else {
    log.error(`Email verification failed: ${result.error?.message || result.error}`);
    // Try to continue with manual verification for testing
    log.warn('Attempting manual verification for testing...');
    return false;
  }
}

// 3. Test Login (should trigger OTP)
async function testLogin() {
  log.step('Testing Login Flow');
  
  const result = await apiRequest('POST', '/api/auth/login', {
    email: TEST_USER.email,
    password: TEST_USER.password
  });
  
  if (result.success && result.data.success) {
    if (result.data.data?.requiresOTP) {
      log.success('Login initiated - OTP required');
      userId = result.data.data.userId;
      log.info(`User ID: ${userId}`);
      testResults.login = true;
      return true;
    } else {
      log.success('Direct login successful (OTP not required)');
      userTokens = result.data.data.tokens;
      testResults.login = true;
      testResults.otpVerification = true; // Skip OTP if not required
      return true;
    }
  } else {
    log.error(`Login failed: ${result.error?.message || result.error}`);
    if (result.error?.requiresEmailVerification) {
      log.warn('Email verification required first');
    }
    return false;
  }
}

// 4. Test OTP Verification
async function testOTPVerification() {
  log.step('Testing OTP Verification');
  
  if (!userId) {
    log.error('No user ID available for OTP verification');
    return false;
  }
  
  // In real scenario, OTP would be from email
  // For testing, we'll simulate OTP entry
  log.warn('In production, user would enter OTP from email');
  otpCode = '123456'; // This would be the actual OTP from email
  
  const result = await apiRequest('POST', '/api/auth/verify-login-otp', {
    userId,
    otp: otpCode
  });
  
  if (result.success && result.data.success) {
    log.success('OTP verification successful');
    userTokens = result.data.data.tokens;
    testResults.otpVerification = true;
    return true;
  } else {
    log.error(`OTP verification failed: ${result.error?.message || result.error}`);
    return false;
  }
}

// 5. Test Dashboard Access
async function testDashboardAccess() {
  log.step('Testing Dashboard Access');
  
  if (!userTokens?.accessToken) {
    log.error('No access token available for dashboard test');
    return false;
  }
  
  const result = await apiRequest('GET', '/api/auth/me', null, {
    'Authorization': `Bearer ${userTokens.accessToken}`
  });
  
  if (result.success && result.data.success) {
    log.success('Dashboard access successful');
    log.info(`Authenticated user: ${result.data.data.user.email}`);
    testResults.dashboard = true;
    return true;
  } else {
    log.error(`Dashboard access failed: ${result.error?.message || result.error}`);
    return false;
  }
}

// Cleanup function
async function cleanup() {
  log.step('Cleaning up test data');
  
  // In production, you might want to delete test users
  // For now, we'll just log the cleanup
  log.info('Test user can be manually removed from database if needed');
  log.info(`Email: ${TEST_USER.email}`);
}

/**
 * Main Test Runner
 */
async function runTests() {
  console.log('\n🚀 Auth System Complete Flow Test'.rainbow.bold);
  console.log('='.repeat(50).gray);
  
  log.info(`Testing against: ${BASE_URL}`);
  log.info(`Frontend URL: ${FRONTEND_URL}`);
  log.info(`Test user email: ${TEST_USER.email}`);
  
  try {
    // Test server connectivity
    log.step('Checking server connectivity');
    const healthCheck = await apiRequest('GET', '/health');
    if (!healthCheck.success) {
      log.error('Server is not running or not accessible');
      log.error('Please start the backend server: npm run dev');
      process.exit(1);
    }
    log.success('Server is running');
    
    // Run sequential tests
    const tests = [
      { name: 'Registration', func: testRegistration },
      { name: 'Email Verification', func: testEmailVerification },
      { name: 'Login', func: testLogin },
      { name: 'OTP Verification', func: testOTPVerification },
      { name: 'Dashboard Access', func: testDashboardAccess }
    ];
    
    for (const test of tests) {
      const success = await test.func();
      await wait(1000); // Wait between tests
      
      if (!success && test.name !== 'Email Verification') {
        log.error(`Test failed: ${test.name}`);
        break;
      }
    }
    
    // Print results
    console.log('\n📊 Test Results'.bold);
    console.log('='.repeat(30));
    
    Object.entries(testResults).forEach(([test, passed]) => {
      const icon = passed ? '✅' : '❌';
      const status = passed ? 'PASSED'.green : 'FAILED'.red;
      console.log(`${icon} ${test.padEnd(20)} ${status}`);
    });
    
    const passedCount = Object.values(testResults).filter(Boolean).length;
    const totalCount = Object.keys(testResults).length;
    
    console.log(`\n📈 Overall: ${passedCount}/${totalCount} tests passed`);
    
    if (passedCount === totalCount) {
      log.success('🎉 All tests passed! Authentication system is working correctly.');
    } else {
      log.warn(`${totalCount - passedCount} tests failed. Please check the logs above.`);
    }
    
  } catch (error) {
    log.error(`Test runner error: ${error.message}`);
  } finally {
    await cleanup();
  }
}

/**
 * Manual Test Instructions
 */
function printManualTestInstructions() {
  console.log('\n📋 Manual Testing Instructions'.bold.blue);
  console.log('='.repeat(40));
  
  console.log('\n1. 🔄 Registration Flow:');
  console.log('   • Open: http://localhost:3000/signup');
  console.log('   • Fill form with test data');
  console.log('   • Submit and verify redirect to email verification');
  
  console.log('\n2. 📧 Email Verification:');
  console.log('   • Check backend console for Ethereal preview URLs');
  console.log('   • Click verification link in email preview');
  console.log('   • Verify redirect to login page');
  
  console.log('\n3. 🔐 Login & OTP:');
  console.log('   • Use registered credentials to login');
  console.log('   • Check email for OTP code');
  console.log('   • Enter OTP in verification form');
  
  console.log('\n4. 🏠 Dashboard Access:');
  console.log('   • Verify successful login to dashboard');
  console.log('   • Check user profile information');
  
  console.log('\n💡 Tips:');
  console.log('   • Check browser console for any errors');
  console.log('   • Monitor backend logs for email URLs');
  console.log('   • Verify database for user records');
}

// Run tests if called directly
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.includes('--manual') || args.includes('-m')) {
    printManualTestInstructions();
  } else {
    runTests().catch(console.error);
  }
}

module.exports = {
  runTests,
  printManualTestInstructions,
  testResults
};