import request from 'supertest';
import app from '../../src/index';
import { User } from '../../src/models/User';
import { OTP } from '../../src/models/OTP';

describe('Authentication E2E Tests', () => {
  describe('POST /api/auth/register', () => {
    it('should register a new user successfully', async () => {
      const userData = {
        firstName: 'John',
        lastName: 'Doe',
        email: 'john.doe@example.com',
        password: 'SecurePassword123!'
      };

      const response = await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.email).toBe(userData.email);
      expect(response.body.data.tokens).toBeDefined();
      expect(response.body.data.tokens.accessToken).toBeDefined();
      expect(response.body.data.tokens.refreshToken).toBeDefined();

      // Verify user was created in database
      const user = await User.findOne({ email: userData.email });
      expect(user).toBeTruthy();
      expect(user?.firstName).toBe(userData.firstName);
      expect(user?.isEmailVerified).toBe(false);
    });

    it('should not register user with duplicate email', async () => {
      const userData = {
        firstName: 'Jane',
        lastName: 'Doe',
        email: 'duplicate@example.com',
        password: 'SecurePassword123!'
      };

      // Create first user
      await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(201);

      // Try to create duplicate
      const response = await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('already exists');
    });

    it('should validate password requirements', async () => {
      const userData = {
        firstName: 'Test',
        lastName: 'User',
        email: 'test@example.com',
        password: 'weak'
      };

      const response = await request(app)
        .post('/api/auth/register')
        .send(userData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Password');
    });
  });

  describe('POST /api/auth/login', () => {
    let testUser: any;

    beforeEach(async () => {
      testUser = await (global as any).testUtils.createTestUser({
        email: 'login.test@example.com',
        password: 'LoginPassword123!'
      });
    });

    it('should login with valid credentials', async () => {
      const loginData = {
        email: 'login.test@example.com',
        password: 'LoginPassword123!'
      };

      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.email).toBe(loginData.email);
      expect(response.body.data.tokens.accessToken).toBeDefined();
      expect(response.body.data.tokens.refreshToken).toBeDefined();
    });

    it('should not login with invalid password', async () => {
      const loginData = {
        email: 'login.test@example.com',
        password: 'WrongPassword123!'
      };

      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Invalid');
    });

    it('should handle account lockout after failed attempts', async () => {
      const loginData = {
        email: 'login.test@example.com',
        password: 'WrongPassword123!'
      };

      // Make 5 failed attempts
      for (let i = 0; i < 5; i++) {
        await request(app)
          .post('/api/auth/login')
          .send(loginData)
          .expect(401);
      }

      // 6th attempt should result in account lock
      const response = await request(app)
        .post('/api/auth/login')
        .send(loginData)
        .expect(423);

      expect(response.body.message).toContain('locked');
    });

    it('should rate limit login attempts', async () => {
      const promises = [];
      
      // Make multiple rapid requests
      for (let i = 0; i < 10; i++) {
        promises.push(
          request(app)
            .post('/api/auth/login')
            .send({
              email: 'test@example.com',
              password: 'password'
            })
        );
      }

      const responses = await Promise.all(promises);
      const rateLimitedResponses = responses.filter(res => res.status === 429);
      
      expect(rateLimitedResponses.length).toBeGreaterThan(0);
    });
  });

  describe('OTP Verification Flow', () => {
    let testUser: any;

    beforeEach(async () => {
      testUser = await (global as any).testUtils.createTestUser({
        email: 'otp.test@example.com',
        isEmailVerified: false
      });
    });

    it('should send OTP for email verification', async () => {
      const response = await request(app)
        .post('/api/auth/send-otp')
        .send({
          email: 'otp.test@example.com',
          type: 'email_verification'
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('sent');

      // Verify OTP was created in database
      const otp = await OTP.findOne({
        email: 'otp.test@example.com',
        type: 'email_verification',
        isUsed: false
      });
      expect(otp).toBeTruthy();
      expect(otp?.code).toHaveLength(6);
    });

    it('should verify valid OTP', async () => {
      // First send OTP
      await request(app)
        .post('/api/auth/send-otp')
        .send({
          email: 'otp.test@example.com',
          type: 'email_verification'
        });

      // Get the OTP from database
      const otpRecord = await OTP.findOne({
        email: 'otp.test@example.com',
        type: 'email_verification',
        isUsed: false
      });

      const response = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          email: 'otp.test@example.com',
          code: otpRecord?.code,
          type: 'email_verification'
        })
        .expect(200);

      expect(response.body.success).toBe(true);

      // Verify user is now email verified
      const updatedUser = await User.findById(testUser._id);
      expect(updatedUser?.isEmailVerified).toBe(true);

      // Verify OTP is marked as used
      const usedOtp = await OTP.findById(otpRecord?._id);
      expect(usedOtp?.isUsed).toBe(true);
    });

    it('should not verify invalid OTP', async () => {
      const response = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          email: 'otp.test@example.com',
          code: '123456',
          type: 'email_verification'
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Invalid');
    });
  });

  describe('JWT Token Management', () => {
    let testUser: any;
    let accessToken: string;
    let refreshToken: string;

    beforeEach(async () => {
      testUser = await (global as any).testUtils.createTestUser();
      
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: 'TestPassword123!'
        });

      accessToken = loginResponse.body.data.tokens.accessToken;
      refreshToken = loginResponse.body.data.tokens.refreshToken;
    });

    it('should access protected route with valid token', async () => {
      const response = await request(app)
        .get('/api/user/profile')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.email).toBe(testUser.email);
    });

    it('should not access protected route without token', async () => {
      const response = await request(app)
        .get('/api/user/profile')
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toBe('AUTHENTICATION_REQUIRED');
    });

    it('should refresh access token with valid refresh token', async () => {
      const response = await request(app)
        .post('/api/auth/refresh')
        .send({ refreshToken })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.tokens.accessToken).toBeDefined();
      expect(response.body.data.tokens.refreshToken).toBeDefined();
      expect(response.body.data.tokens.accessToken).not.toBe(accessToken);
    });

    it('should logout and invalidate tokens', async () => {
      // Logout
      await request(app)
        .post('/api/auth/logout')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ refreshToken })
        .expect(200);

      // Try to use the same refresh token
      const refreshResponse = await request(app)
        .post('/api/auth/refresh')
        .send({ refreshToken })
        .expect(401);

      expect(refreshResponse.body.success).toBe(false);
    });
  });

  describe('Password Reset Flow', () => {
    let testUser: any;

    beforeEach(async () => {
      testUser = await (global as any).testUtils.createTestUser({
        email: 'reset.test@example.com'
      });
    });

    it('should initiate password reset', async () => {
      const response = await request(app)
        .post('/api/auth/forgot-password')
        .send({ email: 'reset.test@example.com' })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('sent');

      // Verify reset token was created
      const updatedUser = await User.findById(testUser._id);
      expect(updatedUser?.passwordResetToken).toBeDefined();
      expect(updatedUser?.passwordResetExpires).toBeDefined();
    });

    it('should reset password with valid token', async () => {
      // Initiate reset
      await request(app)
        .post('/api/auth/forgot-password')
        .send({ email: 'reset.test@example.com' });

      const userWithToken = await User.findById(testUser._id);
      const resetToken = userWithToken?.passwordResetToken;

      // Reset password
      const newPassword = 'NewSecurePassword123!';
      const response = await request(app)
        .post('/api/auth/reset-password')
        .send({
          token: resetToken,
          password: newPassword
        })
        .expect(200);

      expect(response.body.success).toBe(true);

      // Verify can login with new password
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'reset.test@example.com',
          password: newPassword
        })
        .expect(200);

      expect(loginResponse.body.success).toBe(true);
    });
  });

  describe('Security Headers and CORS', () => {
    it('should include security headers', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.headers['x-content-type-options']).toBe('nosniff');
      expect(response.headers['x-frame-options']).toBeDefined();
      expect(response.headers['x-xss-protection']).toBeDefined();
    });

    it('should handle CORS properly', async () => {
      const response = await request(app)
        .options('/api/auth/login')
        .set('Origin', 'http://localhost:3000')
        .expect(204);

      expect(response.headers['access-control-allow-origin']).toBeDefined();
      expect(response.headers['access-control-allow-methods']).toBeDefined();
    });
  });
});