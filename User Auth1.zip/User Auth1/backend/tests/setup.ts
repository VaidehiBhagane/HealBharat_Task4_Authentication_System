import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';
import { configDotenv } from 'dotenv';

let mongoServer: MongoMemoryServer;

// Setup test environment
configDotenv({ path: '.env.test' });

beforeAll(async () => {
  // Start in-memory MongoDB for testing
  mongoServer = await MongoMemoryServer.create();
  const mongoUri = mongoServer.getUri();
  
  await mongoose.connect(mongoUri);
});

afterAll(async () => {
  // Cleanup
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  // Clean up data after each test
  const collections = mongoose.connection.collections;
  for (const key in collections) {
    await collections[key].deleteMany({});
  }
});

// Global test utilities
global.testUtils = {
  createTestUser: async (userData = {}) => {
    const { User } = await import('../src/models/User');
    const defaultUser = {
      firstName: 'Test',
      lastName: 'User',
      email: 'test@example.com',
      password: 'TestPassword123!',
      isEmailVerified: true,
      role: 'user'
    };
    
    return User.create({ ...defaultUser, ...userData });
  },
  
  generateAuthToken: async (user: any) => {
    const { tokenService } = await import('../src/utils/tokenService');
    return tokenService.generateAccessToken(user);
  }
};