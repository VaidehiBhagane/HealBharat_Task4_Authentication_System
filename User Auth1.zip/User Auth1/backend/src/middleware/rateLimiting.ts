import rateLimit from 'express-rate-limit';
import { Request, Response } from 'express';

// Admin-specific rate limiting
export const rateLimitAdmin = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each admin to 100 requests per windowMs
  message: {
    success: false,
    error: 'Too many admin requests from this IP, please try again later',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  // Skip rate limiting for successful requests to read-only endpoints
  skip: (req: Request) => {
    const readOnlyMethods = ['GET'];
    const readOnlyPaths = ['/stats', '/users', '/audit-logs'];
    return readOnlyMethods.includes(req.method) && 
           readOnlyPaths.some(path => req.path.includes(path));
  },
  // Custom key generator based on admin user ID
  keyGenerator: (req: Request) => {
    return req.user ? `admin_${req.user._id}` : req.ip || 'unknown';
  },
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: 'Too many admin requests from this account',
      message: 'You have exceeded the admin rate limit. Please try again later.',
      retryAfter: Math.ceil(15 * 60), // seconds
      timestamp: new Date().toISOString()
    });
  }
});

// More restrictive rate limiting for sensitive admin operations
export const rateLimitAdminSensitive = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // Limit each admin to 20 sensitive operations per hour
  message: {
    success: false,
    error: 'Too many sensitive admin operations from this account',
    retryAfter: '1 hour'
  },
  keyGenerator: (req: Request) => {
    return req.user ? `admin_sensitive_${req.user._id}` : req.ip || 'unknown';
  },
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: 'Sensitive operation rate limit exceeded',
      message: 'You have exceeded the limit for sensitive admin operations. Please try again later.',
      retryAfter: Math.ceil(60 * 60), // seconds
      timestamp: new Date().toISOString()
    });
  }
});

// Export user data rate limiting (very restrictive)
export const rateLimitExport = rateLimit({
  windowMs: 24 * 60 * 60 * 1000, // 24 hours
  max: 5, // Limit each admin to 5 export operations per day
  message: {
    success: false,
    error: 'Daily export limit exceeded',
    retryAfter: '24 hours'
  },
  keyGenerator: (req: Request) => {
    return req.user ? `admin_export_${req.user._id}` : req.ip || 'unknown';
  },
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: 'Daily export limit exceeded',
      message: 'You have reached the maximum number of data exports allowed per day.',
      retryAfter: Math.ceil(24 * 60 * 60), // seconds
      timestamp: new Date().toISOString()
    });
  }
});