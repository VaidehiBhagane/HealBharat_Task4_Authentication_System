import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { CustomError } from './errorHandler';

// CSRF Token Store (in production, use Redis or database)
const csrfTokens = new Map<string, { token: string, expires: number }>();

/**
 * Generate CSRF token
 */
export const generateCSRFToken = (): string => {
  return crypto.randomBytes(32).toString('hex');
};

/**
 * CSRF Protection Middleware
 */
export const csrfProtection = (req: Request, res: Response, next: NextFunction) => {
  // Skip CSRF for GET, HEAD, OPTIONS requests
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }

  const token = req.headers['x-csrf-token'] || req.body._csrf;
  const sessionId = (req.headers['authorization'] || req.ip || 'unknown') as string;

  if (!token) {
    throw new CustomError('CSRF token missing', 403);
  }

  const storedToken = csrfTokens.get(sessionId);
  
  if (!storedToken || storedToken.token !== token) {
    throw new CustomError('Invalid CSRF token', 403);
  }

  // Check if token has expired (1 hour)
  if (Date.now() > storedToken.expires) {
    csrfTokens.delete(sessionId);
    throw new CustomError('CSRF token expired', 403);
  }

  // Regenerate token after use for security
  const newToken = generateCSRFToken();
  csrfTokens.set(sessionId, {
    token: newToken,
    expires: Date.now() + (60 * 60 * 1000) // 1 hour
  });

  // Send new token in response header
  res.setHeader('X-CSRF-Token', newToken);
  
  next();
};

/**
 * Endpoint to get CSRF token
 */
export const getCSRFToken = (req: Request, res: Response) => {
  const sessionId = (req.headers['authorization'] || req.ip || 'unknown') as string;
  const token = generateCSRFToken();
  
  csrfTokens.set(sessionId, {
    token,
    expires: Date.now() + (60 * 60 * 1000) // 1 hour
  });

  res.json({
    success: true,
    csrfToken: token
  });
};

/**
 * XSS Protection Headers
 */
export const xssProtection = (req: Request, res: Response, next: NextFunction) => {
  // Set XSS protection headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Content Security Policy
  res.setHeader('Content-Security-Policy', 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline'; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; " +
    "img-src 'self' data: https:; " +
    "connect-src 'self';"
  );
  
  next();
};

/**
 * Input Sanitization Middleware
 */
export const sanitizeInput = (req: Request, res: Response, next: NextFunction) => {
  // Sanitize string inputs
  const sanitizeString = (str: string): string => {
    if (typeof str !== 'string') return str;
    
    return str
      .replace(/[<>]/g, '') // Remove < and >
      .replace(/javascript:/gi, '') // Remove javascript: protocol
      .replace(/on\w+=/gi, '') // Remove event handlers
      .trim();
  };

  // Recursively sanitize object properties
  const sanitizeObject = (obj: any): any => {
    if (typeof obj === 'string') {
      return sanitizeString(obj);
    }
    
    if (Array.isArray(obj)) {
      return obj.map(sanitizeObject);
    }
    
    if (typeof obj === 'object' && obj !== null) {
      const sanitized: any = {};
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          sanitized[key] = sanitizeObject(obj[key]);
        }
      }
      return sanitized;
    }
    
    return obj;
  };

  // Sanitize request body, query, and params
  if (req.body) {
    req.body = sanitizeObject(req.body);
  }
  
  if (req.query) {
    req.query = sanitizeObject(req.query);
  }
  
  if (req.params) {
    req.params = sanitizeObject(req.params);
  }

  next();
};

/**
 * Secure Headers Middleware
 */
export const secureHeaders = (req: Request, res: Response, next: NextFunction) => {
  // Remove server information
  res.removeHeader('X-Powered-By');
  
  // Set security headers
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  res.setHeader('X-Download-Options', 'noopen');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  
  next();
};

/**
 * Admin Session Validation
 */
export const validateAdminSession = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Check if user exists and is active
    if (!req.user) {
      throw new CustomError('Authentication required', 401);
    }

    // Verify user is still active (not deactivated by another admin)
    const { User } = require('../models/User');
    const currentUser = await User.findById(req.user._id);
    
    if (!currentUser || !currentUser.isActive) {
      throw new CustomError('Account has been deactivated', 403);
    }

    // Verify admin role (double-check)
    if (currentUser.role !== 'admin') {
      throw new CustomError('Admin access required', 403);
    }

    // Update request with current user data
    req.user = currentUser;
    
    next();
  } catch (error) {
    next(error);
  }
};

/**
 * IP Whitelist Middleware (optional - for high-security environments)
 */
export const ipWhitelist = (allowedIPs: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const clientIP = req.ip || req.connection.remoteAddress || '';
    
    if (allowedIPs.length > 0 && !allowedIPs.includes(clientIP)) {
      throw new CustomError('Access denied from this IP address', 403);
    }
    
    next();
  };
};