import { Request, Response, NextFunction } from 'express';
import { body, query, param, validationResult } from 'express-validator';
import { CustomError } from './errorHandler';

// Helper function to handle validation errors
const handleValidationErrors = (req: Request, res: Response, next: NextFunction) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map(error => error.msg).join(', ');
    throw new CustomError(`Validation failed: ${errorMessages}`, 400);
  }
  next();
};

export const validateAdminRequest = {
  // Validate get users list request
  getUserList: [
    query('page')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Page must be a positive integer'),
    query('limit')
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage('Limit must be between 1 and 100'),
    query('search')
      .optional()
      .isLength({ max: 100 })
      .withMessage('Search term cannot exceed 100 characters')
      .trim()
      .escape(),
    query('status')
      .optional()
      .isIn(['all', 'active', 'inactive', 'verified', 'unverified'])
      .withMessage('Status must be one of: all, active, inactive, verified, unverified'),
    query('role')
      .optional()
      .isIn(['all', 'user', 'admin'])
      .withMessage('Role must be one of: all, user, admin'),
    query('sortBy')
      .optional()
      .isIn(['createdAt', 'lastLogin', 'firstName', 'lastName', 'email'])
      .withMessage('SortBy must be one of: createdAt, lastLogin, firstName, lastName, email'),
    query('sortOrder')
      .optional()
      .isIn(['asc', 'desc'])
      .withMessage('SortOrder must be asc or desc'),
    handleValidationErrors
  ],

  // Validate get user by ID request
  getUserById: [
    param('id')
      .isMongoId()
      .withMessage('Invalid user ID format'),
    handleValidationErrors
  ],

  // Validate update user status request
  updateUserStatus: [
    param('id')
      .isMongoId()
      .withMessage('Invalid user ID format'),
    body('isActive')
      .isBoolean()
      .withMessage('isActive must be a boolean'),
    body('reason')
      .optional()
      .isLength({ max: 500 })
      .withMessage('Reason cannot exceed 500 characters')
      .trim()
      .escape(),
    handleValidationErrors
  ],

  // Validate reset password request
  resetPassword: [
    param('id')
      .isMongoId()
      .withMessage('Invalid user ID format'),
    body('temporaryPassword')
      .optional()
      .isLength({ min: 8, max: 128 })
      .withMessage('Temporary password must be between 8 and 128 characters'),
    body('forceReset')
      .optional()
      .isBoolean()
      .withMessage('forceReset must be a boolean'),
    handleValidationErrors
  ],

  // Validate get user logs request
  getUserLogs: [
    param('id')
      .isMongoId()
      .withMessage('Invalid user ID format'),
    query('page')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Page must be a positive integer'),
    query('limit')
      .optional()
      .isInt({ min: 1, max: 200 })
      .withMessage('Limit must be between 1 and 200'),
    query('action')
      .optional()
      .isLength({ max: 50 })
      .withMessage('Action filter cannot exceed 50 characters')
      .trim()
      .escape(),
    query('startDate')
      .optional()
      .isISO8601()
      .withMessage('Start date must be a valid ISO 8601 date'),
    query('endDate')
      .optional()
      .isISO8601()
      .withMessage('End date must be a valid ISO 8601 date'),
    handleValidationErrors
  ],

  // Validate export users request
  exportUsers: [
    query('format')
      .optional()
      .isIn(['csv', 'json'])
      .withMessage('Format must be csv or json'),
    query('status')
      .optional()
      .isIn(['all', 'active', 'inactive', 'verified', 'unverified'])
      .withMessage('Status must be one of: all, active, inactive, verified, unverified'),
    query('role')
      .optional()
      .isIn(['all', 'user', 'admin'])
      .withMessage('Role must be one of: all, user, admin'),
    handleValidationErrors
  ],

  // Validate get audit logs request
  getAuditLogs: [
    query('page')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Page must be a positive integer'),
    query('limit')
      .optional()
      .isInt({ min: 1, max: 200 })
      .withMessage('Limit must be between 1 and 200'),
    query('action')
      .optional()
      .isLength({ max: 50 })
      .withMessage('Action filter cannot exceed 50 characters')
      .trim()
      .escape(),
    query('adminId')
      .optional()
      .isMongoId()
      .withMessage('Invalid admin ID format'),
    query('startDate')
      .optional()
      .isISO8601()
      .withMessage('Start date must be a valid ISO 8601 date'),
    query('endDate')
      .optional()
      .isISO8601()
      .withMessage('End date must be a valid ISO 8601 date'),
    handleValidationErrors
  ]
};