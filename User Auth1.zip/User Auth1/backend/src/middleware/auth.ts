import { Request, Response, NextFunction } from 'express';
import { tokenService, JWTPayload } from '../utils/tokenService';
import { User, IUser } from '../models/User';
// import { Session } from '../models/Session';

// Extend Express Request and User types
declare global {
  namespace Express {
    interface User extends IUser {}
    interface Request {
      token?: string;
    }
  }
}

/**
 * Middleware to authenticate requests using JWT
 */
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let token: string | undefined;

    // Check for token in Authorization header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    }

    // Check for token in cookies
    if (!token && req.cookies.accessToken) {
      token = req.cookies.accessToken;
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access token required',
        error: 'AUTHENTICATION_REQUIRED',
      });
    }

    try {
      // Verify the token
      const decoded: JWTPayload = tokenService.verifyAccessToken(token);
      
      // Find the user
      const user = await User.findById(decoded.userId).select('-password -refreshTokens');
      
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'User not found',
          error: 'USER_NOT_FOUND',
        });
      }

      // Check if user account is locked
      if (user.isAccountLocked()) {
        return res.status(423).json({
          success: false,
          message: 'Account is temporarily locked due to multiple failed login attempts',
          error: 'ACCOUNT_LOCKED',
        });
      }

      // Attach user and token to request
      req.user = user;
      req.token = token;
      
      next();
    } catch (tokenError: any) {
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired token',
        error: 'TOKEN_INVALID',
        details: tokenError.message,
      });
    }
  } catch (error: any) {
    console.error('Authentication error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error during authentication',
      error: 'AUTHENTICATION_ERROR',
    });
  }
};

/**
 * Middleware to authorize specific roles
 */
export const authorize = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
        error: 'AUTHENTICATION_REQUIRED',
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
        error: 'AUTHORIZATION_FAILED',
        requiredRoles: roles,
        userRole: req.user.role,
      });
    }

    next();
  };
};

/**
 * Middleware to check if user is admin
 */
export const requireAdmin = authorize(['admin']);

/**
 * Middleware to ensure user is verified
 */
export const requireVerified = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required',
      error: 'AUTHENTICATION_REQUIRED',
    });
  }

  if (!req.user.isEmailVerified) {
    return res.status(403).json({
      success: false,
      message: 'Email verification required',
      error: 'EMAIL_NOT_VERIFIED',
    });
  }

  next();
};

/**
 * Optional authentication - doesn't fail if no token provided
 */
export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let token: string | undefined;

    // Check for token in Authorization header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    }

    // Check for token in cookies
    if (!token && req.cookies.accessToken) {
      token = req.cookies.accessToken;
    }

    if (token) {
      try {
        const decoded: JWTPayload = tokenService.verifyAccessToken(token);
        const user = await User.findById(decoded.userId).select('-password -refreshTokens');
        
        if (user && !user.isAccountLocked()) {
          req.user = user;
          req.token = token;
        }
      } catch (error) {
        // Silently ignore token errors for optional auth
      }
    }

    next();
  } catch (error: any) {
    console.error('Optional authentication error:', error);
    next(); // Continue without authentication
  }
};

/**
 * Middleware to validate refresh token
 */
export const validateRefreshToken = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const refreshToken = req.body.refreshToken || req.cookies.refreshToken;

    if (!refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token required',
        error: 'REFRESH_TOKEN_REQUIRED',
      });
    }

    try {
      // Verify the refresh token
      const decoded = tokenService.verifyRefreshToken(refreshToken);
      
      // TODO: Check if session exists and is active
      // const session = await Session.findActiveSession(refreshToken);
      
      // if (!session) {
      //   return res.status(401).json({
      //     success: false,
      //     message: 'Invalid or expired refresh token',
      //     error: 'INVALID_REFRESH_TOKEN',
      //   });
      // }

      // Find the user
      const user = await User.findById(decoded.userId);
      
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'User not found',
          error: 'USER_NOT_FOUND',
        });
      }

      // TODO: Update session last accessed
      // await session.updateLastAccessed();

      req.user = user;
      // req.session = session;
      req.token = refreshToken;
      
      next();
    } catch (tokenError: any) {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token',
        error: 'INVALID_REFRESH_TOKEN',
        details: tokenError.message,
      });
    }
  } catch (error: any) {
    console.error('Refresh token validation error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error during token validation',
      error: 'TOKEN_VALIDATION_ERROR',
    });
  }
};

/**
 * Middleware to check 2FA requirement
 */
export const require2FA = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required',
      error: 'AUTHENTICATION_REQUIRED',
    });
  }

  // TODO: Check 2FA verification
  // if (req.user.twoFactorEnabled && !req.session?.is2FAVerified) {
  //   return res.status(403).json({
  //     success: false,
  //     message: '2FA verification required',
  //     error: 'TWO_FACTOR_REQUIRED',
  //   });
  // }

  next();
};