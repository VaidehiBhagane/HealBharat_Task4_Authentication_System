import twilio from 'twilio';

interface SMSOptions {
  to: string;
  message: string;
}

class SMSService {
  private client: twilio.Twilio | null = null;
  private fromNumber: string;
  private initialized: boolean = false;

  constructor() {
    this.fromNumber = process.env.TWILIO_PHONE_NUMBER || '+1234567890';
    // Delay initialization to ensure environment variables are loaded
    setTimeout(() => this.initializeTwilio(), 100);
  }

  private initializeTwilio() {
    if (this.initialized) return;
    
    try {
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;

      if (accountSid && authToken && accountSid !== 'mock_account_sid') {
        this.client = twilio(accountSid, authToken);
        this.initialized = true;
        console.log('✅ SMS Service (Twilio) ready');
        console.log(`📱 Using phone number: ${process.env.TWILIO_PHONE_NUMBER}`);
      } else {
        console.log('⚠️  SMS Service disabled - Twilio credentials not provided');
        console.log('   Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER to enable SMS');
      }
    } catch (error) {
      console.error('❌ Failed to initialize SMS service:', error);
    }
  }

  async sendSMS({ to, message }: SMSOptions): Promise<boolean> {
    try {
      // Ensure SMS service is initialized
      if (!this.initialized) {
        this.initializeTwilio();
      }

      if (!this.client) {
        console.warn('⚠️  SMS service not available - returning mock success');
        console.log(`📱 Mock SMS to ${to}: ${message}`);
        // In development/testing, return true to simulate sending
        return process.env.NODE_ENV === 'development';
      }

      // Format phone number (ensure it has country code)
      const formattedNumber = this.formatPhoneNumber(to);
      
      const messageResult = await this.client.messages.create({
        body: message,
        from: this.fromNumber,
        to: formattedNumber,
      });

      console.log('📱 SMS sent:', messageResult.sid);
      return true;
    } catch (error: any) {
      console.error('❌ SMS sending failed:', error.message);
      
      // In development, simulate success even if Twilio fails
      if (process.env.NODE_ENV === 'development') {
        console.log('🔧 Development mode: Simulating SMS success');
        return true;
      }
      
      return false;
    }
  }

  private formatPhoneNumber(phoneNumber: string): string {
    // Remove all non-numeric characters
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // If it doesn't start with +, add default country code (US: +1)
    if (cleaned.length === 10) {
      return `+1${cleaned}`;
    } else if (cleaned.length === 11 && cleaned.startsWith('1')) {
      return `+${cleaned}`;
    } else if (!phoneNumber.startsWith('+')) {
      return `+1${cleaned}`;
    }
    
    return phoneNumber;
  }

  async sendLoginOTP(phoneNumber: string, firstName: string, otp: string): Promise<boolean> {
    const message = `Hi ${firstName}! Your Auth System login code is: ${otp}. This code expires in 10 minutes. Never share this code with anyone.`;
    
    return this.sendSMS({
      to: phoneNumber,
      message,
    });
  }

  async sendRegistrationOTP(phoneNumber: string, firstName: string, otp: string): Promise<boolean> {
    const message = `Welcome ${firstName}! Your Auth System verification code is: ${otp}. Enter this code to complete your registration. Expires in 10 minutes.`;
    
    return this.sendSMS({
      to: phoneNumber,
      message,
    });
  }

  async sendSecurityAlert(phoneNumber: string, firstName: string, action: string): Promise<boolean> {
    const message = `Security Alert: ${firstName}, a ${action} was performed on your Auth System account. If this wasn't you, please contact support immediately.`;
    
    return this.sendSMS({
      to: phoneNumber,
      message,
    });
  }

  async sendPasswordResetOTP(phoneNumber: string, firstName: string, otp: string): Promise<boolean> {
    const message = `${firstName}, your Auth System password reset code is: ${otp}. This code expires in 10 minutes. Never share this code with anyone. If you didn't request this, contact support.`;
    
    return this.sendSMS({
      to: phoneNumber,
      message,
    });
  }

  isAvailable(): boolean {
    return this.client !== null;
  }
}

export const smsService = new SMSService();