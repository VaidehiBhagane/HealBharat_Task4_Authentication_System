import nodemailer from 'nodemailer';

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

class EmailService {
  private transporter!: nodemailer.Transporter;

  constructor() {
    this.initializeTransporter();
  }

  private async initializeTransporter() {
    try {
      // Production Gmail SMTP configuration
      if (process.env.EMAIL_SERVICE === 'gmail' && process.env.EMAIL_USER && process.env.EMAIL_PASS) {
        console.log('🔧 Configuring Gmail SMTP for email delivery...');
        console.log('   📧 Gmail User:', process.env.EMAIL_USER);
        console.log('   🔐 Password Length:', process.env.EMAIL_PASS.length, 'characters');
        
        this.transporter = nodemailer.createTransport({
          service: 'gmail',
          host: 'smtp.gmail.com',
          port: 587,
          secure: false, // Use STARTTLS
          auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS, // App password required
          },
          debug: process.env.EMAIL_DEBUG === 'true',
          logger: process.env.EMAIL_DEBUG === 'true',
          tls: {
            rejectUnauthorized: false
          }
        });
        
        console.log('✅ Gmail SMTP configured successfully');
      }
      // If no email credentials provided and using Ethereal, create test account
      else if (!process.env.EMAIL_USER && (process.env.EMAIL_HOST === 'smtp.ethereal.email' || process.env.EMAIL_SERVICE === 'ethereal')) {
        console.log('🔧 Creating Ethereal test account for email testing...');
        const testAccount = await nodemailer.createTestAccount();
        
        this.transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass,
          },
        });
        
        console.log('✅ Ethereal test account created:');
        console.log('   Email User:', testAccount.user);
        console.log('   Email Pass:', testAccount.pass);
        console.log('   Preview URLs will be logged after sending emails');
      } else {
        console.log('🔧 Configuring custom SMTP...');
        this.transporter = nodemailer.createTransport({
          host: process.env.EMAIL_HOST || 'smtp.gmail.com',
          port: parseInt(process.env.EMAIL_PORT || '587'),
          secure: process.env.EMAIL_SECURE === 'true',
          auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS,
          },
          debug: process.env.EMAIL_DEBUG === 'true',
          logger: process.env.EMAIL_DEBUG === 'true',
        });
      }

      // Verify transporter configuration
      console.log('🔍 Verifying email transporter configuration...');
      await this.transporter.verify();
      console.log('✅ Email service ready and verified');
    } catch (error) {
      console.error('❌ Failed to initialize email service:', error);
      console.error('   📧 EMAIL_SERVICE:', process.env.EMAIL_SERVICE);
      console.error('   🌐 EMAIL_HOST:', process.env.EMAIL_HOST);
      console.error('   📮 EMAIL_USER:', process.env.EMAIL_USER ? 'Set' : 'Not set');
      console.error('   🔐 EMAIL_PASS:', process.env.EMAIL_PASS ? 'Set' : 'Not set');
      
      // Fallback to Ethereal for development
      console.log('🔄 Falling back to Ethereal test account...');
      try {
        const testAccount = await nodemailer.createTestAccount();
        this.transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass,
          },
        });
        console.log('✅ Fallback Ethereal account created');
      } catch (fallbackError) {
        console.error('❌ Even fallback failed:', fallbackError);
      }
    }
  }

  async sendEmail({ to, subject, html, text }: EmailOptions): Promise<boolean> {
    try {
      console.log('📧 Sending email:');
      console.log('   📍 To:', to);
      console.log('   📋 Subject:', subject);
      console.log('   🔧 Service:', process.env.EMAIL_SERVICE);
      console.log('   📮 From:', process.env.EMAIL_FROM_ADDRESS);

      const mailOptions = {
        from: `${process.env.EMAIL_FROM_NAME || 'Auth System'} <${process.env.EMAIL_FROM_ADDRESS || 'noreply@localhost'}>`,
        to,
        subject,
        html,
        text: text || html.replace(/<[^>]*>/g, ''), // Strip HTML for text version
      };

      const info = await this.transporter.sendMail(mailOptions);
      console.log('✅ Email sent successfully:', info.messageId);
      
      // Log preview URL for Ethereal Email (development)
      if (process.env.NODE_ENV === 'development' && process.env.EMAIL_SERVICE !== 'gmail') {
        const previewUrl = nodemailer.getTestMessageUrl(info);
        if (previewUrl) {
          console.log('🔗 Preview URL:', previewUrl);
        }
      }

      return true;
    } catch (error) {
      console.error('❌ Email sending failed:', error);
      console.error('   📧 To:', to);
      console.error('   🔧 Service:', process.env.EMAIL_SERVICE);
      console.error('   📮 SMTP Host:', process.env.EMAIL_HOST);
      console.error('   🔐 User:', process.env.EMAIL_USER);
      return false;
    }
  }

  async sendEmailVerification(email: string, firstName: string, verificationToken: string): Promise<boolean> {
    const verificationUrl = `${process.env.FRONTEND_URL}/verify-email?token=${verificationToken}`;
    
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Your Email</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
          }
          .title {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
          }
          .subtitle {
            color: #666;
            font-size: 16px;
          }
          .content {
            color: #444;
            line-height: 1.6;
            margin-bottom: 30px;
          }
          .button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 16px;
            transition: all 0.3s ease;
            margin: 20px 0;
          }
          .button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
          }
          .footer {
            text-align: center;
            color: #888;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
          }
          .security-note {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 20px 0;
            border-radius: 0 8px 8px 0;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🔐 Auth System</div>
            <h1 class="title">Verify Your Email Address</h1>
            <p class="subtitle">Almost there! Just one more step...</p>
          </div>
          
          <div class="content">
            <p>Hi <strong>${firstName}</strong>,</p>
            
            <p>Welcome to Auth System! To complete your registration and secure your account, please verify your email address by clicking the button below:</p>
            
            <div style="text-align: center;">
              <a href="${verificationUrl}" class="button">✅ Verify Email Address</a>
            </div>
            
            <div class="security-note">
              <strong>🔒 Security Notice:</strong><br>
              This verification link will expire in 24 hours for your security. If you didn't create an account with us, you can safely ignore this email.
            </div>
            
            <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #667eea;">${verificationUrl}</p>
            
            <p>After verification, you'll be able to:</p>
            <ul>
              <li>✨ Access your personalized dashboard</li>
              <li>🔐 Enable two-factor authentication</li>
              <li>🎨 Customize your profile</li>
              <li>📧 Receive important account notifications</li>
            </ul>
          </div>
          
          <div class="footer">
            <p>Need help? Contact our support team at <a href="mailto:support@localhost">support@localhost</a></p>
            <p>&copy; 2024 Auth System. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: '🔐 Verify Your Email - Auth System',
      html,
    });
  }

  async sendLoginOTP(email: string, firstName: string, otp: string): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Login Code</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
          }
          .otp-box {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            font-size: 36px;
            font-weight: bold;
            text-align: center;
            padding: 20px;
            border-radius: 15px;
            letter-spacing: 8px;
            margin: 30px 0;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
          }
          .content {
            color: #444;
            line-height: 1.6;
          }
          .security-warning {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
          }
          .footer {
            text-align: center;
            color: #888;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🔐 Auth System</div>
            <h1 style="color: #333; margin-bottom: 10px;">Your Login Verification Code</h1>
          </div>
          
          <div class="content">
            <p>Hi <strong>${firstName}</strong>,</p>
            
            <p>You're trying to log into your Auth System account. Please use the following verification code:</p>
            
            <div class="otp-box">${otp}</div>
            
            <div class="security-warning">
              <strong>⚠️ Security Alert:</strong><br>
              This code expires in <strong>10 minutes</strong>. Never share this code with anyone. If you didn't request this login, please secure your account immediately.
            </div>
            
            <p><strong>What to do next:</strong></p>
            <ol>
              <li>Return to the login page</li>
              <li>Enter this 6-digit code when prompted</li>
              <li>Complete your secure login</li>
            </ol>
            
            <p>This code can only be used once and will expire automatically for your security.</p>
          </div>
          
          <div class="footer">
            <p>Didn't request this code? <a href="mailto:support@localhost">Contact Support</a></p>
            <p>&copy; 2024 Auth System. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: '🔐 Your Login Verification Code - Auth System',
      html,
    });
  }

  async sendWelcomeEmail(email: string, firstName: string): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Auth System</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
          }
          .welcome-banner {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-align: center;
            padding: 30px;
            border-radius: 15px;
            margin: 20px 0;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🎉 Auth System</div>
          </div>
          
          <div class="welcome-banner">
            <h1 style="margin: 0 0 10px 0;">Welcome aboard, ${firstName}! 🚀</h1>
            <p style="margin: 0; opacity: 0.9;">Your account has been successfully verified</p>
          </div>
          
          <div style="color: #444; line-height: 1.6;">
            <p>Congratulations! Your email has been verified and your Auth System account is now fully active.</p>
            
            <p><strong>What's next?</strong></p>
            <ul>
              <li>🔐 <strong>Secure Login:</strong> Use your email and password to access your account</li>
              <li>🛡️ <strong>Two-Factor Authentication:</strong> Enable 2FA for enhanced security</li>
              <li>👤 <strong>Profile Setup:</strong> Customize your profile and preferences</li>
              <li>📱 <strong>Mobile Access:</strong> Access your account from any device</li>
            </ul>
            
            <p>If you have any questions or need assistance, don't hesitate to reach out to our support team.</p>
          </div>
          
          <div style="text-align: center; margin-top: 30px; color: #888; font-size: 14px;">
            <p>&copy; 2024 Auth System. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: '🎉 Welcome to Auth System - Account Verified!',
      html,
    });
  }

  async sendPasswordResetEmail(email: string, firstName: string, resetToken: string): Promise<boolean> {
    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;
    
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reset Your Password</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
          }
          .title {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
          }
          .subtitle {
            color: #666;
            font-size: 16px;
          }
          .content {
            color: #444;
            line-height: 1.6;
            margin-bottom: 30px;
          }
          .button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 16px;
            transition: all 0.3s ease;
            margin: 20px 0;
          }
          .button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
          }
          .footer {
            text-align: center;
            color: #888;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
          }
          .security-note {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🔐 Auth System</div>
            <h1 class="title">Password Reset Request</h1>
            <p class="subtitle">Reset your password securely</p>
          </div>
          
          <div class="content">
            <p>Hi <strong>${firstName}</strong>,</p>
            
            <p>We received a request to reset your password for your Auth System account. Click the button below to create a new password:</p>
            
            <div style="text-align: center;">
              <a href="${resetUrl}" class="button">🔑 Reset Password</a>
            </div>
            
            <div class="security-note">
              <strong>⚠️ Security Notice:</strong><br>
              This reset link will expire in <strong>10 minutes</strong> for your security. If you didn't request a password reset, you can safely ignore this email.
            </div>
            
            <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #667eea;">${resetUrl}</p>
            
            <p><strong>For your security:</strong></p>
            <ul>
              <li>🔒 Never share this reset link with anyone</li>
              <li>⏱️ This link expires in 10 minutes</li>
              <li>🚨 If you didn't request this, contact support</li>
            </ul>
          </div>
          
          <div class="footer">
            <p>Need help? Contact our support team at <a href="mailto:support@localhost">support@localhost</a></p>
            <p>&copy; 2024 Auth System. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: '🔐 Password Reset Request - Auth System',
      html,
    });
  }

  async sendPasswordResetOTP(email: string, firstName: string, otp: string): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Password Reset Code</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
          }
          .otp-box {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            font-size: 36px;
            font-weight: bold;
            text-align: center;
            padding: 20px;
            border-radius: 15px;
            letter-spacing: 8px;
            margin: 30px 0;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
          }
          .content {
            color: #444;
            line-height: 1.6;
          }
          .security-warning {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
          }
          .footer {
            text-align: center;
            color: #888;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🔐 Auth System</div>
            <h1 style="color: #333; margin-bottom: 10px;">Password Reset Code</h1>
          </div>
          
          <div class="content">
            <p>Hi <strong>${firstName}</strong>,</p>
            
            <p>You requested to reset your password. Please use the following verification code:</p>
            
            <div class="otp-box">${otp}</div>
            
            <div class="security-warning">
              <strong>⚠️ Security Alert:</strong><br>
              This code expires in <strong>10 minutes</strong>. Never share this code with anyone. If you didn't request this password reset, please secure your account immediately.
            </div>
            
            <p><strong>What to do next:</strong></p>
            <ol>
              <li>Return to the reset password page</li>
              <li>Enter this 6-digit code when prompted</li>
              <li>Create your new secure password</li>
            </ol>
            
            <p>This code can only be used once and will expire automatically for your security.</p>
          </div>
          
          <div class="footer">
            <p>Didn't request this reset? <a href="mailto:support@localhost">Contact Support</a></p>
            <p>&copy; 2024 Auth System. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: '🔐 Password Reset Code - Auth System',
      html,
    });
  }
}

export const emailService = new EmailService();