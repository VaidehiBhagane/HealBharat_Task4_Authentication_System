import mongoose, { Document, Schema } from 'mongoose';

export interface IOTP extends Document {
  userId?: mongoose.Types.ObjectId;
  email?: string;
  phoneNumber?: string;
  code: string;
  type: 'email_verification' | 'phone_verification' | 'password_reset' | '2fa';
  isUsed: boolean;
  attempts: number;
  expiresAt: Date;
  createdAt: Date;
  updatedAt: Date;
  
  // Methods
  isExpired(): boolean;
  isValid(): boolean;
  incrementAttempts(): Promise<void>;
}

const otpSchema = new Schema<IOTP>({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
  },
  email: {
    type: String,
    lowercase: true,
    validate: {
      validator: function(email: string) {
        // Email validation using regex
        return !email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      },
      message: 'Please provide a valid email address',
    },
  },
  phoneNumber: {
    type: String,
    validate: {
      validator: function(phone: string) {
        // Basic phone validation
        return !phone || /^\+?[\d\s\-\(\)]+$/.test(phone);
      },
      message: 'Please provide a valid phone number',
    },
  },
  code: {
    type: String,
    required: [true, 'OTP code is required'],
    length: [6, 'OTP code must be exactly 6 digits'],
    match: [/^\d{6}$/, 'OTP code must contain only digits'],
  },
  type: {
    type: String,
    required: [true, 'OTP type is required'],
    enum: {
      values: ['email_verification', 'phone_verification', 'password_reset', '2fa'],
      message: 'Invalid OTP type',
    },
  },
  isUsed: {
    type: Boolean,
    default: false,
  },
  attempts: {
    type: Number,
    default: 0,
    max: [5, 'Maximum 5 attempts allowed'],
  },
  expiresAt: {
    type: Date,
    required: true,
    default: function() {
      // Default expiration is 10 minutes from creation
      return new Date(Date.now() + 10 * 60 * 1000);
    },
    index: { expireAfterSeconds: 0 }, // MongoDB TTL index
  },
}, {
  timestamps: true,
});

// Compound indexes for performance and uniqueness
otpSchema.index({ email: 1, type: 1, isUsed: 1 });
otpSchema.index({ phoneNumber: 1, type: 1, isUsed: 1 });
otpSchema.index({ userId: 1, type: 1, isUsed: 1 });
otpSchema.index({ expiresAt: 1 });
otpSchema.index({ createdAt: 1 });

// Ensure either email, phoneNumber, or userId is provided
otpSchema.pre<IOTP>('validate', function(next) {
  if (!this.email && !this.phoneNumber && !this.userId) {
    const error = new Error('Either email, phoneNumber, or userId must be provided');
    return next(error);
  }
  next();
});

// Instance Methods
otpSchema.methods.isExpired = function(): boolean {
  return new Date() > this.expiresAt;
};

otpSchema.methods.isValid = function(): boolean {
  return !this.isUsed && !this.isExpired() && this.attempts < 5;
};

otpSchema.methods.incrementAttempts = async function(): Promise<void> {
  this.attempts += 1;
  await this.save();
};

// Static Methods
otpSchema.statics.generateCode = function(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

otpSchema.statics.createOTP = async function(data: {
  userId?: string;
  email?: string;
  phoneNumber?: string;
  type: string;
  expirationMinutes?: number;
}) {
  // Invalidate any existing unused OTPs of the same type
  const filter: any = { type: data.type, isUsed: false };
  
  if (data.userId) filter.userId = data.userId;
  if (data.email) filter.email = data.email;
  if (data.phoneNumber) filter.phoneNumber = data.phoneNumber;
  
  await this.updateMany(filter, { isUsed: true });
  
  // Generate new OTP
  const code = (this as any).generateCode();
  const expiresAt = new Date(Date.now() + (data.expirationMinutes || 10) * 60 * 1000);
  
  const otp = new this({
    userId: data.userId,
    email: data.email,
    phoneNumber: data.phoneNumber,
    code,
    type: data.type,
    expiresAt,
  });
  
  await otp.save();
  return otp;
};

otpSchema.statics.verifyOTP = async function(data: {
  userId?: string;
  email?: string;
  phoneNumber?: string;
  code: string;
  type: string;
}) {
  const filter: any = {
    code: data.code,
    type: data.type,
    isUsed: false,
  };
  
  if (data.userId) filter.userId = data.userId;
  if (data.email) filter.email = data.email;
  if (data.phoneNumber) filter.phoneNumber = data.phoneNumber;
  
  const otp = await this.findOne(filter);
  
  if (!otp) {
    throw new Error('Invalid OTP code');
  }
  
  if (otp.isExpired()) {
    throw new Error('OTP code has expired');
  }
  
  if (otp.attempts >= 5) {
    throw new Error('Maximum attempts exceeded');
  }
  
  // Mark as used
  otp.isUsed = true;
  await otp.save();
  
  return otp;
};

otpSchema.statics.cleanupExpired = async function() {
  const result = await this.deleteMany({
    $or: [
      { expiresAt: { $lt: new Date() } },
      { isUsed: true, createdAt: { $lt: new Date(Date.now() - 24 * 60 * 60 * 1000) } }
    ]
  });
  
  return result.deletedCount;
};

export const OTP = mongoose.model<IOTP>('OTP', otpSchema);
export default OTP;