import mongoose, { Document, Schema } from 'mongoose';

export interface IUserActivity extends Document {
  userId: mongoose.Types.ObjectId;
  action: string;
  details: any;
  ipAddress?: string;
  userAgent?: string;
  location?: {
    country?: string;
    city?: string;
    timezone?: string;
  };
  deviceInfo?: {
    type?: string;
    os?: string;
    browser?: string;
  };
  success: boolean;
  errorMessage?: string;
  createdAt: Date;
}

const UserActivitySchema = new Schema<IUserActivity>({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required'],
  },
  action: {
    type: String,
    required: [true, 'Action is required'],
    enum: [
      'LOGIN',
      'LOGOUT',
      'LOGIN_FAILED',
      'PASSWORD_CHANGE',
      'PASSWORD_RESET_REQUEST',
      'PASSWORD_RESET_COMPLETE',
      'EMAIL_VERIFICATION',
      'PHONE_VERIFICATION',
      'TWO_FACTOR_ENABLE',
      'TWO_FACTOR_DISABLE',
      'TWO_FACTOR_LOGIN',
      'PROFILE_UPDATE',
      'ACCOUNT_ACTIVATED',
      'ACCOUNT_DEACTIVATED',
      'PASSWORD_RESET_BY_ADMIN',
      'OTP_REQUEST',
      'OTP_VERIFY',
      'OTP_VERIFY_FAILED',
      'SOCIAL_LOGIN',
      'ACCOUNT_LOCKED',
      'ACCOUNT_UNLOCKED'
    ],
  },
  details: {
    type: Schema.Types.Mixed,
    default: {},
  },
  ipAddress: {
    type: String,
    required: false,
  },
  userAgent: {
    type: String,
    required: false,
  },
  location: {
    country: String,
    city: String,
    timezone: String,
  },
  deviceInfo: {
    type: {
      type: String,
      enum: ['desktop', 'mobile', 'tablet', 'unknown'],
    },
    os: String,
    browser: String,
  },
  success: {
    type: Boolean,
    default: true,
  },
  errorMessage: {
    type: String,
    required: false,
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes for performance
UserActivitySchema.index({ userId: 1, createdAt: -1 });
UserActivitySchema.index({ action: 1, createdAt: -1 });
UserActivitySchema.index({ success: 1, createdAt: -1 });
UserActivitySchema.index({ createdAt: -1 });

// Auto-delete old activity logs after 6 months
UserActivitySchema.index({ createdAt: 1 }, { expireAfterSeconds: 180 * 24 * 60 * 60 });

// Static method to log user activity
UserActivitySchema.statics.logActivity = async function(
  userId: mongoose.Types.ObjectId,
  action: string,
  details: any = {},
  req?: any
) {
  const activityData: any = {
    userId,
    action,
    details,
  };

  if (req) {
    activityData.ipAddress = req.ip || req.connection.remoteAddress;
    activityData.userAgent = req.get('User-Agent');
    
    // Parse device info from user agent
    const userAgent = req.get('User-Agent') || '';
    activityData.deviceInfo = {
      type: /Mobile|Android|iPhone|iPad/.test(userAgent) ? 'mobile' : 'desktop',
      os: userAgent.includes('Windows') ? 'Windows' :
          userAgent.includes('Mac') ? 'macOS' :
          userAgent.includes('Linux') ? 'Linux' :
          userAgent.includes('Android') ? 'Android' :
          userAgent.includes('iOS') ? 'iOS' : 'unknown',
      browser: userAgent.includes('Chrome') ? 'Chrome' :
               userAgent.includes('Firefox') ? 'Firefox' :
               userAgent.includes('Safari') ? 'Safari' :
               userAgent.includes('Edge') ? 'Edge' : 'unknown'
    };
  }

  return this.create(activityData);
};

export const UserActivity = mongoose.model<IUserActivity>('UserActivity', UserActivitySchema);
export default UserActivity;