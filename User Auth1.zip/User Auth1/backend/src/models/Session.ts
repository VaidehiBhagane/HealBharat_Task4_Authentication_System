import mongoose, { Document, Schema } from 'mongoose';

export interface ISession extends Document {
  userId: mongoose.Types.ObjectId;
  refreshToken: string;
  deviceInfo: {
    userAgent?: string;
    ip: string;
    device?: string;
    browser?: string;
    os?: string;
    location?: {
      country?: string;
      city?: string;
      region?: string;
    };
  };
  isActive: boolean;
  lastAccessed: Date;
  expiresAt: Date;
  createdAt: Date;
  updatedAt: Date;
  
  // Methods
  updateLastAccessed(): Promise<void>;
  isExpired(): boolean;
  revoke(): Promise<void>;
}

const sessionSchema = new Schema<ISession>({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required'],
    index: true,
  },
  refreshToken: {
    type: String,
    required: [true, 'Refresh token is required'],
    unique: true,
    index: true,
  },
  deviceInfo: {
    userAgent: {
      type: String,
      maxlength: [500, 'User agent cannot exceed 500 characters'],
    },
    ip: {
      type: String,
      required: [true, 'IP address is required'],
      validate: {
        validator: function(ip: string) {
          // Basic IP validation (IPv4 and IPv6)
          const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
          const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
          return ipv4Regex.test(ip) || ipv6Regex.test(ip);
        },
        message: 'Please provide a valid IP address',
      },
    },
    device: {
      type: String,
      maxlength: [100, 'Device name cannot exceed 100 characters'],
    },
    browser: {
      type: String,
      maxlength: [100, 'Browser name cannot exceed 100 characters'],
    },
    os: {
      type: String,
      maxlength: [100, 'OS name cannot exceed 100 characters'],
    },
    location: {
      country: {
        type: String,
        maxlength: [100, 'Country name cannot exceed 100 characters'],
      },
      city: {
        type: String,
        maxlength: [100, 'City name cannot exceed 100 characters'],
      },
      region: {
        type: String,
        maxlength: [100, 'Region name cannot exceed 100 characters'],
      },
    },
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true,
  },
  lastAccessed: {
    type: Date,
    default: Date.now,
    index: true,
  },
  expiresAt: {
    type: Date,
    required: true,
    index: { expireAfterSeconds: 0 }, // MongoDB TTL index
  },
}, {
  timestamps: true,
});

// Compound indexes for efficient queries
sessionSchema.index({ userId: 1, isActive: 1 });
sessionSchema.index({ userId: 1, lastAccessed: -1 });
sessionSchema.index({ refreshToken: 1, isActive: 1 });
sessionSchema.index({ expiresAt: 1 });
sessionSchema.index({ 'deviceInfo.ip': 1, userId: 1 });

// Instance Methods
sessionSchema.methods.updateLastAccessed = async function(): Promise<void> {
  this.lastAccessed = new Date();
  await this.save();
};

sessionSchema.methods.isExpired = function(): boolean {
  return new Date() > this.expiresAt;
};

sessionSchema.methods.revoke = async function(): Promise<void> {
  this.isActive = false;
  await this.save();
};

// Static Methods
sessionSchema.statics.createSession = async function(data: {
  userId: string;
  refreshToken: string;
  deviceInfo: any;
  expirationDays?: number;
}) {
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + (data.expirationDays || 30)); // Default 30 days
  
  const session = new this({
    userId: data.userId,
    refreshToken: data.refreshToken,
    deviceInfo: data.deviceInfo,
    expiresAt,
  });
  
  await session.save();
  return session;
};

sessionSchema.statics.findActiveSession = async function(refreshToken: string) {
  return this.findOne({
    refreshToken,
    isActive: true,
    expiresAt: { $gt: new Date() },
  });
};

sessionSchema.statics.revokeAllUserSessions = async function(userId: string) {
  return this.updateMany(
    { userId, isActive: true },
    { isActive: false }
  );
};

sessionSchema.statics.revokeSession = async function(refreshToken: string) {
  return this.updateOne(
    { refreshToken },
    { isActive: false }
  );
};

sessionSchema.statics.cleanupExpiredSessions = async function() {
  const result = await this.deleteMany({
    $or: [
      { expiresAt: { $lt: new Date() } },
      { isActive: false, updatedAt: { $lt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } }
    ]
  });
  
  return result.deletedCount;
};

sessionSchema.statics.getUserActiveSessions = async function(userId: string) {
  return this.find({
    userId,
    isActive: true,
    expiresAt: { $gt: new Date() },
  }).sort({ lastAccessed: -1 });
};

sessionSchema.statics.getSessionStats = async function(userId: string) {
  const [activeSessions, totalSessions, recentSessions] = await Promise.all([
    this.countDocuments({ userId, isActive: true, expiresAt: { $gt: new Date() } }),
    this.countDocuments({ userId }),
    this.find({ userId })
      .sort({ lastAccessed: -1 })
      .limit(5)
      .select('deviceInfo lastAccessed isActive'),
  ]);
  
  return {
    activeSessions,
    totalSessions,
    recentSessions,
  };
};

export const Session = mongoose.model<ISession>('Session', sessionSchema);
export default Session;