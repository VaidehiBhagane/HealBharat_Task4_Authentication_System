import mongoose, { Document, Schema } from 'mongoose';

export interface IAuditLog extends Document {
  adminId: mongoose.Types.ObjectId;
  action: string;
  resourceType: string;
  resourceId?: mongoose.Types.ObjectId;
  details: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

const AuditLogSchema = new Schema<IAuditLog>({
  adminId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Admin ID is required'],
  },
  action: {
    type: String,
    required: [true, 'Action is required'],
    enum: [
      'VIEW_USERS',
      'VIEW_USER_DETAILS',
      'ACTIVATE_USER',
      'DEACTIVATE_USER',
      'RESET_USER_PASSWORD',
      'VIEW_USER_LOGS',
      'EXPORT_USERS',
      'VIEW_DASHBOARD',
      'VIEW_AUDIT_LOGS',
      'UPDATE_USER_ROLE',
      'DELETE_USER',
      'CREATE_USER',
      'BULK_ACTION'
    ],
  },
  resourceType: {
    type: String,
    required: [true, 'Resource type is required'],
    enum: ['USER', 'USER_ACTIVITY', 'DASHBOARD', 'AUDIT_LOG', 'SYSTEM'],
  },
  resourceId: {
    type: Schema.Types.ObjectId,
    required: false,
  },
  details: {
    type: Schema.Types.Mixed,
    default: {},
  },
  ipAddress: {
    type: String,
    required: false,
  },
  userAgent: {
    type: String,
    required: false,
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes for performance
AuditLogSchema.index({ adminId: 1, createdAt: -1 });
AuditLogSchema.index({ action: 1, createdAt: -1 });
AuditLogSchema.index({ resourceType: 1, resourceId: 1 });
AuditLogSchema.index({ createdAt: -1 });

// Auto-delete old audit logs after 1 year (for compliance)
AuditLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 365 * 24 * 60 * 60 });

export const AuditLog = mongoose.model<IAuditLog>('AuditLog', AuditLogSchema);
export default AuditLog;