import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import session from 'express-session';
import MongoStore from 'connect-mongo';
import passport from 'passport';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';

// Import configurations
import { connectDB } from './config/database';
import { configurePassport } from './config/passport';
import { logOAuthConfig } from './utils/oauthDebug';
import { performStartupChecks } from './config/startup';

// Import routes
import authRoutes from './routes/auth';
// import userRoutes from './routes/user';
import adminRoutes from './routes/admin';
import systemRoutes from './routes/system';
import testRoutes from './routes/testRoutes';
import testEmailRoutes from './routes/testEmail';
import debugRoutes from './routes/debugFixed';

// Import middleware
import { errorHandler, notFound } from './middleware/errorHandler';
import { xssProtection, secureHeaders, getCSRFToken } from './middleware/security';

// Load environment variables
dotenv.config();

const app: Application = express();
const PORT = process.env.PORT || 5000;

// Perform comprehensive startup checks
async function initializeServer() {
  console.log('🚀 Starting Auth System...');
  
  const startupResult = await performStartupChecks();
  
  if (!startupResult.dbConnected) {
    console.error('❌ Failed to connect to database. Server cannot start.');
    process.exit(1);
  }

  if (!startupResult.adminReady) {
    console.warn('⚠️ Admin user not ready, but continuing...');
  }

  if (startupResult.errors.length > 0) {
    console.warn('⚠️ Startup warnings:', startupResult.errors);
  }

  // Configure Passport after DB is ready
  configurePassport();
  logOAuthConfig();
  
  return startupResult;
}

// Connect to Database
// connectDB(); // Replaced with comprehensive startup checks

// Security Middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https://res.cloudinary.com", "https://lh3.googleusercontent.com"],
      scriptSrc: ["'self'"],
    },
  },
}));

// Additional security middleware
app.use(xssProtection);
app.use(secureHeaders);

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // Limit auth attempts to 20 per 15 minutes (increased from 5)
  message: {
    error: 'Too many authentication attempts, please try again later.',
  },
  skipSuccessfulRequests: true,
});

app.use(limiter);

// CORS Configuration
const corsOptions = {
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  optionsSuccessStatus: 200,
};
app.use(cors(corsOptions));

// General Middleware
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Serve static files (for profile pictures)
app.use('/uploads', express.static('uploads'));

// Session Configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'fallback-secret-key',
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem',
    }),
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  })
);

// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

// Health Check Route
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({
    status: 'OK',
    message: 'Server is running',
    timestamp: new Date().toISOString(),
  });
});

// API Routes
app.use('/api/auth', authLimiter, authRoutes);
// app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/system', systemRoutes);
app.use('/api/test', testRoutes);
app.use('/api/email', testEmailRoutes);
app.use('/api/debug', debugRoutes);

// CSRF Token endpoint
app.get('/api/csrf-token', getCSRFToken);

// Root Route
app.get('/', (req: Request, res: Response) => {
  res.json({
    message: 'Auth System API',
    version: '1.0.0',
    docs: '/api/docs',
  });
});

// Error Handling Middleware (must be last)
app.use(notFound);
app.use(errorHandler);

// Graceful Shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

if (process.env.NODE_ENV !== 'test') {
  // Start Server with comprehensive initialization
  async function startServer() {
    try {
      // Initialize all systems
      await initializeServer();
      
      // Start the server
      app.listen(PORT, () => {
        console.log('🎉 Auth System Started Successfully!');
        console.log(`🌐 Server running on port ${PORT}`);
        console.log(`📱 Frontend: ${process.env.FRONTEND_URL || 'http://localhost:3000'}`);
        console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
        console.log('\n🔐 Default Admin Credentials:');
        console.log('   � Email: admin@test.com');
        console.log('   🔑 Password: admin123');
        console.log('\n📋 Available Endpoints:');
        console.log('   🏥 Health Check: http://localhost:5000/health');
        console.log('   🔍 Debug Info: http://localhost:5000/api/debug/status');
        console.log('   📧 Email Test: http://localhost:5000/api/debug/send-test-email');
        console.log(`�📖 API Documentation: http://localhost:${PORT}/api/docs`);
      });
    } catch (error) {
      console.error('❌ Failed to start server:', error);
      process.exit(1);
    }
  }

  // Initialize server
  startServer();
}

export default app;