// Test SMS endpoints for manual testing
import { Router, Request, Response } from 'express';
import { smsService } from '../services/smsService';

const router = Router();

// Test Login OTP SMS
router.post('/sms/login-otp', async (req: Request, res: Response) => {
  try {
    const { phoneNumber, firstName, otp } = req.body;
    
    if (!phoneNumber || !firstName || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Phone number, firstName, and otp are required'
      });
    }
    
    console.log(`🧪 Testing Login OTP SMS to ${phoneNumber}`);
    const result = await smsService.sendLoginOTP(phoneNumber, firstName, otp);
    
    res.json({
      success: result,
      message: result ? 'Login OTP SMS sent successfully' : 'Failed to send Login OTP SMS',
      data: {
        phoneNumber,
        firstName,
        otp,
        messageType: 'Login OTP'
      }
    });
    
  } catch (error: any) {
    console.error('❌ Login OTP SMS test failed:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
});

// Test Registration OTP SMS
router.post('/sms/registration-otp', async (req: Request, res: Response) => {
  try {
    const { phoneNumber, firstName, otp } = req.body;
    
    if (!phoneNumber || !firstName || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Phone number, firstName, and otp are required'
      });
    }
    
    console.log(`🧪 Testing Registration OTP SMS to ${phoneNumber}`);
    const result = await smsService.sendRegistrationOTP(phoneNumber, firstName, otp);
    
    res.json({
      success: result,
      message: result ? 'Registration OTP SMS sent successfully' : 'Failed to send Registration OTP SMS',
      data: {
        phoneNumber,
        firstName,
        otp,
        messageType: 'Registration OTP'
      }
    });
    
  } catch (error: any) {
    console.error('❌ Registration OTP SMS test failed:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
});

// Test Security Alert SMS
router.post('/sms/security-alert', async (req: Request, res: Response) => {
  try {
    const { phoneNumber, firstName, action } = req.body;
    
    if (!phoneNumber || !firstName || !action) {
      return res.status(400).json({
        success: false,
        message: 'Phone number, firstName, and action are required'
      });
    }
    
    console.log(`🧪 Testing Security Alert SMS to ${phoneNumber}`);
    const result = await smsService.sendSecurityAlert(phoneNumber, firstName, action);
    
    res.json({
      success: result,
      message: result ? 'Security Alert SMS sent successfully' : 'Failed to send Security Alert SMS',
      data: {
        phoneNumber,
        firstName,
        action,
        messageType: 'Security Alert'
      }
    });
    
  } catch (error: any) {
    console.error('❌ Security Alert SMS test failed:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
});

// Get SMS service status
router.get('/sms/status', async (req: Request, res: Response) => {
  try {
    const isAvailable = smsService.isAvailable();
    
    res.json({
      success: true,
      message: 'SMS service status retrieved',
      data: {
        isAvailable,
        provider: 'Twilio',
        phoneNumber: process.env.TWILIO_PHONE_NUMBER,
        accountSid: process.env.TWILIO_ACCOUNT_SID ? '***' + process.env.TWILIO_ACCOUNT_SID.slice(-4) : 'Not set'
      }
    });
    
  } catch (error: any) {
    console.error('❌ Failed to get SMS service status:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
});

// Test all SMS types at once
router.post('/sms/test-all', async (req: Request, res: Response) => {
  try {
    const { phoneNumber, firstName } = req.body;
    
    if (!phoneNumber || !firstName) {
      return res.status(400).json({
        success: false,
        message: 'Phone number and firstName are required'
      });
    }
    
    const testOtp = '123456';
    const testAction = 'password change';
    
    console.log(`🧪 Testing all SMS types to ${phoneNumber}`);
    
    // Test all SMS types
    const loginResult = await smsService.sendLoginOTP(phoneNumber, firstName, testOtp);
    
    // Wait 2 seconds between messages to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const registrationResult = await smsService.sendRegistrationOTP(phoneNumber, firstName, testOtp);
    
    // Wait 2 seconds between messages
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const securityResult = await smsService.sendSecurityAlert(phoneNumber, firstName, testAction);
    
    const allSuccess = loginResult && registrationResult && securityResult;
    
    res.json({
      success: allSuccess,
      message: allSuccess ? 'All SMS tests completed successfully' : 'Some SMS tests failed',
      data: {
        phoneNumber,
        firstName,
        results: {
          loginOTP: loginResult,
          registrationOTP: registrationResult,
          securityAlert: securityResult
        },
        summary: `${[loginResult, registrationResult, securityResult].filter(Boolean).length}/3 messages sent successfully`
      }
    });
    
  } catch (error: any) {
    console.error('❌ SMS test-all failed:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
});

export default router;