import express from 'express';
import { emailService } from '../services/emailService';

const router = express.Router();

// Test email sending functionality
router.post('/send-test-email', async (req, res) => {
  try {
    const { email, testType = 'basic' } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email address is required'
      });
    }

    console.log(`🧪 Testing email delivery to: ${email}`);
    console.log(`📧 Test type: ${testType}`);

    let result = false;
    let testDetails = {};

    switch (testType) {
      case 'basic':
        result = await emailService.sendEmail({
          to: email,
          subject: '🧪 Test Email - Basic Connectivity',
          html: `
            <h2>✅ Email Service Test Successful!</h2>
            <p>This email confirms that your SMTP configuration is working correctly.</p>
            <p><strong>Test Details:</strong></p>
            <ul>
              <li>📧 Service: ${process.env.EMAIL_SERVICE}</li>
              <li>🌐 Host: ${process.env.EMAIL_HOST}</li>
              <li>📮 From: ${process.env.EMAIL_FROM_ADDRESS}</li>
              <li>⏰ Sent at: ${new Date().toLocaleString()}</li>
            </ul>
            <p>If you received this email, your OTP delivery should work!</p>
          `
        });
        testDetails = {
          service: process.env.EMAIL_SERVICE,
          host: process.env.EMAIL_HOST,
          from: process.env.EMAIL_FROM_ADDRESS
        };
        break;

      case 'otp':
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        result = await emailService.sendPasswordResetOTP(email, 'Test User', otp);
        testDetails = {
          type: 'Password Reset OTP',
          otp: otp,
          note: 'This is a test OTP - do not use for actual password reset'
        };
        break;

      case 'verification':
        const token = 'test-verification-token-' + Date.now();
        result = await emailService.sendEmailVerification(email, 'Test User', token);
        testDetails = {
          type: 'Email Verification',
          token: token,
          note: 'This is a test verification - do not use for actual verification'
        };
        break;

      default:
        return res.status(400).json({
          success: false,
          message: 'Invalid test type. Use: basic, otp, or verification'
        });
    }

    if (result) {
      console.log('✅ Test email sent successfully');
      res.json({
        success: true,
        message: `Test email sent successfully to ${email}`,
        testDetails,
        timestamp: new Date().toISOString(),
        instructions: 'Check your email inbox (and spam folder) for the test message'
      });
    } else {
      console.log('❌ Test email failed to send');
      res.status(500).json({
        success: false,
        message: 'Failed to send test email',
        testDetails,
        troubleshooting: [
          'Check your email credentials in .env file',
          'Verify Gmail app password is correct (16 characters, no spaces)',
          'Check if 2FA is enabled on your Gmail account',
          'Look at server logs for detailed error messages'
        ]
      });
    }

  } catch (error) {
    console.error('❌ Test email error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while sending test email',
      error: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined
    });
  }
});

// Get email service status and configuration
router.get('/email-status', (req, res) => {
  try {
    const config = {
      service: process.env.EMAIL_SERVICE || 'not set',
      host: process.env.EMAIL_HOST || 'not set',
      port: process.env.EMAIL_PORT || 'not set',
      user: process.env.EMAIL_USER ? 'configured' : 'not set',
      password: process.env.EMAIL_PASS ? 'configured' : 'not set',
      fromAddress: process.env.EMAIL_FROM_ADDRESS || 'not set',
      fromName: process.env.EMAIL_FROM_NAME || 'not set',
      debug: process.env.EMAIL_DEBUG || 'false',
      mockService: process.env.MOCK_EMAIL_SERVICE || 'false'
    };

    const isGmailConfigured = config.service === 'gmail' && 
                             config.user === 'configured' && 
                             config.password === 'configured';

    const diagnostics = {
      gmail_ready: isGmailConfigured,
      configuration: config,
      recommendations: isGmailConfigured ? 
        ['✅ Gmail SMTP is configured', '✅ Ready to send OTP emails'] :
        [
          '⚠️ Set EMAIL_SERVICE=gmail',
          '⚠️ Configure EMAIL_USER with your Gmail address',
          '⚠️ Set EMAIL_PASS with your Gmail app password',
          '🔗 Generate app password at: https://myaccount.google.com/apppasswords'
        ],
      troubleshooting: [
        'If emails go to spam, add sender to contacts',
        'Gmail app passwords bypass "less secure app" restrictions',
        'Check server logs for detailed SMTP errors',
        'Test with /api/test/send-test-email endpoint'
      ]
    };

    res.json({
      success: true,
      message: 'Email service configuration status',
      ...diagnostics,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ Email status error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving email status',
      error: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined
    });
  }
});

// Test OAuth configuration
router.get('/oauth-status', (req, res) => {
  try {
    const oauthConfig = {
      socialLoginEnabled: process.env.ENABLE_SOCIAL_LOGIN === 'true',
      google: {
        configured: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
        clientId: process.env.GOOGLE_CLIENT_ID ? 'set' : 'not set',
        clientSecret: process.env.GOOGLE_CLIENT_SECRET ? 'set' : 'not set',
        callbackUrl: process.env.GOOGLE_CALLBACK_URL || 'using default',
        testUrl: process.env.GOOGLE_CLIENT_ID ? 
          `http://localhost:5000/api/auth/google` : 'not available'
      },
      facebook: {
        configured: !!(process.env.FACEBOOK_CLIENT_ID && process.env.FACEBOOK_CLIENT_SECRET),
        clientId: process.env.FACEBOOK_CLIENT_ID ? 'set' : 'not set',
        clientSecret: process.env.FACEBOOK_CLIENT_SECRET ? 'set' : 'not set',
        callbackUrl: process.env.FACEBOOK_CALLBACK_URL || 'using default',
        testUrl: process.env.FACEBOOK_CLIENT_ID ? 
          `http://localhost:5000/api/auth/facebook` : 'not available'
      }
    };

    const recommendations = [];
    
    if (!oauthConfig.socialLoginEnabled) {
      recommendations.push('⚠️ Enable social login: Set ENABLE_SOCIAL_LOGIN=true');
    }
    
    if (!oauthConfig.google.configured) {
      recommendations.push('⚠️ Configure Google OAuth credentials');
    } else {
      recommendations.push('✅ Google OAuth is ready');
    }
    
    if (!oauthConfig.facebook.configured) {
      recommendations.push('⚠️ Configure Facebook OAuth credentials');
      recommendations.push('🔗 Setup guide: https://developers.facebook.com/');
    } else {
      recommendations.push('✅ Facebook OAuth is ready');
    }

    res.json({
      success: true,
      message: 'OAuth configuration status',
      configuration: oauthConfig,
      recommendations,
      setup_instructions: {
        google: 'Already configured with valid credentials',
        facebook: 'Need to set FACEBOOK_CLIENT_ID and FACEBOOK_CLIENT_SECRET'
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ OAuth status error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving OAuth status',
      error: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined
    });
  }
});

// Test forgot password flow end-to-end
router.post('/test-forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email address is required'
      });
    }

    console.log(`🧪 Testing forgot password flow for: ${email}`);

    // Simulate the forgot password flow
    const testOtp = Math.floor(100000 + Math.random() * 900000).toString();
    
    const emailSent = await emailService.sendPasswordResetOTP(email, 'Test User', testOtp);

    res.json({
      success: emailSent,
      message: emailSent ? 
        'Password reset OTP sent successfully' : 
        'Failed to send password reset OTP',
      testData: {
        email,
        otp: testOtp,
        expiry: '10 minutes',
        note: 'This is a test OTP - do not use for actual password reset'
      },
      instructions: emailSent ? [
        'Check your email inbox for the OTP',
        'Check spam folder if not in inbox',
        'OTP format: 6-digit number',
        'Valid for 10 minutes'
      ] : [
        'Check server logs for SMTP errors',
        'Verify email configuration',
        'Test basic email sending first'
      ],
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ Test forgot password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while testing forgot password',
      error: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined
    });
  }
});

export default router;