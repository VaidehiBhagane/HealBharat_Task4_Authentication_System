import express from 'express';
import { User } from '../models/User';
import { OTP } from '../models/OTP';
import mongoose from 'mongoose';

const router = express.Router();

// @route   GET /api/system/health
// @desc    System health check
// @access  Public
router.get('/health', async (req, res) => {
  try {
    const healthStatus = {
      status: 'ok',
      timestamp: new Date().toISOString(),
      services: {
        database: {
          status: 'unknown',
          responseTime: 0
        },
        email: {
          status: 'ok',
          provider: process.env.EMAIL_HOST || 'ethereal'
        },
        sms: {
          status: process.env.TWILIO_ACCOUNT_SID ? 'configured' : 'not-configured',
          provider: 'twilio'
        }
      },
      stats: {
        totalUsers: 0,
        activeUsers: 0,
        verifiedUsers: 0,
        adminUsers: 0
      }
    };

    // Check database connection
    const dbStart = Date.now();
    try {
      await User.findOne({}).limit(1);
      healthStatus.services.database.status = 'connected';
      healthStatus.services.database.responseTime = Date.now() - dbStart;
    } catch (error) {
      healthStatus.services.database.status = 'disconnected';
      healthStatus.status = 'degraded';
    }

    // Get basic stats
    try {
      const [totalUsers, activeUsers, verifiedUsers, adminUsers] = await Promise.all([
        User.countDocuments(),
        User.countDocuments({ isActive: true }),
        User.countDocuments({ isEmailVerified: true }),
        User.countDocuments({ role: 'admin' })
      ]);

      healthStatus.stats = {
        totalUsers,
        activeUsers,
        verifiedUsers,
        adminUsers
      };
    } catch (error) {
      console.error('Stats collection error:', error);
    }

    res.json({
      success: true,
      data: healthStatus
    });
  } catch (error: any) {
    console.error('Health check error:', error);
    res.status(500).json({
      success: false,
      status: 'error',
      message: 'Health check failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// @route   GET /api/system/metrics
// @desc    System metrics and analytics
// @access  Private (Admin only)
router.get('/metrics', async (req, res) => {
  try {
    const now = new Date();
    const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const last7d = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const last30d = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const metrics = {
      users: {
        total: await User.countDocuments(),
        active: await User.countDocuments({ isActive: true }),
        verified: await User.countDocuments({ isEmailVerified: true }),
        phoneVerified: await User.countDocuments({ isPhoneVerified: true }),
        admins: await User.countDocuments({ role: 'admin' }),
        registrations: {
          last24h: await User.countDocuments({ createdAt: { $gte: last24h } }),
          last7d: await User.countDocuments({ createdAt: { $gte: last7d } }),
          last30d: await User.countDocuments({ createdAt: { $gte: last30d } })
        },
        logins: {
          last24h: await User.countDocuments({ lastLogin: { $gte: last24h } }),
          last7d: await User.countDocuments({ lastLogin: { $gte: last7d } }),
          last30d: await User.countDocuments({ lastLogin: { $gte: last30d } })
        }
      },
      security: {
        failedAttempts: await User.countDocuments({ loginAttempts: { $gt: 0 } }),
        lockedAccounts: await User.countDocuments({ lockUntil: { $gt: now } }),
        pendingVerifications: await User.countDocuments({ isEmailVerified: false })
      },
      otp: {
        activeOTPs: await OTP.countDocuments({ expiresAt: { $gt: now } }),
        expiredOTPs: await OTP.countDocuments({ expiresAt: { $lte: now } })
      }
    };

    res.json({
      success: true,
      data: metrics
    });
  } catch (error: any) {
    console.error('Metrics error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve metrics'
    });
  }
});

// @route   POST /api/system/cleanup
// @desc    Cleanup expired tokens and sessions
// @access  Private (Admin only)
router.post('/cleanup', async (req, res) => {
  try {
    const now = new Date();
    
    // Clean up expired OTPs
    const otpCleanup = await OTP.deleteMany({ expiresAt: { $lte: now } });
    
    // Clean up expired email verification tokens
    const userCleanup = await User.updateMany(
      { 
        emailVerificationExpires: { $lte: now },
        isEmailVerified: false 
      },
      { 
        $unset: { 
          emailVerificationToken: 1,
          emailVerificationExpires: 1 
        } 
      }
    );

    // Clean up expired password reset tokens
    const passwordResetCleanup = await User.updateMany(
      { passwordResetExpires: { $lte: now } },
      { 
        $unset: { 
          passwordResetToken: 1,
          passwordResetExpires: 1 
        } 
      }
    );

    res.json({
      success: true,
      message: 'Cleanup completed successfully',
      data: {
        expiredOTPs: otpCleanup.deletedCount,
        cleanedUsers: userCleanup.modifiedCount,
        passwordResetTokens: passwordResetCleanup.modifiedCount
      }
    });
  } catch (error: any) {
    console.error('Cleanup error:', error);
    res.status(500).json({
      success: false,
      message: 'Cleanup failed'
    });
  }
});

export default router;