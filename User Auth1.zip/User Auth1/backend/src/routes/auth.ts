import express from 'express';
import passport from 'passport';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { User, IUser } from '../models/User';
import { tokenService } from '../utils/tokenService';
import { logOAuthFlow } from '../utils/oauthDebug';
import { authenticate } from '../middleware/auth';
import { smsService } from '../services/smsService';

const router = express.Router();

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
router.post('/register', async (req, res) => {
  try {
    const { firstName, lastName, email, password, phoneNumber } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email'
      });
    }

    // Create new user
    const user = new User({
      firstName,
      lastName,
      email: email.toLowerCase(),
      password,
      phoneNumber,
      provider: 'local',
      isEmailVerified: false,
      isActive: true,
      role: 'user'
    });

    await user.save();

    // Generate email verification token
    const verificationToken = user.generateEmailVerificationToken();
    await user.save();

    // Send verification email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendEmailVerification(
      user.email,
      user.firstName,
      verificationToken
    );

    if (!emailSent) {
      console.warn('Failed to send verification email to:', user.email);
    }

    res.status(201).json({
      success: true,
      message: 'User registered successfully. Please check your email to verify your account.',
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          isEmailVerified: user.isEmailVerified
        },
        requiresEmailVerification: true,
        emailSent
      }
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// @route   POST /api/auth/login
// @desc    Login user with email and password
// @access  Public
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || !user.password) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if account is locked
    if (user.isAccountLocked()) {
      return res.status(423).json({
        success: false,
        message: 'Account is temporarily locked due to too many failed attempts'
      });
    }

    // Check if email is verified
    if (!user.isEmailVerified) {
      return res.status(400).json({
        success: false,
        message: 'Please verify your email address first',
        requiresEmailVerification: true
      });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      // Increment failed attempts
      await user.incLoginAttempts();
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if OTP is required (bypass for admin users in development and specific environment setting)
    const isAdminBypass = user.role === 'admin' && 
                         (process.env.NODE_ENV === 'development' || process.env.ADMIN_BYPASS_OTP === 'true');
    const otpRequired = process.env.ENABLE_OTP_VERIFICATION !== 'false' && !isAdminBypass;
    
    if (otpRequired) {
      // Generate and send OTP instead of direct login
      const otp = user.generateLoginOTP();
      await user.save();

      // Send OTP via email
      const { emailService } = await import('../services/emailService');
      const emailSent = await emailService.sendLoginOTP(user.email, user.firstName, otp);
      
      // Send OTP via SMS if phone number is available
      let smsSent = false;
      if (user.phoneNumber && user.isPhoneVerified) {
        smsSent = await smsService.sendLoginOTP(user.phoneNumber, user.firstName, otp);
      }

      return res.json({
        success: true,
        message: 'OTP sent to your registered email' + (smsSent ? ' and phone number' : '') + '. Please verify to complete login.',
        data: {
          requiresOTP: true,
          userId: user._id,
          emailSent,
          smsSent,
          hasPhone: !!user.phoneNumber
        }
      });
    }

    // Direct login without OTP (fallback)
    await user.resetLoginAttempts();
    user.lastLogin = new Date();
    await user.save();

    // Generate tokens
    const tokens = tokenService.generateTokenPair(user);

    // Add refresh token to user
    user.refreshTokens.push(tokens.refreshToken);
    await user.save();

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
          profilePicture: user.profilePicture
        },
        tokens
      }
    });
  } catch (error: any) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/auth/google
// @desc    Initiate Google OAuth
// @access  Public
router.get('/google', 
  logOAuthFlow('Google OAuth Initiation'),
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

// @route   GET /api/auth/google/callback
// @desc    Google OAuth callback
// @access  Public
router.get('/google/callback', 
  logOAuthFlow('Google OAuth Callback'),
  passport.authenticate('google', { failureRedirect: '/login?error=oauth_failed' }),
  async (req: any, res) => {
    try {
      const user = req.user as IUser;
      
      // Generate tokens
      const tokens = tokenService.generateTokenPair(user);

      // Add refresh token to user
      user.refreshTokens.push(tokens.refreshToken);
      await user.save();

      // Redirect to frontend with tokens
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      const redirectUrl = `${frontendUrl}/auth/callback?token=${tokens.accessToken}&refresh=${tokens.refreshToken}`;
      
      res.redirect(redirectUrl);
    } catch (error: any) {
      console.error('Google callback error:', error);
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      res.redirect(`${frontendUrl}/login?error=oauth_failed`);
    }
  }
);

// @route   GET /api/auth/facebook
// @desc    Initiate Facebook OAuth
// @access  Public
router.get('/facebook', 
  passport.authenticate('facebook', { scope: ['email'] })
);

// @route   GET /api/auth/facebook/callback
// @desc    Facebook OAuth callback
// @access  Public
router.get('/facebook/callback',
  passport.authenticate('facebook', { failureRedirect: '/login?error=oauth_failed' }),
  async (req: any, res) => {
    try {
      const user = req.user as IUser;
      
      // Generate tokens
      const tokens = tokenService.generateTokenPair(user);

      // Add refresh token to user
      user.refreshTokens.push(tokens.refreshToken);
      await user.save();

      // Redirect to frontend with tokens
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      const redirectUrl = `${frontendUrl}/auth/callback?token=${tokens.accessToken}&refresh=${tokens.refreshToken}`;
      
      res.redirect(redirectUrl);
    } catch (error: any) {
      console.error('Facebook callback error:', error);
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      res.redirect(`${frontendUrl}/login?error=oauth_failed`);
    }
  }
);

// @route   POST /api/auth/refresh
// @desc    Refresh access token
// @access  Public
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token required'
      });
    }

    // Verify refresh token
    const decoded = tokenService.verifyRefreshToken(refreshToken);

    // Find user and check if refresh token exists
    const user = await User.findById(decoded.userId);
    if (!user || !user.refreshTokens.includes(refreshToken)) {
      return res.status(403).json({
        success: false,
        message: 'Invalid refresh token'
      });
    }

    // Generate new tokens
    const tokens = tokenService.generateTokenPair(user);

    // Replace old refresh token with new one
    user.refreshTokens = user.refreshTokens.filter(token => token !== refreshToken);
    user.refreshTokens.push(tokens.refreshToken);
    await user.save();

    res.json({
      success: true,
      data: tokens
    });
  } catch (error: any) {
    console.error('Refresh token error:', error);
    res.status(403).json({
      success: false,
      message: 'Invalid refresh token'
    });
  }
});

// @route   POST /api/auth/logout
// @desc    Logout user and invalidate refresh token
// @access  Private
router.post('/logout', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    const authHeader = req.headers.authorization;

    if (!refreshToken || !authHeader) {
      return res.status(400).json({
        success: false,
        message: 'Refresh token and access token required'
      });
    }

    // Extract access token
    const accessToken = authHeader.split(' ')[1];
    
    // Verify access token to get user ID
    const decoded = tokenService.verifyAccessToken(accessToken);

    // Remove refresh token from user
    const user = await User.findById(decoded.userId);
    if (user) {
      user.refreshTokens = user.refreshTokens.filter(token => token !== refreshToken);
      await user.save();
    }

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error: any) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user profile
// @access  Private
router.get('/me', passport.authenticate('jwt', { session: false }), async (req: any, res) => {
  try {
    const user = req.user as IUser;
    
    res.json({
      success: true,
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
          isPhoneVerified: user.isPhoneVerified,
          profilePicture: user.profilePicture,
          bio: user.bio,
          lastLogin: user.lastLogin,
          createdAt: user.createdAt
        }
      }
    });
  } catch (error: any) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/auth/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', passport.authenticate('jwt', { session: false }), async (req: any, res) => {
  try {
    const user = req.user as IUser;
    const { firstName, lastName, bio, phoneNumber } = req.body;

    // Update user profile
    const updatedUser = await User.findByIdAndUpdate(
      user._id,
      {
        ...(firstName && { firstName }),
        ...(lastName && { lastName }),
        ...(bio !== undefined && { bio }),
        ...(phoneNumber && { phoneNumber }),
        updatedAt: new Date()
      },
      { new: true, select: '-password -refreshTokens' }
    );

    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user: {
          id: updatedUser._id,
          firstName: updatedUser.firstName,
          lastName: updatedUser.lastName,
          email: updatedUser.email,
          role: updatedUser.role,
          isEmailVerified: updatedUser.isEmailVerified,
          isPhoneVerified: updatedUser.isPhoneVerified,
          profilePicture: updatedUser.profilePicture,
          bio: updatedUser.bio,
          lastLogin: updatedUser.lastLogin,
          createdAt: updatedUser.createdAt
        }
      }
    });
  } catch (error: any) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/auth/verify-email/:token
// @desc    Verify user email address
// @access  Public
router.get('/verify-email/:token', async (req, res) => {
  try {
    const { token } = req.params;
    
    // Hash the token to compare with stored hash
    const crypto = require('crypto');
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    
    // Find user with valid token
    const user = await User.findOne({
      emailVerificationToken: hashedToken,
      emailVerificationExpires: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired verification token'
      });
    }

    // Verify the user's email
    user.isEmailVerified = true;
    user.emailVerificationToken = undefined;
    user.emailVerificationExpires = undefined;
    await user.save();

    // Send welcome email
    const { emailService } = await import('../services/emailService');
    await emailService.sendWelcomeEmail(user.email, user.firstName);

    res.json({
      success: true,
      message: 'Email verified successfully! Welcome to Auth System.'
    });
  } catch (error: any) {
    console.error('Email verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/resend-verification
// @desc    Resend email verification
// @access  Public
router.post('/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({
        success: false,
        message: 'Email is already verified'
      });
    }

    // Generate new verification token
    const verificationToken = user.generateEmailVerificationToken();
    await user.save();

    // Send verification email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendEmailVerification(
      user.email,
      user.firstName,
      verificationToken
    );

    res.json({
      success: true,
      message: 'Verification email sent successfully',
      emailSent
    });
  } catch (error: any) {
    console.error('Resend verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/send-login-otp
// @desc    Send OTP for login verification to both email and SMS
// @access  Public
router.post('/send-login-otp', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user and verify password
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || !user.password) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if email is verified
    if (!user.isEmailVerified) {
      return res.status(400).json({
        success: false,
        message: 'Please verify your email address first',
        requiresEmailVerification: true
      });
    }

    // Verify password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      await user.incLoginAttempts();
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Generate and save OTP
    const otp = user.generateLoginOTP();
    await user.save();

    // Send OTP via email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendLoginOTP(user.email, user.firstName, otp);
    
    // Send OTP via SMS if phone number is available and verified
    let smsSent = false;
    if (user.phoneNumber && user.isPhoneVerified) {
      smsSent = await smsService.sendLoginOTP(user.phoneNumber, user.firstName, otp);
    }

    res.json({
      success: true,
      message: 'OTP sent to your registered email' + (smsSent ? ' and phone number' : ''),
      data: {
        userId: user._id,
        emailSent,
        smsSent,
        hasPhone: !!user.phoneNumber
      }
    });
  } catch (error: any) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/verify-login-otp
// @desc    Verify OTP and complete login
// @access  Public
router.post('/verify-login-otp', async (req, res) => {
  try {
    const { userId, otp } = req.body;

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if OTP is valid and not expired
    if (!user.loginOTP || user.loginOTP !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP'
      });
    }

    if (!user.otpExpires || user.otpExpires < new Date()) {
      return res.status(400).json({
        success: false,
        message: 'OTP has expired. Please request a new one.'
      });
    }

    // Reset failed attempts and clear OTP
    await user.resetLoginAttempts();
    user.lastLogin = new Date();
    user.loginOTP = undefined;
    user.otpExpires = undefined;
    user.otpVerified = true;
    await user.save();

    // Generate tokens
    const tokens = tokenService.generateTokenPair(user);

    // Add refresh token to user
    user.refreshTokens.push(tokens.refreshToken);
    await user.save();

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
          profilePicture: user.profilePicture
        },
        tokens
      }
    });
  } catch (error: any) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/resend-otp
// @desc    Resend OTP for login verification to both email and SMS
// @access  Public
router.post('/resend-otp', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: 'User ID is required'
      });
    }

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Generate new OTP
    const otp = user.generateLoginOTP();
    await user.save();

    // Send OTP via email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendLoginOTP(
      user.email,
      user.firstName,
      otp
    );
    
    // Send OTP via SMS if phone number is available and verified
    let smsSent = false;
    if (user.phoneNumber && user.isPhoneVerified) {
      smsSent = await smsService.sendLoginOTP(user.phoneNumber, user.firstName, otp);
    }

    res.json({
      success: true,
      message: 'New OTP sent to your registered email' + (smsSent ? ' and phone number' : ''),
      data: {
        emailSent,
        smsSent,
        hasPhone: !!user.phoneNumber
      }
    });
  } catch (error: any) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/auth/check-admin
// @desc    Check if current user is admin (for showing admin button)
// @access  Private
router.get('/check-admin', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;
    
    const user = await User.findById(userId).select('role');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: {
        isAdmin: user.role === 'admin'
      }
    });
  } catch (error: any) {
    console.error('Check admin error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(process.cwd(), 'uploads', 'profiles');
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `profile-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// @route   PATCH /api/auth/profile
// @desc    Update user profile
// @access  Private
router.patch('/profile', authenticate, upload.single('profilePicture'), async (req, res) => {
  try {
    const userId = (req as any).user.id;
    const { firstName, lastName, phoneNumber, bio } = req.body;
    
    // Find user
    const user = await User.findById(userId).select('-password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update fields if provided
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (phoneNumber) user.phoneNumber = phoneNumber;
    if (bio !== undefined) user.bio = bio;
    
    // Handle profile picture upload
    if (req.file) {
      // Delete old profile picture if it exists
      if (user.profilePicture) {
        const oldPicturePath = path.join(process.cwd(), 'uploads', 'profiles', path.basename(user.profilePicture));
        if (fs.existsSync(oldPicturePath)) {
          fs.unlinkSync(oldPicturePath);
        }
      }
      
      // Set new profile picture URL
      user.profilePicture = `/uploads/profiles/${req.file.filename}`;
    }

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          bio: user.bio,
          profilePicture: user.profilePicture,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
          isPhoneVerified: user.isPhoneVerified,
          createdAt: user.createdAt
        }
      }
    });
  } catch (error: any) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/auth/profile
// @desc    Get current user profile
// @access  Private
router.get('/profile', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;
    
    const user = await User.findById(userId).select('-password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: {
        user: {
          id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          bio: user.bio,
          profilePicture: user.profilePicture,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
          isPhoneVerified: user.isPhoneVerified,
          createdAt: user.createdAt,
          lastLogin: user.lastLogin
        }
      }
    });
  } catch (error: any) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/verify-phone
// @desc    Send OTP to verify phone number
// @access  Private
router.post('/verify-phone', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;
    const { phoneNumber } = req.body;

    if (!phoneNumber) {
      return res.status(400).json({
        success: false,
        message: 'Phone number is required'
      });
    }

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update phone number and generate OTP
    user.phoneNumber = phoneNumber;
    user.isPhoneVerified = false;
    const otp = user.generateLoginOTP();
    await user.save();

    // Send OTP via SMS
    const smsSent = await smsService.sendRegistrationOTP(phoneNumber, user.firstName, otp);

    res.json({
      success: true,
      message: smsSent ? 
        'OTP sent to your phone number. Please verify to complete phone verification.' :
        'Phone number updated. SMS service not available in development mode.',
      data: {
        smsSent,
        userId: user._id
      }
    });
  } catch (error: any) {
    console.error('Phone verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/verify-phone-otp
// @desc    Verify phone OTP
// @access  Private
router.post('/verify-phone-otp', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;
    const { otp } = req.body;

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if OTP is valid and not expired
    if (!user.loginOTP || user.loginOTP !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP'
      });
    }

    if (!user.otpExpires || user.otpExpires < new Date()) {
      return res.status(400).json({
        success: false,
        message: 'OTP has expired. Please request a new one.'
      });
    }

    // Mark phone as verified and clear OTP
    user.isPhoneVerified = true;
    user.loginOTP = undefined;
    user.otpExpires = undefined;
    user.otpVerified = true;
    await user.save();

    res.json({
      success: true,
      message: 'Phone number verified successfully',
      data: {
        isPhoneVerified: true
      }
    });
  } catch (error: any) {
    console.error('Verify phone OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/forgot-password
// @desc    Request password reset with OTP
// @access  Public
router.post('/forgot-password', async (req, res) => {
  try {
    const { identifier } = req.body;

    if (!identifier) {
      return res.status(400).json({
        success: false,
        message: 'Email address is required'
      });
    }

    // Only support email for OTP-based reset
    if (!identifier.includes('@')) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address'
      });
    }

    // Find user by email
    const user = await User.findOne({ email: identifier.toLowerCase() });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found with this email address'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(400).json({
        success: false,
        message: 'Account is deactivated. Please contact support.'
      });
    }

    // Generate OTP for email reset
    const otp = user.generateLoginOTP(); // Reuse existing OTP method
    await user.save();

    // Send OTP via email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendPasswordResetOTP(
      user.email,
      user.firstName,
      otp
    );

    res.json({
      success: true,
      message: 'Password reset code sent to your email address',
      data: {
        method: 'email',
        emailSent,
        identifier: user.email,
        userId: user._id
      }
    });
  } catch (error: any) {
    console.error('Forgot password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/forgot-password/resend
// @desc    Resend password reset OTP
// @access  Public
router.post('/forgot-password/resend', async (req, res) => {
  try {
    const { identifier, userId } = req.body;

    if (!identifier) {
      return res.status(400).json({
        success: false,
        message: 'Email address is required'
      });
    }

    let user;
    
    // Find user by identifier or userId
    if (userId) {
      user = await User.findById(userId);
    } else {
      user = await User.findOne({ email: identifier.toLowerCase() });
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Generate new OTP
    const otp = user.generateLoginOTP();
    await user.save();

    // Resend OTP via email
    const { emailService } = await import('../services/emailService');
    const emailSent = await emailService.sendPasswordResetOTP(
      user.email,
      user.firstName,
      otp
    );

    res.json({
      success: true,
      message: 'Password reset code resent to your email address',
      data: {
        method: 'email',
        emailSent
      }
    });
  } catch (error: any) {
    console.error('Resend password reset error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/verify-reset-otp
// @desc    Verify OTP for password reset
// @access  Public
router.post('/verify-reset-otp', async (req, res) => {
  try {
    const { identifier, otp, userId } = req.body;

    if (!identifier || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Email and OTP are required'
      });
    }

    let user;
    
    // Find user by identifier or userId
    if (userId) {
      user = await User.findById(userId);
    } else {
      user = await User.findOne({ email: identifier.toLowerCase() });
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify OTP
    const isValidOTP = user.verifyLoginOTP(otp);
    
    if (!isValidOTP) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    // Clear the OTP after successful verification
    user.clearLoginOTP();
    
    // Generate a temporary token for password reset
    const resetToken = user.generatePasswordResetToken();
    await user.save();

    res.json({
      success: true,
      message: 'OTP verified successfully',
      data: {
        userId: user._id,
        otpToken: resetToken,
        email: user.email
      }
    });
  } catch (error: any) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/reset-password
// @desc    Reset password with token or OTP
// @access  Public
router.post('/reset-password', async (req, res) => {
  try {
    const { token, otp, password, userId } = req.body;

    if (!password) {
      return res.status(400).json({
        success: false,
        message: 'New password is required'
      });
    }

    if (!token && !otp) {
      return res.status(400).json({
        success: false,
        message: 'Reset token or OTP is required'
      });
    }

    let user;

    if (token) {
      // Email reset with token
      const crypto = require('crypto');
      const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
      
      user = await User.findOne({
        passwordResetToken: hashedToken,
        passwordResetExpires: { $gt: new Date() }
      });

      if (!user) {
        return res.status(400).json({
          success: false,
          message: 'Invalid or expired reset token'
        });
      }
    } else {
      // SMS reset with OTP
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'User ID is required for OTP verification'
        });
      }

      user = await User.findById(userId);
      
      if (!user || !user.loginOTP || user.loginOTP !== otp) {
        return res.status(400).json({
          success: false,
          message: 'Invalid OTP'
        });
      }

      if (!user.otpExpires || user.otpExpires < new Date()) {
        return res.status(400).json({
          success: false,
          message: 'OTP has expired. Please request a new one.'
        });
      }
    }

    // Reset password
    user.password = password; // Will be hashed by pre-save middleware
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    user.loginOTP = undefined;
    user.otpExpires = undefined;
    user.passwordChangedAt = new Date();

    // Reset login attempts
    await user.resetLoginAttempts();
    
    await user.save();

    // Send security alert
    if (user.phoneNumber && user.isPhoneVerified) {
      await smsService.sendSecurityAlert(
        user.phoneNumber,
        user.firstName,
        'password reset'
      );
    }

    res.json({
      success: true,
      message: 'Password reset successful. You can now login with your new password.'
    });
  } catch (error: any) {
    console.error('Reset password error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/auth/verify-reset-token
// @desc    Verify if reset token is valid (for frontend validation)
// @access  Public
router.post('/verify-reset-token', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: 'Reset token is required'
      });
    }

    const crypto = require('crypto');
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    
    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired reset token'
      });
    }

    res.json({
      success: true,
      message: 'Reset token is valid',
      data: {
        email: user.email,
        firstName: user.firstName
      }
    });
  } catch (error: any) {
    console.error('Verify reset token error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

export default router;