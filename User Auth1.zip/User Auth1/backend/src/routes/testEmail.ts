import express from 'express';
import { emailService } from '../services/emailService';

const router = express.Router();

// Test endpoint to verify email configuration
router.post('/test-email', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    console.log('🧪 Testing email delivery to:', email);

    // Send a simple test email
    const result = await emailService.sendEmail({
      to: email,
      subject: '🧪 Email Configuration Test - Auth System',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Email Test</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 2px solid #667eea; border-radius: 10px; }
            .header { text-align: center; color: #667eea; }
            .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Email Configuration Test</h1>
              <p>Auth System - Gmail SMTP</p>
            </div>
            
            <div class="success">
              <strong>✅ Success!</strong> Your Gmail SMTP configuration is working correctly.
            </div>
            
            <p>This test email confirms that:</p>
            <ul>
              <li>📧 Gmail SMTP connection is established</li>
              <li>🔐 Authentication is working</li>
              <li>📮 Emails can be delivered to: <strong>${email}</strong></li>
              <li>🎯 Your OTP system is ready for production</li>
            </ul>
            
            <p><strong>Next steps:</strong></p>
            <ol>
              <li>Test the forgot password flow</li>
              <li>Verify OTP emails arrive in your inbox</li>
              <li>Check spam folder if needed</li>
            </ol>
            
            <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
            <p style="text-align: center; color: #666; font-size: 14px;">
              Generated at: ${new Date().toLocaleString()}<br>
              Auth System - Test Email Service
            </p>
          </div>
        </body>
        </html>
      `
    });

    if (result) {
      console.log('✅ Test email sent successfully');
      res.json({
        success: true,
        message: `Test email sent successfully to ${email}. Check your inbox (and spam folder).`,
        timestamp: new Date().toISOString()
      });
    } else {
      console.log('❌ Test email failed to send');
      res.status(500).json({
        success: false,
        message: 'Failed to send test email. Check server logs for details.'
      });
    }

  } catch (error) {
    console.error('❌ Test email error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while sending test email',
      error: process.env.NODE_ENV === 'development' ? error : undefined
    });
  }
});

// Get email configuration status
router.get('/email-status', (req, res) => {
  const config = {
    service: process.env.EMAIL_SERVICE || 'not set',
    host: process.env.EMAIL_HOST || 'not set',
    port: process.env.EMAIL_PORT || 'not set',
    user: process.env.EMAIL_USER ? 'configured' : 'not set',
    password: process.env.EMAIL_PASS ? 'configured' : 'not set',
    fromAddress: process.env.EMAIL_FROM_ADDRESS || 'not set',
    fromName: process.env.EMAIL_FROM_NAME || 'not set',
    debug: process.env.EMAIL_DEBUG || 'false'
  };

  const isGmailConfigured = config.service === 'gmail' && 
                           config.user === 'configured' && 
                           config.password === 'configured';

  res.json({
    success: true,
    message: 'Email configuration status',
    gmail_ready: isGmailConfigured,
    configuration: config,
    recommendations: isGmailConfigured ? 
      ['Gmail SMTP is configured', 'Ready to send OTP emails'] :
      [
        'Set EMAIL_SERVICE=gmail',
        'Configure EMAIL_USER with your Gmail address',
        'Set EMAIL_PASS with your Gmail app password',
        'Generate app password at: https://myaccount.google.com/apppasswords'
      ]
  });
});

export default router;