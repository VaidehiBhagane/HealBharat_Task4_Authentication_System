import express from 'express';
import { authenticate, requireAdmin } from '../middleware/auth';
import { adminController } from '../controllers/adminController';
import { rateLimitAdmin, rateLimitExport } from '../middleware/rateLimiting';
import { validateAdminRequest } from '../middleware/validation';
import { csrfProtection, validateAdminSession, sanitizeInput } from '../middleware/security';

const router = express.Router();

// Apply security middleware to all admin routes
router.use(sanitizeInput);
router.use(authenticate);
router.use(requireAdmin);
router.use(validateAdminSession);
router.use(rateLimitAdmin);
router.use(csrfProtection);

// User Management Endpoints
router.get('/users', validateAdminRequest.getUserList, adminController.getUsers);
router.get('/users/:id', validateAdminRequest.getUserById, adminController.getUserById);
router.get('/users/:id/detailed', validateAdminRequest.getUserById, adminController.getDetailedUserProfile);
router.put('/users/:id/status', validateAdminRequest.updateUserStatus, adminController.updateUserStatus);
router.post('/users/:id/reset-password', validateAdminRequest.resetPassword, adminController.resetUserPassword);
router.get('/users/:id/logs', validateAdminRequest.getUserLogs, adminController.getUserLogs);
router.post('/users/bulk-update', adminController.bulkUpdateUsers);

// Export Endpoints (with stricter rate limiting)
router.get('/export/users', rateLimitExport, validateAdminRequest.exportUsers, adminController.exportUsers);

// Admin Dashboard Stats
router.get('/stats', adminController.getDashboardStats);
router.get('/analytics', adminController.getUserAnalytics);

// Audit Logs
router.get('/audit-logs', validateAdminRequest.getAuditLogs, adminController.getAuditLogs);

export default router;