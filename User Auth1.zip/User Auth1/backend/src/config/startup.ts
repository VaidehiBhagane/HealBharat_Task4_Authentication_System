import mongoose from 'mongoose';
import { User } from '../models/User';
import bcrypt from 'bcryptjs';

/**
 * Robust startup configuration that ensures:
 * 1. Database connection is established
 * 2. Admin user always exists
 * 3. All essential collections are created
 * 4. Environment variables are validated
 */

export interface StartupResult {
  dbConnected: boolean;
  adminReady: boolean;
  envValidated: boolean;
  errors: string[];
}

export const validateEnvironment = (): string[] => {
  const errors: string[] = [];
  const required = [
    'MONGODB_URI',
    'JWT_ACCESS_SECRET',
    'JWT_REFRESH_SECRET',
    'SESSION_SECRET',
    'GOOGLE_CLIENT_ID',
    'GOOGLE_CLIENT_SECRET',
    'EMAIL_USER',
    'EMAIL_PASS'
  ];

  required.forEach(key => {
    if (!process.env[key]) {
      errors.push(`Missing required environment variable: ${key}`);
    }
  });

  return errors;
};

export const ensureAdminUser = async (): Promise<boolean> => {
  try {
    console.log('🔍 Checking admin user...');
    
    // Check if admin exists
    let admin = await User.findOne({ email: 'admin@test.com' });
    
    if (!admin) {
      console.log('🔧 Creating admin user...');
      
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash('admin123', salt);
      
      admin = new User({
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@test.com',
        password: hashedPassword,
        role: 'admin',
        isEmailVerified: true,
        isActive: true,
        isPhoneVerified: false,
        provider: 'local',
        otpVerified: false,
        loginAttempts: 0,
        twoFactorEnabled: false,
        refreshTokens: [],
        preferences: {
          theme: 'system',
          language: 'en',
          notifications: {
            email: true,
            sms: false,
            push: true,
          },
        },
      });

      await admin.save();
      console.log('✅ Admin user created successfully');
    } else {
      // Ensure admin is active and verified
      if (!admin.isEmailVerified || !admin.isActive || admin.role !== 'admin') {
        admin.isEmailVerified = true;
        admin.isActive = true;
        admin.role = 'admin';
        await admin.save();
        console.log('✅ Admin user updated and activated');
      } else {
        console.log('✅ Admin user already exists and is ready');
      }
    }

    return true;
  } catch (error) {
    console.error('❌ Error ensuring admin user:', error);
    return false;
  }
};

export const connectDatabaseWithRetry = async (maxRetries = 5): Promise<boolean> => {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem';
      
      await mongoose.connect(mongoURI, {
        serverSelectionTimeoutMS: 5000,
        socketTimeoutMS: 45000,
      });

      console.log('✅ MongoDB connected successfully');

      // Setup connection event handlers
      mongoose.connection.on('error', (error) => {
        console.error('❌ MongoDB connection error:', error);
      });

      mongoose.connection.on('disconnected', () => {
        console.warn('⚠️ MongoDB disconnected');
      });

      mongoose.connection.on('reconnected', () => {
        console.log('🔄 MongoDB reconnected');
      });

      return true;
    } catch (error) {
      console.error(`❌ MongoDB connection attempt ${attempt}/${maxRetries} failed:`, error);
      
      if (attempt < maxRetries) {
        console.log(`⏳ Retrying in ${attempt * 2} seconds...`);
        await new Promise(resolve => setTimeout(resolve, attempt * 2000));
      }
    }
  }
  
  return false;
};

export const performStartupChecks = async (): Promise<StartupResult> => {
  console.log('🚀 Performing startup checks...');
  
  const result: StartupResult = {
    dbConnected: false,
    adminReady: false,
    envValidated: false,
    errors: []
  };

  // 1. Validate environment variables
  console.log('🔍 Validating environment variables...');
  const envErrors = validateEnvironment();
  if (envErrors.length === 0) {
    result.envValidated = true;
    console.log('✅ Environment variables validated');
  } else {
    result.errors.push(...envErrors);
    console.error('❌ Environment validation failed:', envErrors);
  }

  // 2. Connect to database
  console.log('🔍 Connecting to database...');
  result.dbConnected = await connectDatabaseWithRetry();
  
  if (!result.dbConnected) {
    result.errors.push('Failed to connect to database after multiple attempts');
    return result;
  }

  // 3. Ensure admin user exists
  console.log('🔍 Ensuring admin user exists...');
  result.adminReady = await ensureAdminUser();
  
  if (!result.adminReady) {
    result.errors.push('Failed to create or verify admin user');
  }

  // 4. Final validation
  if (result.dbConnected && result.adminReady && result.envValidated) {
    console.log('🎉 All startup checks passed!');
    console.log('📋 System ready with:');
    console.log('   📧 Admin Login: admin@test.com');
    console.log('   🔑 Admin Password: admin123');
    console.log('   🌐 Frontend: http://localhost:3000');
    console.log('   🔌 Backend: http://localhost:5000');
  } else {
    console.error('❌ Startup checks failed:', result.errors);
  }

  return result;
};

export default {
  performStartupChecks,
  ensureAdminUser,
  connectDatabaseWithRetry,
  validateEnvironment
};