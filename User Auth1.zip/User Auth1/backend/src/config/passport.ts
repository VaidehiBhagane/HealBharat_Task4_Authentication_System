import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import { Strategy as JwtStrategy, ExtractJwt } from 'passport-jwt';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import bcrypt from 'bcryptjs';
import { User, IUser } from '../models/User';

/**
 * Configure Passport.js authentication strategies
 * Supports local authentication, JWT tokens, Google OAuth, and Facebook OAuth
 */
export const configurePassport = () => {
  // Serialize user for session
  passport.serializeUser((user: any, done) => {
    done(null, user._id);
  });

  // Deserialize user from session
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await User.findById(id).select('-password');
      done(null, user);
    } catch (error) {
      done(error, null);
    }
  });

  // Local Strategy for email/password authentication
  passport.use(
    new LocalStrategy(
      {
        usernameField: 'email',
        passwordField: 'password',
      },
      async (email: string, password: string, done) => {
        try {
          // Find user by email
          const user = await User.findOne({ email: email.toLowerCase() });
          
          if (!user) {
            return done(null, false, { message: 'Invalid email or password' });
          }

          // Check if user account is active
          if (!user.isActive) {
            return done(null, false, { message: 'Account is deactivated' });
          }

          // Check if account is locked
          if (user.isAccountLocked()) {
            return done(null, false, { message: 'Account is temporarily locked due to too many failed attempts' });
          }

          // Verify password
          if (!user.password) {
            return done(null, false, { message: 'Invalid email or password' });
          }
          
          const isMatch = await bcrypt.compare(password, user.password);
          
          if (!isMatch) {
            // Increment failed login attempts using the model method
            await user.incLoginAttempts();
            return done(null, false, { message: 'Invalid email or password' });
          }

          // Reset failed attempts on successful login
          await user.resetLoginAttempts();
          user.lastLogin = new Date();
          await user.save();

          return done(null, user);
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  // JWT Strategy for API authentication
  passport.use(
    new JwtStrategy(
      {
        jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
        secretOrKey: process.env.JWT_ACCESS_SECRET || 'jwt-secret',
        algorithms: ['HS256'],
      },
      async (payload, done) => {
        try {
          const user = await User.findById(payload.userId).select('-password');
          
          if (!user) {
            return done(null, false);
          }

          // Check if user account is active
          if (!user.isActive) {
            return done(null, false);
          }

          // Check if token was issued before password change
          if (user.passwordChangedAt && payload.iat < Math.floor(user.passwordChangedAt.getTime() / 1000)) {
            return done(null, false);
          }

          return done(null, user);
        } catch (error) {
          return done(error, false);
        }
      }
    )
  );

  // Google OAuth Strategy
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    passport.use(
      new GoogleStrategy(
        {
          clientID: process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          callbackURL: process.env.GOOGLE_CALLBACK_URL || '/api/auth/google/callback',
        },
        async (accessToken: string, refreshToken: string, profile: any, done) => {
          try {
            // Check if user already exists with Google ID
            let user = await User.findOne({ googleId: profile.id });

            if (user) {
              // Update user info if needed
              if (!user.isEmailVerified && profile.emails?.[0]?.verified) {
                user.isEmailVerified = true;
                user.emailVerifiedAt = new Date();
              }
              user.lastLogin = new Date();
              await user.save();
              return done(null, user);
            }

            // Check if user exists with same email
            const email = profile.emails?.[0]?.value;
            if (email) {
              user = await User.findOne({ email: email.toLowerCase() });
              if (user) {
                // Link Google account to existing user
                user.googleId = profile.id;
                user.isEmailVerified = profile.emails?.[0]?.verified || user.isEmailVerified;
                if (profile.emails?.[0]?.verified && !user.emailVerifiedAt) {
                  user.emailVerifiedAt = new Date();
                }
                user.lastLogin = new Date();
                await user.save();
                return done(null, user);
              }
            }

            // Create new user
            const newUser = new User({
              googleId: profile.id,
              firstName: profile.name?.givenName || profile.displayName?.split(' ')[0] || 'User',
              lastName: profile.name?.familyName || profile.displayName?.split(' ').slice(1).join(' ') || '',
              email: email?.toLowerCase(),
              isEmailVerified: profile.emails?.[0]?.verified || false,
              emailVerifiedAt: profile.emails?.[0]?.verified ? new Date() : undefined,
              profilePicture: profile.photos?.[0]?.value,
              provider: 'google',
              providerId: profile.id,
              isActive: true,
              role: 'user',
              lastLogin: new Date(),
            });

            await newUser.save();
            return done(null, newUser);
          } catch (error) {
            return done(error, false);
          }
        }
      )
    );
  }

  // Facebook OAuth Strategy
  if (process.env.FACEBOOK_CLIENT_ID && process.env.FACEBOOK_CLIENT_SECRET) {
    passport.use(
      new FacebookStrategy(
        {
          clientID: process.env.FACEBOOK_CLIENT_ID,
          clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
          callbackURL: process.env.FACEBOOK_CALLBACK_URL || '/api/auth/facebook/callback',
          profileFields: ['id', 'displayName', 'name', 'emails', 'photos'],
        },
        async (accessToken: string, refreshToken: string, profile: any, done) => {
          try {
            // Check if user already exists with Facebook ID
            let user = await User.findOne({ facebookId: profile.id });

            if (user) {
              // Update last login
              user.lastLogin = new Date();
              await user.save();
              return done(null, user);
            }

            // Check if user exists with same email
            const email = profile.emails?.[0]?.value;
            if (email) {
              user = await User.findOne({ email: email.toLowerCase() });
              if (user) {
                // Link Facebook account to existing user
                user.facebookId = profile.id;
                user.lastLogin = new Date();
                await user.save();
                return done(null, user);
              }
            }

            // Create new user
            const newUser = new User({
              facebookId: profile.id,
              firstName: profile.name?.givenName || profile.displayName?.split(' ')[0] || 'User',
              lastName: profile.name?.familyName || profile.displayName?.split(' ').slice(1).join(' ') || '',
              email: email?.toLowerCase(),
              isEmailVerified: false, // Facebook doesn't always provide verified email
              profilePicture: profile.photos?.[0]?.value,
              provider: 'facebook',
              providerId: profile.id,
              isActive: true,
              role: 'user',
              lastLogin: new Date(),
            });

            await newUser.save();
            return done(null, newUser);
          } catch (error) {
            return done(error, false);
          }
        }
      )
    );
  }
};

/**
 * Middleware to authenticate with local strategy
 */
export const authenticateLocal = passport.authenticate('local', {
  session: false,
  failureMessage: true,
});

/**
 * Middleware to authenticate with JWT strategy
 */
export const authenticateJWT = passport.authenticate('jwt', {
  session: false,
});

/**
 * Middleware to authenticate with Google OAuth
 */
export const authenticateGoogle = passport.authenticate('google', {
  scope: ['profile', 'email'],
});

/**
 * Middleware to authenticate Google callback
 */
export const authenticateGoogleCallback = passport.authenticate('google', {
  session: false,
  failureRedirect: `${process.env.CLIENT_URL || 'http://localhost:3000'}/login?error=oauth_failed`,
});

/**
 * Middleware to authenticate with Facebook OAuth
 */
export const authenticateFacebook = passport.authenticate('facebook', {
  scope: ['email'],
});

/**
 * Middleware to authenticate Facebook callback
 */
export const authenticateFacebookCallback = passport.authenticate('facebook', {
  session: false,
  failureRedirect: `${process.env.CLIENT_URL || 'http://localhost:3000'}/login?error=oauth_failed`,
});

/**
 * Optional middleware to check if user is authenticated (for session-based auth)
 */
export const requireAuth = (req: any, res: any, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ success: false, message: 'Authentication required' });
};

/**
 * Middleware to check if user has admin role
 */
export const requireAdmin = (req: any, res: any, next: any) => {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ success: false, message: 'Admin access required' });
};