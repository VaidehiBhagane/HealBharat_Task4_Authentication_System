import { Request, Response, NextFunction } from 'express';
import { User, IUser } from '../models/User';
import { AuditLog } from '../models/AuditLog';
import { UserActivity } from '../models/UserActivity';
import { catchAsync, CustomError } from '../middleware/errorHandler';
import { logger } from '../utils/logger';
import { createHash } from 'crypto';
import { Parser } from 'json2csv';

export const adminController = {
  /**
   * Get paginated list of users with filtering and sorting
   */
  getUsers: catchAsync(async (req: Request, res: Response) => {
    const {
      page = 1,
      limit = 20,
      search,
      status,
      role,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    const pageNum = parseInt(page as string, 10);
    const limitNum = parseInt(limit as string, 10);
    const skip = (pageNum - 1) * limitNum;

    // Build filter query
    const filter: any = {};
    
    if (search) {
      filter.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { phoneNumber: { $regex: search, $options: 'i' } }
      ];
    }

    if (status && status !== 'all') {
      if (status === 'active') {
        filter.isActive = true;
      } else if (status === 'inactive') {
        filter.isActive = false;
      } else if (status === 'verified') {
        filter.isEmailVerified = true;
      } else if (status === 'unverified') {
        filter.isEmailVerified = false;
      }
    }

    if (role && role !== 'all') {
      filter.role = role;
    }

    // Build sort query
    const sort: any = {};
    sort[sortBy as string] = sortOrder === 'desc' ? -1 : 1;

    // Execute queries
    const [users, totalUsers] = await Promise.all([
      User.find(filter)
        .select('-password -twoFactorSecret -passwordResetToken -emailVerificationToken')
        .sort(sort)
        .skip(skip)
        .limit(limitNum)
        .lean(),
      User.countDocuments(filter)
    ]);

    // Calculate pagination info
    const totalPages = Math.ceil(totalUsers / limitNum);
    const hasNextPage = pageNum < totalPages;
    const hasPrevPage = pageNum > 1;

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'VIEW_USERS',
      resourceType: 'USER',
      details: {
        filters: { search, status, role },
        pagination: { page: pageNum, limit: limitNum }
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: {
        users,
        pagination: {
          currentPage: pageNum,
          totalPages,
          totalUsers,
          hasNextPage,
          hasPrevPage,
          limit: limitNum
        }
      }
    });
  }),

  /**
   * Get detailed information about a specific user
   */
  getUserById: catchAsync(async (req: Request, res: Response) => {
    const { id } = req.params;

    const user = await User.findById(id)
      .select('-password -twoFactorSecret -passwordResetToken -emailVerificationToken')
      .lean();

    if (!user) {
      throw new CustomError('User not found', 404);
    }

    // Get recent activity for this user
    const recentActivity = await UserActivity.find({ userId: id })
      .sort({ createdAt: -1 })
      .limit(50)
      .lean();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'VIEW_USER_DETAILS',
      resourceType: 'USER',
      resourceId: id,
      details: { viewedUserId: id },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: {
        user,
        recentActivity
      }
    });
  }),

  /**
   * Update user account status (active/inactive)
   */
  updateUserStatus: catchAsync(async (req: Request, res: Response) => {
    const { id } = req.params;
    const { isActive, reason } = req.body;

    const user = await User.findById(id);
    if (!user) {
      throw new CustomError('User not found', 404);
    }

    // Prevent admins from deactivating themselves
    if (id === req.user!._id.toString()) {
      throw new CustomError('Cannot modify your own account status', 400);
    }

    const previousStatus = user.isActive;
    user.isActive = isActive;
    await user.save();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: isActive ? 'ACTIVATE_USER' : 'DEACTIVATE_USER',
      resourceType: 'USER',
      resourceId: id,
      details: {
        previousStatus,
        newStatus: isActive,
        reason,
        targetUserId: id
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    // Log activity for the user
    await UserActivity.create({
      userId: id,
      action: isActive ? 'ACCOUNT_ACTIVATED' : 'ACCOUNT_DEACTIVATED',
      details: {
        activatedBy: req.user!._id,
        reason
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    logger.info(`Admin ${req.user!.email} ${isActive ? 'activated' : 'deactivated'} user ${user.email}`, {
      adminId: req.user!._id,
      userId: id,
      action: isActive ? 'ACTIVATE_USER' : 'DEACTIVATE_USER'
    });

    res.json({
      success: true,
      message: `User account ${isActive ? 'activated' : 'deactivated'} successfully`,
      data: {
        userId: id,
        isActive
      }
    });
  }),

  /**
   * Reset user password (admin-initiated)
   */
  resetUserPassword: catchAsync(async (req: Request, res: Response) => {
    const { id } = req.params;
    const { temporaryPassword, forceReset = true } = req.body;

    const user = await User.findById(id);
    if (!user) {
      throw new CustomError('User not found', 404);
    }

    // Generate temporary password if not provided
    const newPassword = temporaryPassword || Math.random().toString(36).slice(-12) + 'A1!';

    // Set password and force reset flag
    user.password = newPassword;
    user.passwordResetRequired = forceReset;
    user.passwordResetToken = createHash('sha256').update(Date.now().toString()).digest('hex');
    user.passwordResetExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    await user.save();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'RESET_USER_PASSWORD',
      resourceType: 'USER',
      resourceId: id,
      details: {
        targetUserId: id,
        forceReset,
        hasTemporaryPassword: !!temporaryPassword
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    // Log activity for the user
    await UserActivity.create({
      userId: id,
      action: 'PASSWORD_RESET_BY_ADMIN',
      details: {
        resetBy: req.user!._id,
        forceReset
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    logger.info(`Admin ${req.user!.email} reset password for user ${user.email}`, {
      adminId: req.user!._id,
      userId: id,
      action: 'RESET_USER_PASSWORD'
    });

    res.json({
      success: true,
      message: 'User password reset successfully',
      data: {
        userId: id,
        temporaryPassword: newPassword,
        forceReset
      }
    });
  }),

  /**
   * Get user activity logs
   */
  getUserLogs: catchAsync(async (req: Request, res: Response) => {
    const { id } = req.params;
    const { 
      page = 1, 
      limit = 50, 
      action, 
      startDate, 
      endDate 
    } = req.query;

    const pageNum = parseInt(page as string, 10);
    const limitNum = parseInt(limit as string, 10);
    const skip = (pageNum - 1) * limitNum;

    // Verify user exists
    const user = await User.findById(id);
    if (!user) {
      throw new CustomError('User not found', 404);
    }

    // Build filter
    const filter: any = { userId: id };
    
    if (action) {
      filter.action = action;
    }

    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) {
        filter.createdAt.$gte = new Date(startDate as string);
      }
      if (endDate) {
        filter.createdAt.$lte = new Date(endDate as string);
      }
    }

    // Get logs
    const [logs, totalLogs] = await Promise.all([
      UserActivity.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      UserActivity.countDocuments(filter)
    ]);

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'VIEW_USER_LOGS',
      resourceType: 'USER_ACTIVITY',
      resourceId: id,
      details: {
        targetUserId: id,
        filters: { action, startDate, endDate }
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    const totalPages = Math.ceil(totalLogs / limitNum);

    res.json({
      success: true,
      data: {
        logs,
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName
        },
        pagination: {
          currentPage: pageNum,
          totalPages,
          totalLogs,
          limit: limitNum
        }
      }
    });
  }),

  /**
   * Export users data
   */
  exportUsers: catchAsync(async (req: Request, res: Response) => {
    const { format = 'csv', status, role } = req.query;

    // Build filter
    const filter: any = {};
    
    if (status && status !== 'all') {
      if (status === 'active') {
        filter.isActive = true;
      } else if (status === 'inactive') {
        filter.isActive = false;
      }
    }

    if (role && role !== 'all') {
      filter.role = role;
    }

    // Get users
    const users = await User.find(filter)
      .select('firstName lastName email phoneNumber role isActive isEmailVerified lastLogin createdAt')
      .lean();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'EXPORT_USERS',
      resourceType: 'USER',
      details: {
        format,
        filters: { status, role },
        exportedCount: users.length
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    if (format === 'json') {
      res.json({
        success: true,
        data: {
          users,
          exportedAt: new Date(),
          exportedBy: req.user!.email,
          totalCount: users.length
        }
      });
    } else {
      // CSV export
      const fields = [
        'firstName',
        'lastName', 
        'email',
        'phoneNumber',
        'role',
        'isActive',
        'isEmailVerified',
        'lastLogin',
        'createdAt'
      ];

      const json2csvParser = new Parser({ fields });
      const csv = json2csvParser.parse(users);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=users-export-${new Date().toISOString().split('T')[0]}.csv`);
      res.send(csv);
    }
  }),

  /**
   * Get dashboard statistics
   */
  getDashboardStats: catchAsync(async (req: Request, res: Response) => {
    const [
      totalUsers,
      activeUsers,
      newUsersToday,
      newUsersThisWeek,
      verifiedUsers,
      adminUsers
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isActive: true }),
      User.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
      }),
      User.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      }),
      User.countDocuments({ isEmailVerified: true }),
      User.countDocuments({ role: 'admin' })
    ]);

    // Get recent activity
    const recentActivity = await UserActivity.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('userId', 'firstName lastName email')
      .lean();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'VIEW_DASHBOARD',
      resourceType: 'DASHBOARD',
      details: {},
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: {
        stats: {
          totalUsers,
          activeUsers,
          inactiveUsers: totalUsers - activeUsers,
          newUsersToday,
          newUsersThisWeek,
          verifiedUsers,
          unverifiedUsers: totalUsers - verifiedUsers,
          adminUsers
        },
        recentActivity
      }
    });
  }),

  /**
   * Get audit logs
   */
  getAuditLogs: catchAsync(async (req: Request, res: Response) => {
    const {
      page = 1,
      limit = 50,
      action,
      adminId,
      startDate,
      endDate
    } = req.query;

    const pageNum = parseInt(page as string, 10);
    const limitNum = parseInt(limit as string, 10);
    const skip = (pageNum - 1) * limitNum;

    // Build filter
    const filter: any = {};
    
    if (action) {
      filter.action = action;
    }

    if (adminId) {
      filter.adminId = adminId;
    }

    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) {
        filter.createdAt.$gte = new Date(startDate as string);
      }
      if (endDate) {
        filter.createdAt.$lte = new Date(endDate as string);
      }
    }

    // Get logs
    const [logs, totalLogs] = await Promise.all([
      AuditLog.find(filter)
        .populate('adminId', 'firstName lastName email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      AuditLog.countDocuments(filter)
    ]);

    const totalPages = Math.ceil(totalLogs / limitNum);

    res.json({
      success: true,
      data: {
        logs,
        pagination: {
          currentPage: pageNum,
          totalPages,
          totalLogs,
          limit: limitNum
        }
      }
    });
  }),

  /**
   * Get comprehensive user analytics
   */
  getUserAnalytics: catchAsync(async (req: Request, res: Response) => {
    const { timeframe = '30d' } = req.query;
    
    let startDate: Date;
    switch (timeframe) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    // User registration trends
    const registrationTrends = await User.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    // User status breakdown
    const statusBreakdown = await User.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          active: {
            $sum: {
              $cond: [{ $eq: ["$isActive", true] }, 1, 0]
            }
          },
          emailVerified: {
            $sum: {
              $cond: [{ $eq: ["$isEmailVerified", true] }, 1, 0]
            }
          },
          phoneVerified: {
            $sum: {
              $cond: [{ $eq: ["$isPhoneVerified", true] }, 1, 0]
            }
          },
          admins: {
            $sum: {
              $cond: [{ $eq: ["$role", "admin"] }, 1, 0]
            }
          },
          twoFactorEnabled: {
            $sum: {
              $cond: [{ $eq: ["$twoFactorEnabled", true] }, 1, 0]
            }
          }
        }
      }
    ]);

    // Provider breakdown
    const providerBreakdown = await User.aggregate([
      {
        $group: {
          _id: "$provider",
          count: { $sum: 1 }
        }
      }
    ]);

    // Recent activity summary
    const recentLogins = await User.aggregate([
      {
        $match: {
          lastLogin: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$lastLogin" }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.json({
      success: true,
      data: {
        timeframe,
        registrationTrends,
        statusBreakdown: statusBreakdown[0] || {},
        providerBreakdown,
        recentLogins
      }
    });
  }),

  /**
   * Bulk update users
   */
  bulkUpdateUsers: catchAsync(async (req: Request, res: Response) => {
    const { userIds, action, data } = req.body;

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      throw new CustomError('User IDs are required', 400);
    }

    if (!action) {
      throw new CustomError('Action is required', 400);
    }

    let updateQuery: any = {};
    let actionDescription = '';

    switch (action) {
      case 'activate':
        updateQuery = { isActive: true };
        actionDescription = 'Activated users';
        break;
      case 'deactivate':
        updateQuery = { isActive: false };
        actionDescription = 'Deactivated users';
        break;
      case 'verify-email':
        updateQuery = { isEmailVerified: true, emailVerifiedAt: new Date() };
        actionDescription = 'Verified email for users';
        break;
      case 'update-role':
        if (!data.role || !['user', 'admin'].includes(data.role)) {
          throw new CustomError('Valid role is required', 400);
        }
        updateQuery = { role: data.role };
        actionDescription = `Updated role to ${data.role}`;
        break;
      default:
        throw new CustomError('Invalid action', 400);
    }

    // Prevent admin from modifying their own account in bulk operations
    const filteredUserIds = userIds.filter(id => id !== req.user!._id.toString());

    if (filteredUserIds.length === 0) {
      throw new CustomError('Cannot perform bulk operations on your own account', 400);
    }

    // Perform bulk update
    const result = await User.updateMany(
      { _id: { $in: filteredUserIds } },
      { $set: updateQuery }
    );

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'BULK_UPDATE_USERS',
      resourceType: 'USER',
      details: {
        action,
        userIds: filteredUserIds,
        updateQuery,
        modifiedCount: result.modifiedCount
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    logger.info(`Admin ${req.user!.email} performed bulk action: ${action} on ${filteredUserIds.length} users`, {
      adminId: req.user!._id,
      action: 'BULK_UPDATE_USERS',
      affectedUsers: filteredUserIds.length
    });

    res.json({
      success: true,
      message: `${actionDescription} for ${result.modifiedCount} users`,
      data: {
        modifiedCount: result.modifiedCount,
        requestedCount: filteredUserIds.length
      }
    });
  }),

  /**
   * Get detailed user profile with all associated data
   */
  getDetailedUserProfile: catchAsync(async (req: Request, res: Response) => {
    const { id } = req.params;

    // Get user with all non-sensitive fields
    const user = await User.findById(id)
      .select('-password -twoFactorSecret -passwordResetToken -emailVerificationToken -refreshTokens')
      .lean();

    if (!user) {
      throw new CustomError('User not found', 404);
    }

    // Get user activity count by action type
    const activitySummary = await UserActivity.aggregate([
      { $match: { userId: id } },
      {
        $group: {
          _id: '$action',
          count: { $sum: 1 },
          lastOccurrence: { $max: '$createdAt' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    // Get recent login history
    const loginHistory = await UserActivity.find({
      userId: id,
      action: { $in: ['LOGIN_SUCCESS', 'LOGIN_FAILED', 'LOGOUT'] }
    })
      .sort({ createdAt: -1 })
      .limit(20)
      .lean();

    // Get security events
    const securityEvents = await UserActivity.find({
      userId: id,
      action: { 
        $in: [
          'PASSWORD_CHANGED', 
          'EMAIL_CHANGED', 
          'TWO_FACTOR_ENABLED', 
          'TWO_FACTOR_DISABLED',
          'ACCOUNT_LOCKED',
          'ACCOUNT_UNLOCKED'
        ] 
      }
    })
      .sort({ createdAt: -1 })
      .limit(10)
      .lean();

    // Log admin action
    await AuditLog.create({
      adminId: req.user!._id,
      action: 'VIEW_DETAILED_USER_PROFILE',
      resourceType: 'USER',
      resourceId: id,
      details: { viewedUserId: id },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: {
        user,
        activitySummary,
        loginHistory,
        securityEvents,
        stats: {
          totalActivities: activitySummary.reduce((sum, item) => sum + item.count, 0),
          loginCount: loginHistory.filter(h => h.action === 'LOGIN_SUCCESS').length,
          failedLoginCount: loginHistory.filter(h => h.action === 'LOGIN_FAILED').length
        }
      }
    });
  })
};