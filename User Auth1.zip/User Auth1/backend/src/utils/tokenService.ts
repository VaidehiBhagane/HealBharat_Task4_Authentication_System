import * as jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { IUser } from '../models/User';

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  iat?: number;
  exp?: number;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

class TokenService {
  private accessTokenSecret: string;
  private refreshTokenSecret: string;
  private accessTokenExpiry: string;
  private refreshTokenExpiry: string;

  constructor() {
    this.accessTokenSecret = process.env.JWT_ACCESS_SECRET || 'access-secret-fallback';
    this.refreshTokenSecret = process.env.JWT_REFRESH_SECRET || 'refresh-secret-fallback';
    this.accessTokenExpiry = process.env.JWT_ACCESS_EXPIRY || '15m';
    this.refreshTokenExpiry = process.env.JWT_REFRESH_EXPIRY || '7d';

    // Warn if using fallback secrets
    if (!process.env.JWT_ACCESS_SECRET || !process.env.JWT_REFRESH_SECRET) {
      console.warn('⚠️ Using fallback JWT secrets. Please set JWT_ACCESS_SECRET and JWT_REFRESH_SECRET in production.');
    }
  }

  /**
   * Generate access token
   */
  generateAccessToken(user: IUser): string {
    const payload: JWTPayload = {
      userId: user._id.toString(),
      email: user.email,
      role: user.role,
    };

    const options = {
      expiresIn: this.accessTokenExpiry,
      issuer: 'auth-system',
      audience: 'auth-system-client',
    };
    
    return jwt.sign(payload, this.accessTokenSecret, options as any);
  }

  /**
   * Generate refresh token
   */
  generateRefreshToken(user: IUser): string {
    const payload = {
      userId: user._id.toString(),
      tokenVersion: Date.now(), // Can be used to invalidate all tokens
    };

    return jwt.sign(payload, this.refreshTokenSecret, {
      expiresIn: this.refreshTokenExpiry,
      issuer: 'auth-system',
      audience: 'auth-system-client',
    } as any);
  }

  /**
   * Generate both access and refresh tokens
   */
  generateTokenPair(user: IUser): TokenPair {
    return {
      accessToken: this.generateAccessToken(user),
      refreshToken: this.generateRefreshToken(user),
    };
  }

  /**
   * Verify access token
   */
  verifyAccessToken(token: string): JWTPayload {
    try {
      return jwt.verify(token, this.accessTokenSecret, {
        issuer: 'auth-system',
        audience: 'auth-system-client',
      }) as JWTPayload;
    } catch (error: any) {
      throw new Error(`Invalid access token: ${error.message}`);
    }
  }

  /**
   * Verify refresh token
   */
  verifyRefreshToken(token: string): any {
    try {
      return jwt.verify(token, this.refreshTokenSecret, {
        issuer: 'auth-system',
        audience: 'auth-system-client',
      });
    } catch (error: any) {
      throw new Error(`Invalid refresh token: ${error.message}`);
    }
  }

  /**
   * Decode token without verification (for debugging)
   */
  decodeToken(token: string): any {
    return jwt.decode(token);
  }

  /**
   * Get token expiration date
   */
  getTokenExpiration(token: string): Date | null {
    try {
      const decoded = this.decodeToken(token);
      if (decoded && decoded.exp) {
        return new Date(decoded.exp * 1000);
      }
      return null;
    } catch {
      return null;
    }
  }

  /**
   * Check if token is expired
   */
  isTokenExpired(token: string): boolean {
    const expiration = this.getTokenExpiration(token);
    if (!expiration) return true;
    return expiration < new Date();
  }

  /**
   * Generate random token for password reset, email verification, etc.
   */
  generateRandomToken(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Hash token for storage (one-way)
   */
  hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Generate secure random OTP
   */
  generateOTP(length: number = 6): string {
    const digits = '0123456789';
    let otp = '';
    
    for (let i = 0; i < length; i++) {
      const randomIndex = crypto.randomInt(0, digits.length);
      otp += digits[randomIndex];
    }
    
    return otp;
  }

  /**
   * Create JWT for specific purpose (email verification, password reset)
   */
  createPurposeToken(payload: object, expiresIn: string = '1h'): string {
    return jwt.sign(payload, this.accessTokenSecret, {
      expiresIn,
      issuer: 'auth-system',
    } as any);
  }

  /**
   * Verify purpose token
   */
  verifyPurposeToken(token: string): any {
    try {
      return jwt.verify(token, this.accessTokenSecret, {
        issuer: 'auth-system',
      });
    } catch (error: any) {
      throw new Error(`Invalid purpose token: ${error.message}`);
    }
  }
}

export const tokenService = new TokenService();
export default tokenService;