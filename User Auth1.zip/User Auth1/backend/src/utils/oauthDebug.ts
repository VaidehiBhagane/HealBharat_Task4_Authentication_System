// OAuth Debug Helper - Place in backend/src/utils/oauthDebug.ts
import { Request, Response, NextFunction } from 'express';

export const logOAuthFlow = (step: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    console.log(`\n🔍 OAuth Debug - ${step}:`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📍 URL:', req.url);
    console.log('🌐 Full URL:', `${req.protocol}://${req.get('host')}${req.originalUrl}`);
    console.log('📊 Query Params:', req.query);
    console.log('🏠 Headers:', {
      'user-agent': req.get('user-agent'),
      'referer': req.get('referer'),
      'host': req.get('host')
    });
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    next();
  };
};

export const logOAuthConfig = () => {
  console.log('\n🔐 OAuth Configuration Check:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🔑 Google Client ID:', process.env.GOOGLE_CLIENT_ID ? '✅ Set' : '❌ Missing');
  console.log('🔒 Google Secret:', process.env.GOOGLE_CLIENT_SECRET ? '✅ Set' : '❌ Missing');
  console.log('🔗 Callback URL:', process.env.GOOGLE_CALLBACK_URL || '/api/auth/google/callback');
  console.log('🌐 Frontend URL:', process.env.FRONTEND_URL || process.env.CLIENT_URL || 'http://localhost:3000');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
};