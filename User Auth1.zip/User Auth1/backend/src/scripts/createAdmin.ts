import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import User model
import { User } from '../models/User';

async function createAdminUser() {
  try {
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB');

    // Check if admin user already exists
    const existingAdmin = await User.findOne({ email: 'admin@test.com' });
    
    if (existingAdmin) {
      console.log('🔍 Admin user already exists. Updating credentials...');
      
      // Update existing admin user
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash('admin123', salt);
      
      existingAdmin.password = hashedPassword;
      existingAdmin.isEmailVerified = true;
      existingAdmin.isActive = true;
      existingAdmin.role = 'admin';
      existingAdmin.passwordChangedAt = new Date();
      
      await existingAdmin.save();
      console.log('✅ Admin user updated successfully');
    } else {
      console.log('🔧 Creating new admin user...');
      
      // Hash password
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash('admin123', salt);
      
      // Create admin user
      const adminUser = new User({
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@test.com',
        password: hashedPassword,
        role: 'admin',
        isEmailVerified: true,
        isActive: true,
        isPhoneVerified: false,
        provider: 'local',
        otpVerified: false,
        loginAttempts: 0,
        twoFactorEnabled: false,
        refreshTokens: [],
        preferences: {
          theme: 'system',
          language: 'en',
          notifications: {
            email: true,
            sms: false,
            push: true,
          },
        },
      });

      await adminUser.save();
      console.log('✅ Admin user created successfully');
    }

    // Verify admin user details
    const admin = await User.findOne({ email: 'admin@test.com' });
    if (admin) {
      console.log('\n📋 Admin User Details:');
      console.log(`   📧 Email: ${admin.email}`);
      console.log(`   👤 Name: ${admin.firstName} ${admin.lastName}`);
      console.log(`   🔑 Role: ${admin.role}`);
      console.log(`   ✅ Email Verified: ${admin.isEmailVerified}`);
      console.log(`   🟢 Active: ${admin.isActive}`);
      console.log(`   🔐 Password Set: ${!!admin.password}`);
      console.log(`   📅 Created: ${admin.createdAt}`);
    }

    console.log('\n🎉 Admin setup complete!');
    console.log('📝 Login Credentials:');
    console.log('   Email: admin@test.com');
    console.log('   Password: admin123');
    console.log('\n🚀 You can now login at: http://localhost:3001/login');

  } catch (error) {
    console.error('❌ Error creating admin user:', error);
  } finally {
    // Close connection
    await mongoose.connection.close();
    console.log('🔌 Database connection closed');
  }
}

// Run the script
createAdminUser();