import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import User model
import { User } from '../models/User';

async function debugAdminUser() {
  try {
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB');

    // Find admin user
    const adminUser = await User.findOne({ email: 'admin@test.com' });
    
    if (!adminUser) {
      console.log('❌ Admin user not found in database!');
      console.log('📝 Creating admin user...');
      
      // Create new admin user
      const newAdmin = new User({
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@test.com',
        password: 'admin123', // Will be hashed by pre-save middleware
        role: 'admin',
        isEmailVerified: true,
        isActive: true,
        provider: 'local',
        otpVerified: false,
        loginAttempts: 0,
        twoFactorEnabled: false,
        refreshTokens: [],
        preferences: {
          theme: 'system',
          language: 'en',
          notifications: {
            email: true,
            sms: false,
            push: true,
          },
        },
      });
      
      await newAdmin.save();
      console.log('✅ Admin user created successfully');
    } else {
      console.log('🔍 Admin user found in database');
      console.log('📋 Current admin details:');
      console.log(`   📧 Email: ${adminUser.email}`);
      console.log(`   🔑 Role: ${adminUser.role}`);
      console.log(`   ✅ Email Verified: ${adminUser.isEmailVerified}`);
      console.log(`   🟢 Active: ${adminUser.isActive}`);
      console.log(`   🔐 Has Password: ${!!adminUser.password}`);
      
      // Test password comparison
      if (adminUser.password) {
        const isMatch = await bcrypt.compare('admin123', adminUser.password);
        console.log(`   🔐 Password 'admin123' matches: ${isMatch}`);
        
        if (!isMatch) {
          console.log('🔧 Password mismatch! Updating password...');
          const salt = await bcrypt.genSalt(12);
          const hashedPassword = await bcrypt.hash('admin123', salt);
          adminUser.password = hashedPassword;
          await adminUser.save();
          console.log('✅ Password updated successfully');
        }
      } else {
        console.log('❌ No password set! Setting password...');
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash('admin123', salt);
        adminUser.password = hashedPassword;
        await adminUser.save();
        console.log('✅ Password set successfully');
      }
    }

    // Final verification
    const finalAdmin = await User.findOne({ email: 'admin@test.com' });
    if (finalAdmin && finalAdmin.password) {
      const passwordTest = await bcrypt.compare('admin123', finalAdmin.password);
      console.log('\n🎯 Final verification:');
      console.log(`   📧 Email: ${finalAdmin.email}`);
      console.log(`   🔑 Role: ${finalAdmin.role}`);
      console.log(`   ✅ Email Verified: ${finalAdmin.isEmailVerified}`);
      console.log(`   🔐 Password works: ${passwordTest}`);
      
      if (passwordTest && finalAdmin.isEmailVerified && finalAdmin.role === 'admin') {
        console.log('\n🎉 Admin user is ready! Credentials should work now.');
        console.log('📝 Login with: admin@test.com / admin123');
      } else {
        console.log('\n❌ There are still issues with the admin user.');
      }
    }

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Database connection closed');
  }
}

debugAdminUser();