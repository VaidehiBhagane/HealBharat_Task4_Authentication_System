import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import User model
import { User } from '../models/User';

async function fixAdminUser() {
  try {
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB');

    // Delete existing admin user to start fresh
    await User.deleteOne({ email: 'admin@test.com' });
    console.log('🗑️ Deleted existing admin user');

    // Create new admin user with compliant password
    const adminUser = new User({
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@test.com',
      password: 'Admin@123', // Meets all requirements: uppercase, lowercase, number, special char
      role: 'admin',
      isEmailVerified: true,
      isActive: true,
      provider: 'local',
      otpVerified: false,
      loginAttempts: 0,
      twoFactorEnabled: false,
      refreshTokens: [],
      preferences: {
        theme: 'system',
        language: 'en',
        notifications: {
          email: true,
          sms: false,
          push: true,
        },
      },
    });

    await adminUser.save();
    console.log('✅ Admin user created successfully');

    // Verify the admin user
    const verifyAdmin = await User.findOne({ email: 'admin@test.com' });
    if (verifyAdmin && verifyAdmin.password) {
      const passwordTest = await bcrypt.compare('Admin@123', verifyAdmin.password);
      
      console.log('\n📋 Admin User Details:');
      console.log(`   📧 Email: ${verifyAdmin.email}`);
      console.log(`   👤 Name: ${verifyAdmin.firstName} ${verifyAdmin.lastName}`);
      console.log(`   🔑 Role: ${verifyAdmin.role}`);
      console.log(`   ✅ Email Verified: ${verifyAdmin.isEmailVerified}`);
      console.log(`   🟢 Active: ${verifyAdmin.isActive}`);
      console.log(`   🔐 Password 'Admin@123' works: ${passwordTest}`);
      
      if (passwordTest) {
        console.log('\n🎉 SUCCESS! Admin user is ready!');
        console.log('📝 Login Credentials:');
        console.log('   Email: admin@test.com');
        console.log('   Password: Admin@123');
      } else {
        console.log('\n❌ Password verification failed');
      }
    }

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Database connection closed');
  }
}

fixAdminUser();