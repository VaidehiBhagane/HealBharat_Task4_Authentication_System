const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Simple User schema for this script
const UserSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  password: String,
  role: String,
  isEmailVerified: Boolean,
  isActive: Boolean,
  provider: String
});

const User = mongoose.model('User', UserSchema);

async function fixAdminUser() {
  try {
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/authsystem';
    await mongoose.connect(mongoUri);
    console.log('📦 Connected to MongoDB');

    // Check current admin user status
    const adminUser = await User.findOne({ email: 'admin@test.com' });
    
    if (!adminUser) {
      console.log('❌ Admin user not found');
      process.exit(1);
    }

    console.log('📊 Current admin user status:');
    console.log('Email:', adminUser.email);
    console.log('Role:', adminUser.role);
    console.log('Email Verified:', adminUser.isEmailVerified);
    console.log('Active:', adminUser.isActive);

    // Fix the admin user
    const updateResult = await User.updateOne(
      { email: 'admin@test.com' },
      { 
        $set: { 
          isEmailVerified: true,
          isActive: true,
          role: 'admin'
        }
      }
    );

    console.log('✅ Admin user updated:', updateResult.modifiedCount, 'documents modified');

    // Verify the update
    const updatedAdmin = await User.findOne({ email: 'admin@test.com' });
    console.log('📊 Updated admin user status:');
    console.log('Email Verified:', updatedAdmin.isEmailVerified);
    console.log('Active:', updatedAdmin.isActive);
    console.log('Role:', updatedAdmin.role);

    console.log('✅ Admin user is now ready for login!');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('📦 Disconnected from MongoDB');
    process.exit(0);
  }
}

fixAdminUser();