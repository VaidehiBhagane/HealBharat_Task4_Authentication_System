const axios = require('axios');

async function testLogin() {
  try {
    console.log('🔍 Testing login API...');
    
    const response = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@test.com',
      password: 'admin123'
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Login successful!');
    console.log('Status:', response.status);
    console.log('Success:', response.data.success);
    console.log('Message:', response.data.message);
    console.log('User Role:', response.data.data?.user?.role);
    console.log('Requires OTP:', response.data.data?.requiresOTP);
    console.log('Has Tokens:', !!response.data.data?.tokens);

  } catch (error) {
    console.log('❌ Login failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Error Message:', error.response.data?.message);
      console.log('Full Response:', JSON.stringify(error.response.data, null, 2));
    } else if (error.request) {
      console.log('No response received:', error.message);
    } else {
      console.log('Request error:', error.message);
    }
  }
}

testLogin();