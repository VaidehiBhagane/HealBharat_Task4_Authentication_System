#!/usr/bin/env node

/**
 * Comprehensive Authentication System Test
 * Tests all authentication flows including welcome page, profile dashboard, and admin panel
 */

const axios = require('axios');
const colors = require('colors');

const BASE_URL = 'http://localhost:5000';
const FRONTEND_URL = 'http://localhost:3001';

// Test data
const testUser = {
  firstName: 'Test',
  lastName: 'User',
  email: 'testuser@example.com',
  password: 'TestPassword123!',
  phoneNumber: '+1234567890',
  bio: 'I am a test user for the authentication system.'
};

const testAdmin = {
  firstName: 'Admin',
  lastName: 'User',  
  email: 'admin@example.com',
  password: 'AdminPassword123!',
  phoneNumber: '+1987654321',
  bio: 'I am an admin user with elevated privileges.'
};

let userToken = '';
let adminToken = '';
let userId = '';
let adminUserId = '';

console.log('🚀 Starting Comprehensive Authentication System Test\n'.cyan.bold);

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function testEndpoint(name, testFunc) {
  try {
    console.log(`🧪 Testing ${name}...`.yellow);
    await testFunc();
    console.log(`✅ ${name} - PASSED\n`.green);
    return true;
  } catch (error) {
    console.log(`❌ ${name} - FAILED`.red);
    console.log(`   Error: ${error.message}`.red);
    console.log('');
    return false;
  }
}

// 1. Test User Registration
async function testUserRegistration() {
  const response = await axios.post(`${BASE_URL}/api/auth/register`, testUser);
  
  if (response.data.success) {
    userId = response.data.data.user._id;
    console.log(`   ✓ User registered successfully (ID: ${userId})`.green);
  } else {
    throw new Error('Registration failed: ' + response.data.message);
  }
}

// 2. Test Admin Registration  
async function testAdminRegistration() {
  const response = await axios.post(`${BASE_URL}/api/auth/register`, testAdmin);
  
  if (response.data.success) {
    adminUserId = response.data.data.user._id;
    console.log(`   ✓ Admin user registered successfully (ID: ${adminUserId})`.green);
  } else {
    throw new Error('Admin registration failed: ' + response.data.message);
  }
}

// 3. Test User Login
async function testUserLogin() {
  const response = await axios.post(`${BASE_URL}/api/auth/login`, {
    email: testUser.email,
    password: testUser.password
  });
  
  if (response.data.success) {
    userToken = response.data.data.tokens.accessToken;
    console.log(`   ✓ User login successful`.green);
    console.log(`   ✓ Access token received`.green);
  } else {
    throw new Error('Login failed: ' + response.data.message);
  }
}

// 4. Test Admin Login
async function testAdminLogin() {
  const response = await axios.post(`${BASE_URL}/api/auth/login`, {
    email: testAdmin.email,
    password: testAdmin.password
  });
  
  if (response.data.success) {
    adminToken = response.data.data.tokens.accessToken;
    console.log(`   ✓ Admin login successful`.green);
    console.log(`   ✓ Admin access token received`.green);
  } else {
    throw new Error('Admin login failed: ' + response.data.message);
  }
}

// 5. Test Profile Retrieval
async function testProfileRetrieval() {
  const response = await axios.get(`${BASE_URL}/api/auth/profile`, {
    headers: { Authorization: `Bearer ${userToken}` }
  });
  
  if (response.data.success) {
    const user = response.data.data.user;
    console.log(`   ✓ Profile retrieved: ${user.firstName} ${user.lastName}`.green);
    console.log(`   ✓ Email: ${user.email}`.green);
  } else {
    throw new Error('Profile retrieval failed: ' + response.data.message);
  }
}

// 6. Test Profile Update
async function testProfileUpdate() {
  const updateData = {
    firstName: 'Updated',
    lastName: 'TestUser',
    phoneNumber: '+1555123456',
    bio: 'Updated bio for testing profile updates.'
  };

  const response = await axios.patch(`${BASE_URL}/api/auth/profile`, updateData, {
    headers: { 
      Authorization: `Bearer ${userToken}`,
      'Content-Type': 'application/json'
    }
  });
  
  if (response.data.success) {
    const user = response.data.data.user;
    console.log(`   ✓ Profile updated: ${user.firstName} ${user.lastName}`.green);
    console.log(`   ✓ Phone: ${user.phoneNumber}`.green);
    console.log(`   ✓ Bio: ${user.bio}`.green);
  } else {
    throw new Error('Profile update failed: ' + response.data.message);
  }
}

// 7. Test Admin User List
async function testAdminUserList() {
  // First make the admin user an actual admin
  await axios.patch(`${BASE_URL}/api/admin/users/${adminUserId}/role`, 
    { role: 'admin' },
    { headers: { Authorization: `Bearer ${adminToken}` }}
  );

  const response = await axios.get(`${BASE_URL}/api/admin/users`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  
  if (response.data.success) {
    const users = response.data.data.users;
    console.log(`   ✓ Admin retrieved ${users.length} users`.green);
    console.log(`   ✓ Users include regular and admin users`.green);
  } else {
    throw new Error('Admin user list failed: ' + response.data.message);
  }
}

// 8. Test Admin Statistics
async function testAdminStatistics() {
  const response = await axios.get(`${BASE_URL}/api/admin/stats`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  
  if (response.data.success) {
    const stats = response.data.data;
    console.log(`   ✓ Stats retrieved - Total Users: ${stats.totalUsers}`.green);
    console.log(`   ✓ Active Users: ${stats.activeUsers}`.green);
    console.log(`   ✓ Admin Users: ${stats.adminUsers}`.green);
  } else {
    throw new Error('Admin statistics failed: ' + response.data.message);
  }
}

// 9. Test User Role Management
async function testUserRoleManagement() {
  // Change regular user to admin
  const response = await axios.patch(`${BASE_URL}/api/admin/users/${userId}/role`, 
    { role: 'admin' },
    { headers: { Authorization: `Bearer ${adminToken}` }}
  );
  
  if (response.data.success) {
    console.log(`   ✓ User role updated to admin successfully`.green);
  } else {
    throw new Error('Role management failed: ' + response.data.message);
  }

  // Change back to user
  const response2 = await axios.patch(`${BASE_URL}/api/admin/users/${userId}/role`, 
    { role: 'user' },
    { headers: { Authorization: `Bearer ${adminToken}` }}
  );
  
  if (response2.data.success) {
    console.log(`   ✓ User role changed back to user successfully`.green);
  } else {
    throw new Error('Role change back failed: ' + response2.data.message);
  }
}

// 10. Test User Status Management
async function testUserStatusManagement() {
  // Deactivate user
  const response = await axios.patch(`${BASE_URL}/api/admin/users/${userId}/status`, 
    { isActive: false },
    { headers: { Authorization: `Bearer ${adminToken}` }}
  );
  
  if (response.data.success) {
    console.log(`   ✓ User deactivated successfully`.green);
  } else {
    throw new Error('User deactivation failed: ' + response.data.message);
  }

  // Reactivate user
  const response2 = await axios.patch(`${BASE_URL}/api/admin/users/${userId}/status`, 
    { isActive: true },
    { headers: { Authorization: `Bearer ${adminToken}` }}
  );
  
  if (response2.data.success) {
    console.log(`   ✓ User reactivated successfully`.green);
  } else {
    throw new Error('User reactivation failed: ' + response2.data.message);
  }
}

// 11. Test Frontend Accessibility
async function testFrontendPages() {
  try {
    // Test welcome page
    const welcomeResponse = await axios.get(`${FRONTEND_URL}/welcome`);
    if (welcomeResponse.status === 200) {
      console.log(`   ✓ Welcome page accessible at ${FRONTEND_URL}/welcome`.green);
    }
  } catch (error) {
    console.log(`   ⚠️  Welcome page test skipped (auth required)`.yellow);
  }

  try {
    // Test dashboard page
    const dashboardResponse = await axios.get(`${FRONTEND_URL}/dashboard`);
    if (dashboardResponse.status === 200) {
      console.log(`   ✓ Dashboard page accessible at ${FRONTEND_URL}/dashboard`.green);
    }
  } catch (error) {
    console.log(`   ⚠️  Dashboard page test skipped (auth required)`.yellow);
  }

  try {
    // Test admin page
    const adminResponse = await axios.get(`${FRONTEND_URL}/admin`);
    if (adminResponse.status === 200) {
      console.log(`   ✓ Admin page accessible at ${FRONTEND_URL}/admin`.green);
    }
  } catch (error) {
    console.log(`   ⚠️  Admin page test skipped (auth required)`.yellow);
  }

  // Test login page (should be accessible)
  const loginResponse = await axios.get(`${FRONTEND_URL}/login`);
  if (loginResponse.status === 200) {
    console.log(`   ✓ Login page accessible at ${FRONTEND_URL}/login`.green);
  }

  // Test signup page (should be accessible)
  const signupResponse = await axios.get(`${FRONTEND_URL}/signup`);
  if (signupResponse.status === 200) {
    console.log(`   ✓ Signup page accessible at ${FRONTEND_URL}/signup`.green);
  }
}

// Run all tests
async function runAllTests() {
  const tests = [
    ['User Registration', testUserRegistration],
    ['Admin Registration', testAdminRegistration],
    ['User Login', testUserLogin],
    ['Admin Login', testAdminLogin],
    ['Profile Retrieval', testProfileRetrieval],
    ['Profile Update', testProfileUpdate],
    ['Admin User List', testAdminUserList],
    ['Admin Statistics', testAdminStatistics],
    ['User Role Management', testUserRoleManagement],
    ['User Status Management', testUserStatusManagement],
    ['Frontend Page Accessibility', testFrontendPages]
  ];

  let passed = 0;
  let failed = 0;

  for (const [name, testFunc] of tests) {
    const result = await testEndpoint(name, testFunc);
    if (result) {
      passed++;
    } else {
      failed++;
    }
    await sleep(500); // Small delay between tests
  }

  // Summary
  console.log('📊 TEST SUMMARY'.cyan.bold);
  console.log('='.repeat(50).cyan);
  console.log(`✅ Passed: ${passed}`.green.bold);
  console.log(`❌ Failed: ${failed}`.red.bold);
  console.log(`📈 Success Rate: ${((passed / (passed + failed)) * 100).toFixed(1)}%`.cyan.bold);
  
  if (failed === 0) {
    console.log('\n🎉 ALL TESTS PASSED! Your authentication system is working perfectly! 🎉'.green.bold);
    console.log('\n🔗 ACCESS LINKS:'.cyan.bold);
    console.log(`   Frontend: ${FRONTEND_URL}`.green);
    console.log(`   Login: ${FRONTEND_URL}/login`.green);
    console.log(`   Signup: ${FRONTEND_URL}/signup`.green);
    console.log(`   Dashboard: ${FRONTEND_URL}/dashboard (after login)`.green);
    console.log(`   Admin Panel: ${FRONTEND_URL}/admin (admin users only)`.green);
  } else {
    console.log('\n⚠️  Some tests failed. Please check the errors above and fix any issues.'.yellow.bold);
  }
}

// Start testing
runAllTests().catch((error) => {
  console.error('Test runner failed:', error.message);
  process.exit(1);
});