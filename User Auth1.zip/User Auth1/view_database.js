// Direct MongoDB connection to view users
const mongoose = require('mongoose');

// MongoDB connection
const mongoUri = 'mongodb://localhost:27017/authsystem';

// User Schema (must match your actual schema)
const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  password: String,
  phoneNumber: String,
  role: { type: String, default: 'user' },
  isActive: { type: Boolean, default: true },
  isEmailVerified: { type: Boolean, default: false },
  isPhoneVerified: { type: Boolean, default: false },
  provider: { type: String, default: 'local' },
  providerId: String,
  googleId: String,
  facebookId: String,
  profilePicture: String,
  bio: String,
  lastLogin: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { collection: 'users' });

async function viewAllUsersFromDB() {
  try {
    // Connect to MongoDB
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB\n');
    
    const User = mongoose.model('User', userSchema);
    
    // Get all users (excluding password field)
    const users = await User.find({}).select('-password -refreshTokens').lean();
    
    console.log(`📊 Total Users in Database: ${users.length}\n`);
    
    if (users.length === 0) {
      console.log('🚫 No users found in database');
      return;
    }
    
    console.log('👥 Complete User Database:');
    console.log('═'.repeat(100));
    
    users.forEach((user, index) => {
      console.log(`\n${index + 1}. 👤 ${user.firstName || 'N/A'} ${user.lastName || 'N/A'}`);
      console.log(`   📧 Email: ${user.email || 'N/A'}`);
      console.log(`   📱 Phone: ${user.phoneNumber || 'Not provided'}`);
      console.log(`   👑 Role: ${user.role || 'user'}`);
      console.log(`   🔐 Provider: ${user.provider || 'local'}`);
      console.log(`   ✅ Email Verified: ${user.isEmailVerified ? 'Yes' : 'No'}`);
      console.log(`   📲 Phone Verified: ${user.isPhoneVerified ? 'Yes' : 'No'}`);
      console.log(`   🟢 Active: ${user.isActive ? 'Yes' : 'No'}`);
      console.log(`   📅 Created: ${new Date(user.createdAt).toLocaleString()}`);
      if (user.lastLogin) {
        console.log(`   🕐 Last Login: ${new Date(user.lastLogin).toLocaleString()}`);
      }
      if (user.bio) {
        console.log(`   📝 Bio: ${user.bio}`);
      }
      if (user.profilePicture) {
        console.log(`   🖼️  Profile Picture: ${user.profilePicture}`);
      }
      if (user.googleId) {
        console.log(`   🌐 Google ID: ${user.googleId}`);
      }
      console.log(`   🆔 Database ID: ${user._id}`);
      console.log('─'.repeat(80));
    });
    
    // Summary statistics
    const adminCount = users.filter(u => u.role === 'admin').length;
    const userCount = users.filter(u => u.role === 'user').length;
    const verifiedEmails = users.filter(u => u.isEmailVerified).length;
    const verifiedPhones = users.filter(u => u.isPhoneVerified).length;
    const googleUsers = users.filter(u => u.provider === 'google').length;
    const localUsers = users.filter(u => u.provider === 'local').length;
    
    console.log('\n📈 DATABASE STATISTICS:');
    console.log('═'.repeat(50));
    console.log(`👑 Admins: ${adminCount}`);
    console.log(`👤 Regular Users: ${userCount}`);
    console.log(`✅ Email Verified: ${verifiedEmails}/${users.length}`);
    console.log(`📱 Phone Verified: ${verifiedPhones}/${users.length}`);
    console.log(`🌐 Google Users: ${googleUsers}`);
    console.log(`🔐 Local Users: ${localUsers}`);
    
  } catch (error) {
    console.error('❌ Error connecting to database:', error);
  } finally {
    await mongoose.disconnect();
    console.log('\n👋 Disconnected from MongoDB');
  }
}

viewAllUsersFromDB();