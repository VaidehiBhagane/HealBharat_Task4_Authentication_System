// Quick script to create an admin user for testing
// Run this in MongoDB CLI or use MongoDB Compass

// Connect to your database first, then run:

db = db.getSiblingDB('authsystem'); // Use your database name

// Create an admin user
db.users.insertOne({
  email: "admin@test.com",
  password: "$2b$12$LQv3c1yqBwEHFgM7GDCzMeHtrFBgNNLY9UwxGQJ7KOFw1Qj5YPK6m", // password: "admin123"
  firstName: "Admin",
  lastName: "User",
  role: "admin",
  isActive: true,
  isEmailVerified: true,
  isPhoneVerified: false,
  provider: "local",
  loginAttempts: 0,
  otpVerified: false,
  twoFactorEnabled: false,
  refreshTokens: [],
  passwordResetRequired: false,
  preferences: {
    theme: "system",
    language: "en",
    notifications: {
      email: true,
      sms: false,
      push: true
    }
  },
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create a regular user for testing
db.users.insertOne({
  email: "user@test.com", 
  password: "$2b$12$LQv3c1yqBwEHFgM7GDCzMeHtrFBgNNLY9UwxGQJ7KOFw1Qj5YPK6m", // password: "admin123"
  firstName: "Test",
  lastName: "User",
  phoneNumber: "+1234567890",
  role: "user",
  isActive: true,
  isEmailVerified: true,
  isPhoneVerified: false,
  provider: "local",
  loginAttempts: 0,
  otpVerified: false,
  twoFactorEnabled: false,
  refreshTokens: [],
  passwordResetRequired: false,
  preferences: {
    theme: "system",
    language: "en", 
    notifications: {
      email: true,
      sms: false,
      push: true
    }
  },
  createdAt: new Date(),
  updatedAt: new Date()
});

// Verify the users were created
db.users.find({}, {password: 0}).pretty();

console.log("✅ Test users created!");
console.log("👑 Admin: admin@test.com / admin123");
console.log("👤 User: user@test.com / admin123");