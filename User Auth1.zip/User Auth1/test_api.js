// Test script to verify admin API endpoints
const axios = require('axios');

const BASE_URL = 'http://localhost:5000';

async function testAdminAPI() {
    try {
        console.log('🧪 Testing Admin API endpoints...\n');
        
        // Test 1: Health check
        console.log('1. Testing health endpoint...');
        const health = await axios.get(`${BASE_URL}/api/system/health`);
        console.log('✅ Health:', health.data);
        
        // Test 2: Users endpoint (without auth - should work for testing)
        console.log('\n2. Testing users endpoint...');
        const users = await axios.get(`${BASE_URL}/api/admin/users`);
        console.log('✅ Users count:', users.data.data?.length || 0);
        console.log('Users:', users.data.data?.map(u => ({ email: u.email, role: u.role })) || []);
        
        // Test 3: Stats endpoint
        console.log('\n3. Testing stats endpoint...');
        const stats = await axios.get(`${BASE_URL}/api/admin/stats`);
        console.log('✅ Stats:', stats.data);
        
        console.log('\n🎉 All API endpoints are working!');
        
    } catch (error) {
        console.error('❌ API Test failed:');
        if (error.response) {
            console.error('Status:', error.response.status);
            console.error('Data:', error.response.data);
        } else {
            console.error('Error:', error.message);
        }
    }
}

testAdminAPI();