# Authentication System Development Tester
# This script tests the complete auth flow

Write-Host "🔍 Testing Authentication System..." -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

# Test 1: Backend Health Check
Write-Host "`n1. Testing Backend Health..." -ForegroundColor Yellow
try {
    $healthCheck = Invoke-RestMethod -Uri "http://localhost:5000/health" -Method GET -TimeoutSec 5
    Write-Host "✅ Backend is running!" -ForegroundColor Green
    Write-Host "   Status: $($healthCheck.status)" -ForegroundColor Gray
    Write-Host "   Message: $($healthCheck.message)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Backend is not running!" -ForegroundColor Red
    Write-Host "   Please run: npm run dev" -ForegroundColor Yellow
    Write-Host "   Or start backend separately with: cd backend && npm run dev" -ForegroundColor Yellow
    exit 1
}

# Test 2: Frontend Accessibility
Write-Host "`n2. Testing Frontend Accessibility..." -ForegroundColor Yellow
try {
    $frontendCheck = Invoke-WebRequest -Uri "http://localhost:3000" -Method HEAD -TimeoutSec 5 -UseBasicParsing
    if ($frontendCheck.StatusCode -eq 200) {
        Write-Host "✅ Frontend is running!" -ForegroundColor Green
        Write-Host "   Login page: http://localhost:3000/login" -ForegroundColor Gray
        Write-Host "   Signup page: http://localhost:3000/signup" -ForegroundColor Gray
    }
} catch {
    Write-Host "❌ Frontend is not accessible!" -ForegroundColor Red
    Write-Host "   Please ensure frontend is running on port 3000" -ForegroundColor Yellow
}

# Test 3: Registration API
Write-Host "`n3. Testing Registration API..." -ForegroundColor Yellow
$testUser = @{
    firstName = "Test"
    lastName = "User" 
    email = "testuser$(Get-Random -Minimum 1000 -Maximum 9999)@example.com"
    password = "TestPass123!"
} | ConvertTo-Json

try {
    $registerResponse = Invoke-RestMethod -Uri "http://localhost:5000/api/auth/register" -Method POST -ContentType "application/json" -Body $testUser
    Write-Host "✅ Registration API works!" -ForegroundColor Green
    Write-Host "   User created: $($registerResponse.data.user.email)" -ForegroundColor Gray
    
    # Test 4: Login API with created user
    Write-Host "`n4. Testing Login API..." -ForegroundColor Yellow
    $loginUser = @{
        email = ($testUser | ConvertFrom-Json).email
        password = ($testUser | ConvertFrom-Json).password
    } | ConvertTo-Json
    
    $loginResponse = Invoke-RestMethod -Uri "http://localhost:5000/api/auth/login" -Method POST -ContentType "application/json" -Body $loginUser
    Write-Host "✅ Login API works!" -ForegroundColor Green
    Write-Host "   Login successful for: $($loginResponse.data.user.email)" -ForegroundColor Gray
    
} catch {
    Write-Host "❌ Registration/Login API failed!" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Authentication System Test Complete!" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan

Write-Host "`n🚀 Next Steps:" -ForegroundColor Green
Write-Host "1. Open http://localhost:3000/signup to test signup" -ForegroundColor White
Write-Host "2. Create a new account" -ForegroundColor White
Write-Host "3. Login with the created credentials" -ForegroundColor White
Write-Host "4. Check that you reach the dashboard" -ForegroundColor White

Write-Host "`n📝 Development Commands:" -ForegroundColor Blue
Write-Host "- Start all: npm run dev" -ForegroundColor White
Write-Host "- Backend only: cd backend && npm run dev" -ForegroundColor White  
Write-Host "- Frontend only: cd frontend && npm run dev" -ForegroundColor White