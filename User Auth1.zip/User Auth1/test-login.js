const https = require('https');
const http = require('http');

// Test admin login API directly
const testLogin = () => {
  const postData = JSON.stringify({
    email: 'admin@test.com',
    password: 'Admin@123'
  });

  const options = {
    hostname: 'localhost',
    port: 5000,
    path: '/api/auth/login',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('🔍 Testing admin login API...');
  console.log('📧 Email: admin@test.com');
  console.log('🔐 Password: Admin@123');
  console.log('🌐 URL: http://localhost:5000/api/auth/login');

  const req = http.request(options, (res) => {
    console.log(`\n📊 Response Status: ${res.statusCode}`);
    console.log(`📋 Response Headers:`, res.headers);

    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });

    res.on('end', () => {
      console.log('\n📄 Response Body:');
      try {
        const jsonData = JSON.parse(data);
        console.log(JSON.stringify(jsonData, null, 2));
        
        if (jsonData.success) {
          console.log('\n✅ LOGIN SUCCESS! Admin credentials are working.');
          console.log('🎯 Issue is likely in frontend-backend communication.');
        } else {
          console.log('\n❌ LOGIN FAILED! Backend is rejecting credentials.');
          console.log('🔍 Reason:', jsonData.message);
        }
      } catch (e) {
        console.log('Raw response:', data);
      }
    });
  });

  req.on('error', (e) => {
    console.error('❌ Request Error:', e.message);
    console.log('🔍 Backend server may not be running on port 5000');
  });

  req.write(postData);
  req.end();
};

testLogin();