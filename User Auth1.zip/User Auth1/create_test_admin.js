const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://localhost:27017/authsystem');
    console.log('✅ MongoDB connected');
  } catch (error) {
    console.error('❌ MongoDB connection failed:', error);
    process.exit(1);
  }
};

// User schema (simplified)
const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  isActive: { type: Boolean, default: true },
  isEmailVerified: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  provider: { type: String, default: 'local' }
});

const User = mongoose.model('User', userSchema);

async function createTestAdmin() {
  await connectDB();
  
  try {
    // Check if admin already exists
    const existingAdmin = await User.findOne({ email: 'admin@test.com' });
    
    if (existingAdmin) {
      console.log('✅ Admin user already exists: admin@test.com');
      
      // Ensure admin is properly configured
      existingAdmin.role = 'admin';
      existingAdmin.isActive = true;
      existingAdmin.isEmailVerified = true;
      await existingAdmin.save();
      
      console.log('✅ Admin user updated with proper permissions');
    } else {
      // Create new admin user
      const saltRounds = 10;
      const hashedPassword = await bcrypt.hash('admin123', saltRounds);
      
      const adminUser = new User({
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@test.com',
        password: hashedPassword,
        role: 'admin',
        isActive: true,
        isEmailVerified: true,
        provider: 'local'
      });
      
      await adminUser.save();
      console.log('✅ Test admin user created successfully!');
    }
    
    console.log('\n📝 Admin Login Credentials:');
    console.log('Email: admin@test.com');
    console.log('Password: admin123');
    console.log('\n🎯 How to test:');
    console.log('1. Go to http://localhost:3000/login');
    console.log('2. Login with admin credentials');
    console.log('3. Should automatically redirect to /admin dashboard');
    console.log('4. Admin dashboard will show all users from database');
    
  } catch (error) {
    console.error('❌ Error creating admin user:', error);
  } finally {
    mongoose.connection.close();
  }
}

createTestAdmin();