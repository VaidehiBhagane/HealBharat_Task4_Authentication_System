// Test script to verify admin API functionality
const testAdminAPI = async () => {
  try {
    console.log('🔍 Testing Backend Health...');
    
    // Test 1: Health check
    const healthResponse = await fetch('http://localhost:5000/health');
    const healthData = await healthResponse.json();
    console.log('✅ Health Check:', healthData);
    
    // Test 2: Admin login
    console.log('\n🔐 Testing Admin Login...');
    const loginResponse = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'admin@test.com',
        password: 'admin123'
      })
    });
    
    const loginData = await loginResponse.json();
    console.log('Login Response Status:', loginResponse.status);
    console.log('Login Response:', loginData);
    
    if (loginData.success && loginData.data.tokens) {
      const token = loginData.data.tokens.accessToken;
      
      // Test 3: Admin dashboard access
      console.log('\n📊 Testing Admin Dashboard Access...');
      const adminResponse = await fetch('http://localhost:5000/api/admin/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      const adminData = await adminResponse.json();
      console.log('Admin Stats Response Status:', adminResponse.status);
      console.log('Admin Stats Response:', adminData);
      
      // Test 4: Get users list
      console.log('\n👥 Testing Get Users List...');
      const usersResponse = await fetch('http://localhost:5000/api/admin/users', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      const usersData = await usersResponse.json();
      console.log('Users List Response Status:', usersResponse.status);
      console.log('Users List Response:', usersData);
    }
    
  } catch (error) {
    console.error('❌ Test Error:', error);
  }
};

// Run the test
testAdminAPI();