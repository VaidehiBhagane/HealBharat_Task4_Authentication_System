// Quick script to view all users via API
const axios = require('axios');

async function viewAllUsers() {
  try {
    console.log('🔍 Fetching all users from database...\n');
    
    const response = await axios.get('http://localhost:5000/api/admin/users');
    const users = response.data.data;
    
    console.log(`📊 Total Users: ${users.length}\n`);
    console.log('👥 User List:');
    console.log('═'.repeat(80));
    
    users.forEach((user, index) => {
      console.log(`${index + 1}. 👤 ${user.firstName} ${user.lastName}`);
      console.log(`   📧 Email: ${user.email}`);
      console.log(`   👑 Role: ${user.role}`);
      console.log(`   ✅ Email Verified: ${user.isEmailVerified}`);
      console.log(`   📱 Phone Verified: ${user.isPhoneVerified || false}`);
      console.log(`   🔐 Provider: ${user.provider}`);
      console.log(`   📅 Created: ${new Date(user.createdAt).toLocaleDateString()}`);
      if (user.lastLogin) {
        console.log(`   🕐 Last Login: ${new Date(user.lastLogin).toLocaleString()}`);
      }
      console.log('─'.repeat(50));
    });
    
  } catch (error) {
    console.error('❌ Error fetching users:', error.response?.data || error.message);
  }
}

viewAllUsers();