'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import apiClient, { checkBackendConnectivity } from '../lib/apiClient';

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  isEmailVerified: boolean;
  isPhoneVerified?: boolean;
  phoneNumber?: string;
  profilePicture?: string;
  bio?: string;
  lastLogin?: string;
  createdAt?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<boolean>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  const isAuthenticated = !!user;

  // Check if user is authenticated on app start
  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      // First check if backend is reachable
      const connectivity = await checkBackendConnectivity();
      if (!connectivity.connected) {
        console.error('Backend not reachable:', connectivity.message);
        // Don't show error toast on initial load, just log it
        setIsLoading(false);
        return;
      }

      const token = localStorage.getItem('accessToken');
      if (!token) {
        setIsLoading(false);
        return;
      }

      const response = await apiClient.getMe();

      if (response.success && response.data?.user) {
        setUser(response.data.user);
      } else {
        // Token invalid, clear it
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('user');
        
        if (response.error) {
          console.warn('Auth check failed:', response.error);
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      // Check backend connectivity first
      const connectivity = await checkBackendConnectivity();
      if (!connectivity.connected) {
        toast.error(`Cannot connect to server: ${connectivity.message}`);
        return false;
      }

      const response = await apiClient.login(email, password);

      if (response.success && response.data) {
        // Check if this is a direct login (admin bypass) or requires OTP
        if (response.data.tokens) {
          // Direct login with tokens (admin bypass or regular user)
          localStorage.setItem('accessToken', response.data.tokens.accessToken);
          localStorage.setItem('refreshToken', response.data.tokens.refreshToken);
          localStorage.setItem('user', JSON.stringify(response.data.user));
          
          setUser(response.data.user);
          
          toast.success(`Welcome ${response.data.user.role === 'admin' ? 'Admin' : ''} ${response.data.user.firstName}!`);
          
          // Auto-redirect admin users to admin dashboard
          if (response.data.user.role === 'admin') {
            setTimeout(() => {
              router.push('/admin');
            }, 1500);
          } else {
            router.push('/dashboard');
          }
          return true;
        } else if (response.data.requiresOTP) {
          // OTP verification required
          toast.success('OTP sent to your email. Please verify to complete login.');
          router.push(`/verify-otp?email=${encodeURIComponent(email)}&type=login`);
          return true;
        } else {
          toast.error('Unexpected login response format');
          return false;
        }
      } else {
        const errorMsg = response.error || 'Login failed';
        toast.error(errorMsg);
        console.error('Login failed:', errorMsg);
        return false;
      }
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Provide specific error messages
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        toast.error('Cannot connect to server. Please check if the backend is running.');
      } else if (error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
        toast.error('Network error. Please check your connection and try again.');
      } else {
        toast.error('Login failed. Please try again.');
      }
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      const response = await apiClient.logout();
      
      if (!response.success) {
        console.warn('Logout API failed, but continuing with local cleanup:', response.error);
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Always clear local storage and state
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      setUser(null);
      
      toast.success('Logged out successfully');
      router.push('/login');
    }
  };

  const updateProfile = async (updatedUser: Partial<User>): Promise<boolean> => {
    try {
      // Update the user state with the provided data
      setUser(prev => prev ? { ...prev, ...updatedUser } : null);
      
      // Update localStorage
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      const newUser = { ...currentUser, ...updatedUser };
      localStorage.setItem('user', JSON.stringify(newUser));
      
      return true;
    } catch (error) {
      console.error('Profile update error:', error);
      return false;
    }
  };

  const refreshUser = async () => {
    await checkAuthStatus();
  };

  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticated,
    login,
    logout,
    updateProfile,
    refreshUser
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Hook for protected routes
export const useRequireAuth = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  return { isAuthenticated, isLoading };
};