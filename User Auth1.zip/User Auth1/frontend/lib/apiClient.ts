/**
 * Robust API client with automatic retry, error handling, and connection validation
 * Fixes persistent "login failed" and "can't reach page" issues
 */

interface ApiConfig {
  baseURL: string;
  timeout: number;
  retries: number;
  retryDelay: number;
}

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

class ApiClient {
  private config: ApiConfig;
  private isServerHealthy: boolean = false;
  private lastHealthCheck: number = 0;
  private healthCheckInterval: number = 30000; // 30 seconds

  constructor(config?: Partial<ApiConfig>) {
    this.config = {
      baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000',
      timeout: 10000,
      retries: 3,
      retryDelay: 1000,
      ...config
    };

    // Check server health on initialization
    this.checkServerHealth();
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async checkServerHealth(): Promise<boolean> {
    const now = Date.now();
    
    // Skip if recently checked
    if (this.isServerHealthy && (now - this.lastHealthCheck) < this.healthCheckInterval) {
      return this.isServerHealthy;
    }

    try {
      const response = await fetch(`${this.config.baseURL}/health`, {
        method: 'GET',
        signal: AbortSignal.timeout(5000)
      });

      this.isServerHealthy = response.ok;
      this.lastHealthCheck = now;
      
      if (!this.isServerHealthy) {
        console.warn('⚠️ Backend server health check failed');
      }
      
      return this.isServerHealthy;
    } catch (error) {
      console.error('❌ Backend server is not reachable:', error);
      this.isServerHealthy = false;
      this.lastHealthCheck = now;
      return false;
    }
  }

  private getAuthHeaders(): Record<string, string> {
    const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return headers;
  }

  private async makeRequest<T = any>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${this.config.baseURL}${endpoint}`;
    let lastError: any;

    // Check server health first
    const isHealthy = await this.checkServerHealth();
    if (!isHealthy) {
      return {
        success: false,
        error: 'Backend server is not available. Please ensure the server is running on ' + this.config.baseURL
      };
    }

    for (let attempt = 1; attempt <= this.config.retries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

        const response = await fetch(url, {
          ...options,
          headers: {
            ...this.getAuthHeaders(),
            ...options.headers,
          },
          signal: controller.signal,
          credentials: 'include',
        });

        clearTimeout(timeoutId);

        const data = await response.json();

        if (response.ok) {
          return {
            success: true,
            data: data.data || data,
            message: data.message
          };
        } else {
          // Handle specific error cases
          if (response.status === 401) {
            // Token might be expired, clear it
            if (typeof window !== 'undefined') {
              localStorage.removeItem('accessToken');
              localStorage.removeItem('refreshToken');
              localStorage.removeItem('user');
            }
          }

          return {
            success: false,
            error: data.message || data.error || `HTTP ${response.status}`,
            data: data
          };
        }
      } catch (error: any) {
        lastError = error;
        console.warn(`Attempt ${attempt}/${this.config.retries} failed:`, error.message);

        if (attempt < this.config.retries) {
          await this.delay(this.config.retryDelay * attempt);
        }
      }
    }

    // All retries failed
    let errorMessage = 'Network request failed';
    if (lastError?.name === 'AbortError') {
      errorMessage = 'Request timeout - server may be slow or unreachable';
    } else if (lastError?.message?.includes('fetch')) {
      errorMessage = 'Cannot connect to server. Please check if the backend is running.';
    }

    return {
      success: false,
      error: errorMessage
    };
  }

  // Auth Methods
  async login(email: string, password: string): Promise<ApiResponse> {
    return this.makeRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  }

  async logout(): Promise<ApiResponse> {
    const result = await this.makeRequest('/api/auth/logout', {
      method: 'POST'
    });

    // Clear local storage regardless of response
    if (typeof window !== 'undefined') {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
    }

    return result;
  }

  async getMe(): Promise<ApiResponse> {
    return this.makeRequest('/api/auth/me');
  }

  async refreshToken(): Promise<ApiResponse> {
    const refreshToken = typeof window !== 'undefined' ? localStorage.getItem('refreshToken') : null;
    
    if (!refreshToken) {
      return {
        success: false,
        error: 'No refresh token available'
      };
    }

    return this.makeRequest('/api/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refreshToken })
    });
  }

  // Google OAuth
  async initiateGoogleAuth(): Promise<string> {
    // Check server health before redirecting
    const isHealthy = await this.checkServerHealth();
    if (!isHealthy) {
      throw new Error('Backend server is not available for OAuth');
    }

    return `${this.config.baseURL}/api/auth/google`;
  }

  // Admin Methods
  async getUsers(params?: Record<string, any>): Promise<ApiResponse> {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.makeRequest(`/api/admin/users${queryString}`);
  }

  // Email Test
  async sendTestEmail(): Promise<ApiResponse> {
    return this.makeRequest('/api/debug/send-test-email', {
      method: 'POST'
    });
  }

  // System Status
  async getSystemStatus(): Promise<ApiResponse> {
    return this.makeRequest('/api/debug/status');
  }

  // Health Check (public method)
  async healthCheck(): Promise<boolean> {
    return this.checkServerHealth();
  }

  // Get server status
  getServerStatus(): { healthy: boolean; lastCheck: number } {
    return {
      healthy: this.isServerHealthy,
      lastCheck: this.lastHealthCheck
    };
  }
}

// Create singleton instance
export const apiClient = new ApiClient();

// Export for use in components
export default apiClient;

// Utility function to check if backend is reachable
export async function checkBackendConnectivity(): Promise<{
  connected: boolean;
  message: string;
  url: string;
}> {
  const baseURL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
  
  try {
    const response = await fetch(`${baseURL}/health`, {
      method: 'GET',
      signal: AbortSignal.timeout(5000)
    });

    return {
      connected: response.ok,
      message: response.ok ? 'Backend is reachable' : `Backend returned ${response.status}`,
      url: baseURL
    };
  } catch (error: any) {
    return {
      connected: false,
      message: `Cannot reach backend: ${error.message}`,
      url: baseURL
    };
  }
}