'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { 
  FaRocket, 
  FaLock, 
  FaUsers, 
  FaMobile,
  FaStar,
  FaFire,
  FaGem,
  FaCogs,
  FaUserShield
} from 'react-icons/fa'
import { ThemeToggle } from '../components/theme-toggle'
import ParticleField from '../components/ParticleField'
import { useAuth } from '../contexts/AuthContext'

export default function HomePage() {
  const { user, logout } = useAuth();
  
  const features = [
    {
      icon: <FaLock className="w-8 h-8" />,
      title: "Military-Grade Security",
      description: "Advanced encryption, JWT tokens, and multi-layer protection"
    },
    {
      icon: <FaFire className="w-8 h-8" />,
      title: "Lightning Fast",
      description: "Instant authentication with cutting-edge performance optimization"
    },
    {
      icon: <FaStar className="w-8 h-8" />,
      title: "Premium Experience",
      description: "Glassmorphic UI with seamless animations and intuitive design"
    },
    {
      icon: <FaCogs className="w-8 h-8" />,
      title: "Future Ready",
      description: "Built with Next.js 14, TypeScript, and modern web standards"
    }
  ]

  // Component animations and interactions

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        {/* Main gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900"></div>
        
        {/* Animated mesh gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/20 via-purple-500/20 to-pink-500/20 animate-pulse-slow"></div>
        
        {/* Geometric patterns */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 border border-blue-500/30 rotate-45 animate-spin-slow"></div>
          <div className="absolute top-3/4 right-1/4 w-48 h-48 border border-purple-500/30 rotate-12 animate-bounce-slow"></div>
          <div className="absolute top-1/2 left-3/4 w-32 h-32 border border-pink-500/30 -rotate-12 animate-pulse"></div>
        </div>

        {/* Floating particles */}
        <ParticleField count={25} />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="p-6">
          <nav className="flex justify-between items-center max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-2"
            >
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-glow">
                <FaLock className="w-5 h-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                AuthSystem
              </span>
            </motion.div>
            
            <div className="flex items-center gap-4">
              <ThemeToggle />
              
              {/* Admin button - ONLY visible for admin users */}
              {user && user.role === 'admin' && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <Link
                    href="/admin"
                    className="admin-button px-6 py-3 rounded-full text-sm font-medium flex items-center space-x-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 border border-red-400/50"
                  >
                    <FaUserShield className="w-4 h-4" />
                    <span>Admin Panel</span>
                  </Link>
                </motion.div>
              )}
              
              {/* Authentication buttons */}
              {!user ? (
                <>
                  <Link
                    href="/login"
                    className="glass-button-futuristic px-6 py-3 rounded-full text-sm font-medium"
                  >
                    Login
                  </Link>
                  <Link
                    href="/signup"
                    className="neon-button px-6 py-3 rounded-full text-sm font-medium"
                  >
                    Sign Up
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    href="/dashboard"
                    className="glass-button-futuristic px-6 py-3 rounded-full text-sm font-medium"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={logout}
                    className="neon-button px-6 py-3 rounded-full text-sm font-medium"
                  >
                    Logout
                  </button>
                </>
              )}
            </div>
          </nav>
        </header>

        {/* Hero Section */}
        <main className="flex-1 flex items-center justify-center p-6">
          <div className="max-w-6xl mx-auto text-center">
            {/* Main Hero Content */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-16"
            >
              {/* Hero Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="inline-block mb-8"
              >
                <div className="glass-badge px-6 py-2 rounded-full border border-blue-500/30">
                  <span className="text-blue-400 text-sm font-medium">
                    🚀 Experience the Future of Authentication
                  </span>
                </div>
              </motion.div>

              {/* Main Headline */}
              <motion.h1
                className="text-6xl md:text-8xl font-black mb-8 leading-tight"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
              >
                <span className="block bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-glow">
                  Welcome to
                </span>
                <span className="block bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent mt-2">
                  AuthSystem
                </span>
              </motion.h1>
              
              {/* Subtitle */}
              <motion.p
                className="text-xl md:text-3xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                Your secure gateway to the future of authentication.
                <br />
                <span className="text-blue-400 font-semibold">Safe. Fast. Effortless.</span>
              </motion.p>

              {/* CTA Buttons - Made more prominent and centered */}
              <motion.div
                className="flex flex-col sm:flex-row gap-6 justify-center mb-16"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
              >
                <Link
                  href="/signup"
                  className="primary-cta-button group"
                >
                  <span className="relative z-10 flex items-center space-x-2">
                    <FaRocket className="w-5 h-5" />
                    <span>Get Started Now</span>
                  </span>
                </Link>
                <Link
                  href="/login"
                  className="secondary-cta-button group"
                >
                  <span className="relative z-10 flex items-center space-x-2">
                    <FaLock className="w-5 h-5" />
                    <span>Sign In</span>
                  </span>
                </Link>
              </motion.div>

              {/* Friendly tagline */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="text-gray-400 text-lg mb-16"
              >
                Join thousands of users who trust AuthSystem for their security needs
              </motion.div>
            </motion.div>

            {/* Features Grid */}
            <motion.div
              className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
            >
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="futuristic-card group"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.2 + (index * 0.1) }}
                  whileHover={{ 
                    scale: 1.05, 
                    y: -10,
                    transition: { duration: 0.2 }
                  }}
                >
                  <div className="text-blue-400 mb-6 flex justify-center group-hover:text-purple-400 transition-colors duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-white group-hover:text-blue-300 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors duration-300">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </main>

        {/* Footer */}
        <footer className="p-8 text-center">
          <div className="max-w-7xl mx-auto">
            <div className="glass-footer-card px-8 py-6 rounded-2xl">
              <p className="text-gray-400">
                &copy; 2025 AuthSystem. Built with ❤️ using Next.js and modern web technologies.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}