﻿
'use client'

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';

function OTPVerificationContent() {
  const [otp, setOtp] = useState('')
  const [otpArray, setOtpArray] = useState(['', '', '', '', '', ''])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [isResending, setIsResending] = useState(false)
  const [timeLeft, setTimeLeft] = useState(600) // 10 minutes
  const [canResend, setCanResend] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const [userId, setUserId] = useState('')
  const [userEmail, setUserEmail] = useState('')

  useEffect(() => {
    const id = searchParams.get('userId')
    const email = searchParams.get('email')
    if (id) setUserId(id)
    if (email) setUserEmail(email)
  }, [searchParams])

  // Countdown timer
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1)
        // Allow resend after 1 minute
        if (timeLeft === 540) setCanResend(true)
      }, 1000)
      return () => clearTimeout(timer)
    } else {
      setCanResend(true)
    }
  }, [timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  // Handle individual OTP input changes
  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtpArray = [...otpArray]
      newOtpArray[index] = value
      setOtpArray(newOtpArray)
      setOtp(newOtpArray.join(''))
      
      // Auto-focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`)
        nextInput?.focus()
      }
    }
  }

  // Handle backspace
  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otpArray[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`)
      prevInput?.focus()
    }
  }

  // Handle paste
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6)
    if (pastedData.length === 6) {
      const newArray = pastedData.split('')
      setOtpArray(newArray)
      setOtp(pastedData)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    if (otp.length !== 6) {
      setError('Please enter a 6-digit code');
      setLoading(false);
      return;
    }
    
    try {
      const res = await fetch('http://localhost:5000/api/auth/verify-login-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, otp }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        toast.success('Login successful!');
        router.push('/dashboard');
      } else {
        setError(data.message || 'Invalid verification code');
      }
    } catch (err: any) {
      console.error('OTP verification error:', err);
      if (err.message?.includes('fetch')) {
        setError('Cannot connect to server. Please ensure the backend is running.');
      } else {
        setError('Server error. Please try again.');
      }
    }
    setLoading(false);
  };

  const handleResendOTP = async () => {
    setIsResending(true);
    setError('');
    try {
      const res = await fetch('http://localhost:5000/api/auth/send-login-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        toast.success('New verification code sent to your email');
        setTimeLeft(600); // Reset timer
      } else {
        setError(data.message || 'Failed to resend code');
      }
    } catch (err: any) {
      console.error('Resend OTP error:', err);
      setError('Failed to resend code. Please try again.');
    }
    setIsResending(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      <div className="backdrop-blur-md bg-white/10 rounded-2xl p-8 shadow-2xl border border-white/20 w-full max-w-md">
        <div className="text-center mb-8">
          <motion.div 
            className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex items-center justify-center mb-4"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-2xl">🔐</span>
          </motion.div>
          <motion.h2 
            className="text-3xl font-bold text-white mb-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Enter Verification Code
          </motion.h2>
          <motion.div 
            className="text-gray-300 text-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <p>We've sent a 6-digit code to</p>
            {userEmail && (
              <p className="text-blue-400 font-medium mt-1 break-all">{userEmail}</p>
            )}
          </motion.div>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Individual OTP Input Fields */}
          <motion.div 
            className="flex justify-center space-x-3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            onPaste={handlePaste}
          >
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                value={otpArray[index]}
                onChange={(e) => handleOtpChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-14 text-center text-2xl font-bold bg-white/10 border border-white/20 rounded-lg text-white focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 focus:outline-none transition-all backdrop-blur-sm"
                disabled={loading}
                autoComplete="off"
              />
            ))}
          </motion.div>
          
          {/* Timer */}
          <motion.div 
            className="text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <div className="inline-flex items-center space-x-2 text-sm">
              {timeLeft > 0 ? (
                <>
                  <span className="text-gray-400">Code expires in</span>
                  <span className="text-blue-400 font-mono font-bold bg-blue-400/10 px-2 py-1 rounded">
                    {formatTime(timeLeft)}
                  </span>
                </>
              ) : (
                <span className="text-red-400 font-medium">⏰ Code expired</span>
              )}
            </div>
          </motion.div>
          
          {/* Error Message */}
          {error && (
            <motion.div 
              className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-lg text-sm text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {error}
            </motion.div>
          )}
          
          {/* Submit Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Button 
              type="submit" 
              disabled={loading || otp.length !== 6 || timeLeft === 0} 
              className="w-full"
              variant="gradient"
              size="lg"
              isLoading={loading}
            >
              {loading ? 'Verifying...' : 'Verify & Continue'}
            </Button>
          </motion.div>
        </form>
        
        {/* Resend Section */}
        <motion.div 
          className="mt-6 text-center space-y-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <p className="text-gray-400 text-sm">Didn't receive the code?</p>
          <Button
            onClick={handleResendOTP}
            disabled={isResending || !canResend}
            variant="ghost"
            size="sm"
            isLoading={isResending}
            className="text-blue-400 hover:text-blue-300"
          >
            {isResending ? 'Sending...' : 
             !canResend ? `Resend in ${Math.ceil((541 - timeLeft) / 60)}m` : 
             'Resend Code'}
          </Button>
        </motion.div>
        
        {/* Navigation */}
        <div className="mt-8 pt-6 border-t border-white/10 text-center space-y-3">
          <button
            onClick={() => router.push('/login')}
            className="text-gray-400 hover:text-white text-sm transition-colors inline-flex items-center"
          >
            ← Back to Login
          </button>
          <p className="text-xs text-gray-500">
            Having trouble? <a href="mailto:support@localhost" className="text-blue-400 hover:text-blue-300">Contact Support</a>
          </p>
        </div>
      </div>
    </div>
  )
}

export default function OTPVerificationPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <OTPVerificationContent />
    </Suspense>
  );
}
