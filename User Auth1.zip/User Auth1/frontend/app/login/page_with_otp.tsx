'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import toast from 'react-hot-toast'
import { FaUser, FaLock, FaArrowLeft, FaKey, FaMobile, FaEnvelope, FaClock } from 'react-icons/fa'

import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { SocialLoginGroup } from '@/components/ui/SocialButton'
import { ThemeToggle } from '@/components/theme-toggle'
import { useAuth } from '@/contexts/AuthContext'

// Login validation schema
const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Invalid email format'),
  password: z
    .string()
    .min(1, 'Password is required')
    .min(8, 'Password must be at least 8 characters'),
  rememberMe: z.boolean().optional(),
})

// OTP validation schema
const otpSchema = z.object({
  otp: z
    .string()
    .min(6, 'OTP must be 6 digits')
    .max(6, 'OTP must be 6 digits')
    .regex(/^\d{6}$/, 'OTP must contain only numbers'),
})

type LoginFormData = z.infer<typeof loginSchema>
type OTPFormData = z.infer<typeof otpSchema>

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [showOTPForm, setShowOTPForm] = useState(false)
  const [otpData, setOtpData] = useState<{
    userId: string;
    emailSent: boolean;
    smsSent: boolean;
    hasPhone: boolean;
  } | null>(null)
  const [otpTimeLeft, setOtpTimeLeft] = useState(0)
  const router = useRouter()
  const { login } = useAuth()

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
      rememberMe: false,
    },
  })

  const {
    register: registerOTP,
    handleSubmit: handleSubmitOTP,
    formState: { errors: otpErrors },
    reset: resetOTP,
  } = useForm<OTPFormData>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      otp: '',
    },
  })

  const rememberMe = watch('rememberMe')

  useEffect(() => {
    setMounted(true)
    
    // Check for registration success
    const urlParams = new URLSearchParams(window.location.search)
    if (urlParams.get('registered') === 'true') {
      toast.success('Registration successful! Please log in with your credentials.')
    }
  }, [])

  // OTP countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (showOTPForm && otpTimeLeft > 0) {
      interval = setInterval(() => {
        setOtpTimeLeft((time) => time - 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [showOTPForm, otpTimeLeft])

  // Handle form submission
  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true)
    try {
      // First verify credentials and send OTP
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: data.email,
          password: data.password,
        }),
      })

      const result = await response.json()

      if (result.success) {
        if (result.data.requiresOTP) {
          // Show OTP form
          setOtpData(result.data)
          setShowOTPForm(true)
          setOtpTimeLeft(600) // 10 minutes
          toast.success(result.message)
        } else {
          // Direct login (fallback)
          const success = await login(data.email, data.password)
          if (success) {
            router.push('/welcome')
          }
        }
      } else {
        toast.error(result.message)
      }
    } catch (error: any) {
      console.error('Login error:', error)
      toast.error('Login failed. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  // Handle OTP submission
  const onSubmitOTP = async (data: OTPFormData) => {
    if (!otpData) return
    
    setIsLoading(true)
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/verify-login-otp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: otpData.userId,
          otp: data.otp,
        }),
      })

      const result = await response.json()

      if (result.success) {
        // Store tokens and redirect
        if (result.data.tokens) {
          localStorage.setItem('accessToken', result.data.tokens.accessToken)
          localStorage.setItem('refreshToken', result.data.tokens.refreshToken)
        }
        toast.success('Login successful!')
        router.push('/welcome')
      } else {
        toast.error(result.message)
      }
    } catch (error: any) {
      console.error('OTP verification error:', error)
      toast.error('OTP verification failed. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  // Resend OTP
  const handleResendOTP = async () => {
    if (!otpData) return
    
    setIsLoading(true)
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/resend-otp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: otpData.userId,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setOtpTimeLeft(600) // Reset timer
        resetOTP()
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch (error: any) {
      console.error('Resend OTP error:', error)
      toast.error('Failed to resend OTP. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  // Go back to login form
  const handleBackToLogin = () => {
    setShowOTPForm(false)
    setOtpData(null)
    setOtpTimeLeft(0)
    resetOTP()
  }

  // Handle social login
  const handleSocialLogin = (provider: string) => {
    setIsLoading(true)
    // Redirect to backend OAuth endpoint
    window.location.href = `http://localhost:5000/api/auth/${provider}`
  }

  // Format time for countdown
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
        <div className="glass-card w-full max-w-md p-8 animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded mb-6"></div>
          <div className="space-y-4">
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-dot-pattern relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-20 left-20 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, -50, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-96 h-96 bg-purple-400/20 rounded-full blur-3xl"
          animate={{
            x: [0, -100, 0],
            y: [0, 50, 0],
            scale: [1, 0.9, 1],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      {/* Header */}
      <header className="absolute top-0 left-0 right-0 z-10 p-6">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <Link 
            href="/"
            className="flex items-center space-x-2 glass-button px-4 py-2 rounded-full text-sm"
          >
            <FaArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </Link>
          <ThemeToggle />
        </div>
      </header>

      {/* Main Content */}
      <div className="min-h-screen flex items-center justify-center p-6">
        <motion.div
          className="w-full max-w-md relative z-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Login Card */}
          <motion.div
            className="glass-card p-8 relative overflow-hidden"
            whileHover={{ y: -5 }}
            transition={{ duration: 0.3 }}
          >
            {/* Glow Effect on Hover */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-blue-400/10 via-purple-400/10 to-blue-400/10 opacity-0 hover:opacity-100 transition-opacity duration-500"
              initial={false}
            />

            {/* Header */}
            <div className="text-center mb-8 relative z-10">
              <motion.h1
                className="text-3xl font-bold glow-text mb-2"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                {showOTPForm ? 'Verify Your Identity' : 'Welcome Back'}
              </motion.h1>
              <motion.p
                className="text-gray-600 dark:text-gray-400"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                {showOTPForm ? 'Enter the verification code sent to you' : 'Sign in to access your account'}
              </motion.p>
            </div>

            {/* Login Form or OTP Form */}
            <AnimatePresence mode="wait">
              {!showOTPForm ? (
                <motion.form
                  key="login-form"
                  onSubmit={handleSubmit(onSubmit)}
                  className="space-y-6 relative z-10"
                  initial={{ opacity: 0, x: 0 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                  >
                    <Input
                      {...register('email')}
                      type="email"
                      label="Email Address"
                      placeholder="Enter your email"
                      icon={<FaUser className="w-5 h-5" />}
                      error={errors.email?.message}
                      disabled={isLoading}
                    />
                  </motion.div>

                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                  >
                    <Input
                      {...register('password')}
                      type="password"
                      label="Password"
                      placeholder="Enter your password"
                      icon={<FaLock className="w-5 h-5" />}
                      error={errors.password?.message}
                      disabled={isLoading}
                    />
                  </motion.div>

                  {/* Remember Me & Forgot Password */}
                  <motion.div
                    className="flex items-center justify-between"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                  >
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        {...register('rememberMe')}
                        className="w-4 h-4 text-blue-600 bg-transparent border-2 border-gray-300 dark:border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                        disabled={isLoading}
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        Remember me
                      </span>
                    </label>
                    <Link
                      href="/forgot-password"
                      className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
                    >
                      Forgot Password?
                    </Link>
                  </motion.div>

                  {/* Login Button */}
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                  >
                    <Button
                      type="submit"
                      variant="gradient"
                      size="lg"
                      isLoading={isLoading}
                      disabled={isLoading}
                      className="w-full"
                      glow
                    >
                      {isLoading ? 'Signing In...' : 'Sign In'}
                    </Button>
                  </motion.div>
                </motion.form>
              ) : (
                <motion.div
                  key="otp-form"
                  className="space-y-6 relative z-10"
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 100 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* OTP Header */}
                  <div className="text-center mb-6">
                    <motion.div
                      className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4"
                      animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <FaKey className="w-8 h-8 text-white" />
                    </motion.div>
                    <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">
                      Enter Verification Code
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">
                      We've sent a 6-digit code to:
                    </p>
                    <div className="flex items-center justify-center space-x-4 mt-2">
                      {otpData?.emailSent && (
                        <div className="flex items-center space-x-1 text-blue-600 dark:text-blue-400">
                          <FaEnvelope className="w-4 h-4" />
                          <span className="text-sm">Email</span>
                        </div>
                      )}
                      {otpData?.smsSent && (
                        <div className="flex items-center space-x-1 text-green-600 dark:text-green-400">
                          <FaMobile className="w-4 h-4" />
                          <span className="text-sm">SMS</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* OTP Form */}
                  <form onSubmit={handleSubmitOTP(onSubmitOTP)} className="space-y-6">
                    <motion.div
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.3, delay: 0.1 }}
                    >
                      <Input
                        {...registerOTP('otp')}
                        type="text"
                        label="Verification Code"
                        placeholder="Enter 6-digit code"
                        icon={<FaKey className="w-5 h-5" />}
                        error={otpErrors.otp?.message}
                        disabled={isLoading}
                        maxLength={6}
                        className="text-center text-xl tracking-wider font-mono"
                      />
                    </motion.div>

                    {/* Timer and Resend */}
                    <motion.div
                      className="flex items-center justify-between text-sm"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: 0.2 }}
                    >
                      {otpTimeLeft > 0 ? (
                        <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-400">
                          <FaClock className="w-4 h-4" />
                          <span>Code expires in {formatTime(otpTimeLeft)}</span>
                        </div>
                      ) : (
                        <div className="text-red-500">
                          Code has expired
                        </div>
                      )}
                      
                      <button
                        type="button"
                        onClick={handleResendOTP}
                        disabled={isLoading || otpTimeLeft > 540} // Allow resend after 1 minute
                        className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Resend Code
                      </button>
                    </motion.div>

                    {/* Submit Button */}
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ duration: 0.3, delay: 0.3 }}
                    >
                      <Button
                        type="submit"
                        variant="gradient"
                        size="lg"
                        isLoading={isLoading}
                        disabled={isLoading || otpTimeLeft <= 0}
                        className="w-full"
                        glow
                      >
                        {isLoading ? 'Verifying...' : 'Verify Code'}
                      </Button>
                    </motion.div>

                    {/* Back Button */}
                    <motion.div
                      className="text-center"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: 0.4 }}
                    >
                      <button
                        type="button"
                        onClick={handleBackToLogin}
                        className="text-gray-600 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 text-sm transition-colors"
                      >
                        ← Back to Login
                      </button>
                    </motion.div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Social Login - Only show for login form */}
            {!showOTPForm && (
              <motion.div
                className="mt-8 relative z-10"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.7 }}
              >
                <SocialLoginGroup
                  onGoogleClick={() => handleSocialLogin('google')}
                  onFacebookClick={() => handleSocialLogin('facebook')}
                  isLoading={isLoading}
                />
              </motion.div>
            )}

            {/* Sign Up Link - Only show for login form */}
            {!showOTPForm && (
              <motion.div
                className="mt-8 text-center relative z-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.8 }}
              >
                <p className="text-gray-600 dark:text-gray-400">
                  Don&apos;t have an account?{' '}
                  <Link
                    href="/signup"
                    className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-medium transition-colors"
                  >
                    Sign up here
                  </Link>
                </p>
              </motion.div>
            )}
          </motion.div>

          {/* Floating Particles Effect */}
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-blue-400/30 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, -100, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: Math.random() * 3 + 2,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                }}
              />
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}