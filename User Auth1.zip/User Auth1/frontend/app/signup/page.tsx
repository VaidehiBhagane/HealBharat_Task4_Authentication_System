'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import toast from 'react-hot-toast'
import { 
  FaUser, 
  FaEnvelope, 
  FaLock, 
  FaEye, 
  FaEyeSlash, 
  FaArrowLeft,
  FaPhone,
  FaCheck
} from 'react-icons/fa'

import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { SocialLoginGroup } from '@/components/ui/SocialButton'
import { ThemeToggle } from '@/components/theme-toggle'
import { useAuth } from '@/contexts/AuthContext'

// Registration validation schema
const registerSchema = z.object({
  firstName: z
    .string()
    .min(1, 'First name is required')
    .min(2, 'First name must be at least 2 characters')
    .max(50, 'First name must be less than 50 characters'),
  lastName: z
    .string()
    .min(1, 'Last name is required')
    .min(2, 'Last name must be at least 2 characters')
    .max(50, 'Last name must be less than 50 characters'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Invalid email format'),
  phoneNumber: z
    .string()
    .optional()
    .refine((val) => !val || /^[\+]?[1-9][\d]{0,15}$/.test(val), {
      message: 'Invalid phone number format'
    }),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),
  confirmPassword: z.string().min(1, 'Please confirm your password'),
  agreeToTerms: z.boolean().refine((val) => val === true, {
    message: 'You must agree to the terms and conditions'
  })
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword']
})

type RegisterFormData = z.infer<typeof registerSchema>

export default function SignupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [mounted, setMounted] = useState(false)
  const router = useRouter()
  const { isAuthenticated } = useAuth()

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    watch,
    setValue
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    mode: 'onChange'
  })

  // Redirect if already authenticated
  useEffect(() => {
    setMounted(true)
    if (isAuthenticated) {
      router.push('/welcome')
    }
  }, [isAuthenticated, router])

  // Watch password for strength indicator
  const password = watch('password', '')

  // Password strength checker
  const getPasswordStrength = (password: string) => {
    const checks = [
      password.length >= 8,
      /[A-Z]/.test(password),
      /[a-z]/.test(password),
      /[0-9]/.test(password),
      /[^A-Za-z0-9]/.test(password)
    ]
    const score = checks.filter(Boolean).length
    
    if (score <= 2) return { level: 'weak', color: 'bg-red-500', text: 'Weak' }
    if (score <= 3) return { level: 'medium', color: 'bg-yellow-500', text: 'Medium' }
    if (score <= 4) return { level: 'good', color: 'bg-blue-500', text: 'Good' }
    return { level: 'strong', color: 'bg-green-500', text: 'Strong' }
  }

  // Handle form submission
  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true)
    
    try {
      const response = await fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
          password: data.password,
          phoneNumber: data.phoneNumber || undefined
        }),
      })

      // Check if request was successful (server responded)
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        const errorMessage = errorData.message || `Server error: ${response.status}`
        toast.error(errorMessage)
        return
      }

      const result = await response.json()

      if (result.success) {
        toast.success('Account created successfully! Please check your email for verification.')
        // For now, redirect to login page after successful registration
        // In the future, you can implement auto-login and redirect to welcome
        router.push(`/login?registered=true&email=${encodeURIComponent(data.email)}`)
      } else {
        toast.error(result.message || 'Registration failed')
      }
    } catch (error: any) {
      console.error('Registration error:', error)
      
      // Check if it's a network error (backend not running)
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        toast.error('Cannot connect to server. Please ensure the backend is running on port 5000.')
      } else if (error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
        toast.error('Network error. Please check your internet connection and ensure the backend server is running.')
      } else {
        toast.error('An unexpected error occurred. Please try again.')
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Handle social login
  const handleSocialLogin = (provider: string) => {
    setIsLoading(true)
    // Redirect to backend OAuth endpoint
    window.location.href = `http://localhost:5000/api/auth/${provider}`
  }

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
        <div className="glass-card w-full max-w-md p-8 animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded mb-6"></div>
          <div className="space-y-4">
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  const passwordStrength = getPasswordStrength(password)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-md space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <Link href="/" className="inline-block">
            <motion.h1
              className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300, damping: 10 }}
            >
              Auth System
            </motion.h1>
          </Link>
          <p className="mt-2 text-gray-300">Create your account to get started</p>
        </motion.div>

        {/* Sign Up Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="backdrop-blur-md bg-white/10 rounded-2xl p-8 shadow-2xl border border-white/20"
        >
          {/* Back to Login Link */}
          <Link
            href="/login"
            className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors mb-6"
          >
            <FaArrowLeft className="mr-2" />
            Back to Login
          </Link>

          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">Create Account</h2>
            <p className="text-gray-300 text-sm">Join us and start your journey</p>
          </div>

          {/* Social Login */}
          <div className="mb-6">
            <SocialLoginGroup
              onGoogleClick={() => handleSocialLogin('google')}
              onFacebookClick={() => handleSocialLogin('facebook')}
              isLoading={isLoading}
            />
          </div>

          {/* Divider */}
          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/20" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 text-gray-400 bg-transparent">Or create with email</span>
            </div>
          </div>

          {/* Registration Form */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {/* Name Fields */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Input
                  type="text"
                  placeholder="First name"
                  icon={<FaUser />}
                  error={errors.firstName?.message}
                  {...register('firstName')}
                  disabled={isLoading}
                />
              </div>
              <div>
                <Input
                  type="text"
                  placeholder="Last name"
                  icon={<FaUser />}
                  error={errors.lastName?.message}
                  {...register('lastName')}
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* Email Field */}
            <Input
              type="email"
              placeholder="Email address"
              icon={<FaEnvelope />}
              error={errors.email?.message}
              {...register('email')}
              disabled={isLoading}
            />

            {/* Phone Field (Optional) */}
            <Input
              type="tel"
              placeholder="Phone number (optional)"
              icon={<FaPhone />}
              error={errors.phoneNumber?.message}
              {...register('phoneNumber')}
              disabled={isLoading}
            />

            {/* Password Field */}
            <div>
              <Input
                type="password"
                placeholder="Password"
                icon={<FaLock />}
                error={errors.password?.message}
                {...register('password')}
                disabled={isLoading}
              />
              
              {/* Password Strength Indicator */}
              {password && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-2"
                >
                  <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                    <span>Password strength:</span>
                    <span className={`font-medium ${
                      passwordStrength.level === 'strong' ? 'text-green-400' :
                      passwordStrength.level === 'good' ? 'text-blue-400' :
                      passwordStrength.level === 'medium' ? 'text-yellow-400' : 'text-red-400'
                    }`}>
                      {passwordStrength.text}
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-1">
                    <div
                      className={`h-1 rounded-full transition-all duration-300 ${passwordStrength.color}`}
                      style={{ width: `${(getPasswordStrength(password).level === 'weak' ? 20 : 
                        getPasswordStrength(password).level === 'medium' ? 40 :
                        getPasswordStrength(password).level === 'good' ? 70 : 100)}%` }}
                    />
                  </div>
                </motion.div>
              )}
            </div>

            {/* Confirm Password Field */}
            <Input
              type="password"
              placeholder="Confirm password"
              icon={<FaLock />}
              error={errors.confirmPassword?.message}
              {...register('confirmPassword')}
              disabled={isLoading}
            />

            {/* Terms and Conditions */}
            <div className="flex items-start space-x-3">
              <div className="flex items-center h-5">
                <input
                  type="checkbox"
                  {...register('agreeToTerms')}
                  className="w-4 h-4 text-blue-500 bg-transparent border border-gray-400 rounded focus:ring-2 focus:ring-blue-500 focus:ring-offset-0"
                  disabled={isLoading}
                />
              </div>
              <div className="text-sm">
                <label className="text-gray-300">
                  I agree to the{' '}
                  <Link href="/terms" className="text-blue-400 hover:text-blue-300 underline">
                    Terms of Service
                  </Link>
                  {' '}and{' '}
                  <Link href="/privacy" className="text-blue-400 hover:text-blue-300 underline">
                    Privacy Policy
                  </Link>
                </label>
                {errors.agreeToTerms && (
                  <p className="mt-1 text-red-400 text-xs">{errors.agreeToTerms.message}</p>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              variant="gradient"
              size="lg"
              className="w-full"
              disabled={isLoading || !isValid}
              isLoading={isLoading}
            >
              {isLoading ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>

          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Already have an account?{' '}
              <Link
                href="/login"
                className="text-blue-400 hover:text-blue-300 font-medium transition-colors"
              >
                Sign in here
              </Link>
            </p>
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center text-gray-400 text-sm"
        >
          <p>&copy; 2024 Auth System. All rights reserved.</p>
        </motion.div>
      </div>
    </div>
  )
}