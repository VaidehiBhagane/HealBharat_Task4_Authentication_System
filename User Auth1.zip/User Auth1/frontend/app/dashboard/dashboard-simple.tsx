'use client';

import React from 'react';
import ProfileDashboard from '@/components/ProfileDashboard';

export default function Dashboard() {
  return <ProfileDashboard />;
}