'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useAuthNavigation, AuthGuard } from '@/lib/navigation';
import { FiUser, FiMail, FiCheck, FiArrowRight, FiStar, FiShield } from 'react-icons/fi';

const WelcomePage = () => {
  const { user } = useAuth();
  const { navigateAfterLogin } = useAuthNavigation();
  const [currentStep, setCurrentStep] = useState(0);
  const [showContinue, setShowContinue] = useState(false);

  const welcomeSteps = [
    {
      icon: FiUser,
      title: "Welcome Back!",
      description: `Hi ${user?.firstName || 'there'}, great to see you again!`,
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: FiCheck,
      title: "You're All Set",
      description: "Your account is verified and ready to use.",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: user?.role === 'admin' ? FiShield : FiStar,
      title: user?.role === 'admin' ? "Admin Access" : "Ready to Explore",
      description: user?.role === 'admin' 
        ? "You have administrator privileges and can manage the system."
        : "Let's get you to your dashboard where you can manage your profile and settings.",
      color: user?.role === 'admin' ? "from-purple-500 to-pink-500" : "from-indigo-500 to-purple-500"
    }
  ];

  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < welcomeSteps.length - 1) {
          return prev + 1;
        } else {
          clearInterval(stepInterval);
          setTimeout(() => setShowContinue(true), 500);
          return prev;
        }
      });
    }, 1500);

    // Auto-redirect after 8 seconds if user doesn't click continue
    const autoRedirect = setTimeout(() => {
      navigateAfterLogin(user, true);
    }, 8000);

    return () => {
      clearInterval(stepInterval);
      clearTimeout(autoRedirect);
    };
  }, [user, navigateAfterLogin]);

  const handleContinue = () => {
    navigateAfterLogin(user, true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="relative">
        {/* Background decoration */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl"></div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 md:p-12 max-w-2xl w-full text-center shadow-2xl"
        >
          {/* User Avatar */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="relative mx-auto w-20 h-20 mb-8"
          >
            <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg">
              {user?.firstName?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || 'U'}
            </div>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center"
            >
              <FiCheck className="w-3 h-3 text-white" />
            </motion.div>
          </motion.div>

          {/* Welcome Steps */}
          <div className="space-y-8">
            {welcomeSteps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index <= currentStep;
              const isCurrent = index === currentStep;

              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ 
                    opacity: isActive ? 1 : 0.3,
                    y: isActive ? 0 : 20,
                    scale: isCurrent ? 1.05 : 1
                  }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative ${isCurrent ? 'z-10' : ''}`}
                >
                  <div className="flex items-center justify-center space-x-4">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xl font-semibold text-white mb-1">{step.title}</h3>
                      <p className="text-gray-300 text-sm max-w-md">{step.description}</p>
                    </div>
                  </div>
                  
                  {isCurrent && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute inset-0 bg-white/5 rounded-2xl -z-10 backdrop-blur-sm"
                    />
                  )}
                </motion.div>
              );
            })}
          </div>

          {/* User Info Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: currentStep >= 2 ? 1 : 0, y: currentStep >= 2 ? 0 : 20 }}
            className="mt-8 p-6 bg-white/5 rounded-2xl border border-white/10"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <FiMail className="w-4 h-4 text-blue-400" />
                <span className="text-gray-300">{user?.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                <FiUser className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">{user?.firstName} {user?.lastName}</span>
              </div>
              {user?.role && (
                <div className="flex items-center space-x-2">
                  <FiShield className="w-4 h-4 text-purple-400" />
                  <span className="text-gray-300 capitalize">{user.role}</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <FiCheck className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">Email Verified</span>
              </div>
            </div>
          </motion.div>

          {/* Continue Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: showContinue ? 1 : 0, y: showContinue ? 0 : 20 }}
            className="mt-8"
          >
            <button
              onClick={handleContinue}
              className="group inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold px-8 py-4 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <span>Continue to Dashboard</span>
              <FiArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="text-gray-400 text-xs mt-3">
              You'll be redirected automatically in a few seconds
            </p>
          </motion.div>

          {/* Progress Indicator */}
          <div className="flex justify-center space-x-2 mt-6">
            {welcomeSteps.map((_, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0.5 }}
                animate={{ 
                  scale: index <= currentStep ? 1 : 0.5,
                  backgroundColor: index <= currentStep ? '#3B82F6' : '#374151'
                }}
                className="w-2 h-2 rounded-full"
              />
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const WelcomePageWithGuard = () => {
  return (
    <AuthGuard>
      <WelcomePage />
    </AuthGuard>
  );
};

export default WelcomePageWithGuard;