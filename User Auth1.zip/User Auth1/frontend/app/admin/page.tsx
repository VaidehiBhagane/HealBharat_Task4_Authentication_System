'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import { 
  FaUsers, 
  FaUserShield, 
  FaSearch, 
  FaTrash,
  FaBan,
  FaCheck,
  FaArrowLeft,
  FaRedo,
  FaCrown,
  FaShieldAlt,
  FaExclamationTriangle,
  FaEye
} from 'react-icons/fa'
import { useAuth } from '@/contexts/AuthContext'
import toast from 'react-hot-toast'

interface User {
  _id: string
  firstName: string
  lastName: string
  email: string
  role: 'admin' | 'user' | 'moderator'
  isActive: boolean
  isEmailVerified: boolean
  isPhoneVerified?: boolean
  phoneNumber?: string
  lastLogin?: string
  createdAt: string
  profilePicture?: string
  provider: string
}

interface AdminStats {
  totalUsers: number
  activeUsers: number
  adminUsers: number
  verifiedUsers: number
}

function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([])
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    activeUsers: 0,
    adminUsers: 0,
    verifiedUsers: 0
  })
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [error, setError] = useState<string>('')
  const { user } = useAuth()
  const router = useRouter()

  // Check admin access
  useEffect(() => {
    const checkAdminAccess = () => {
      const token = localStorage.getItem('accessToken')
      const userData = localStorage.getItem('user')
      
      if (!token) {
        toast.error('Please login first')
        router.push('/login')
        return
      }

      if (userData) {
        const parsedUser = JSON.parse(userData)
        if (parsedUser.role !== 'admin') {
          toast.error('Admin access required')
          router.push('/')
          return
        }
      }
    }

    checkAdminAccess()
  }, [router])

  // Fetch users and stats from backend
  const fetchData = async () => {
    try {
      setLoading(true)
      setError('')
      const token = localStorage.getItem('accessToken')
      
      if (!token) {
        toast.error('Authentication required')
        router.push('/login')
        return
      }

      console.log('🔍 Fetching admin data with token:', token.substring(0, 20) + '...')

      // Fetch users
      const usersResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      console.log('📊 Users API Response Status:', usersResponse.status)

      if (!usersResponse.ok) {
        if (usersResponse.status === 401) {
          toast.error('Admin authentication failed')
          localStorage.clear()
          router.push('/login')
          return
        }
        throw new Error(`API Error: ${usersResponse.status}`)
      }

      const usersData = await usersResponse.json()
      console.log('👥 Users Data:', usersData)
      
      const usersList = usersData.data?.users || usersData.data || []
      setUsers(usersList)

      // Calculate stats from users data
      const calculatedStats = {
        totalUsers: usersList.length,
        activeUsers: usersList.filter((u: User) => u.isActive).length,
        adminUsers: usersList.filter((u: User) => u.role === 'admin').length,
        verifiedUsers: usersList.filter((u: User) => u.isEmailVerified).length
      }
      setStats(calculatedStats)

      toast.success(`Loaded ${usersList.length} users`)

    } catch (error: any) {
      console.error('❌ Error fetching admin data:', error)
      setError(error.message || 'Failed to load admin data')
      toast.error(error.message || 'Failed to load admin data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  // Filter users based on search
  const filteredUsers = users.filter(userItem => {
    const searchString = `${userItem.firstName} ${userItem.lastName} ${userItem.email}`.toLowerCase()
    return searchString.includes(searchTerm.toLowerCase())
  })

  // Toggle user status
  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const token = localStorage.getItem('accessToken')
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users/${userId}/status`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isActive: !currentStatus })
      })

      if (response.ok) {
        toast.success(`User ${currentStatus ? 'deactivated' : 'activated'} successfully`)
        fetchData() // Refresh data
      } else {
        throw new Error('Failed to update user status')
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user status')
    }
  }

  // Delete user
  const deleteUser = async (userId: string, userEmail: string) => {
    if (!confirm(`Are you sure you want to delete user: ${userEmail}?\n\nThis action cannot be undone.`)) {
      return
    }

    try {
      const token = localStorage.getItem('accessToken')
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      if (response.ok) {
        toast.success('User deleted successfully')
        fetchData() // Refresh data
      } else {
        throw new Error('Failed to delete user')
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete user')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading Admin Dashboard...</p>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => router.push('/')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all duration-200"
              >
                <FaArrowLeft className="w-4 h-4" />
                <span>Back to Home</span>
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
                  <FaShieldAlt className="w-6 h-6 text-red-400" />
                  <span>Admin Dashboard</span>
                </h1>
                <p className="text-gray-300">Manage users and system settings</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-300 flex items-center space-x-2">
                <FaCrown className="w-4 h-4 text-yellow-400" />
                <span>Welcome, {user?.firstName} {user?.lastName}</span>
              </span>
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center">
                <FaUserShield className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Error Display */}
        {error && (
          <motion.div 
            className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center space-x-2 text-red-300">
              <FaExclamationTriangle className="w-5 h-5" />
              <span>Error: {error}</span>
            </div>
          </motion.div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            className="bg-black/20 backdrop-blur-lg rounded-xl p-6 border border-white/10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Users</p>
                <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
              </div>
              <FaUsers className="w-8 h-8 text-blue-500" />
            </div>
          </motion.div>

          <motion.div
            className="bg-black/20 backdrop-blur-lg rounded-xl p-6 border border-white/10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Users</p>
                <p className="text-3xl font-bold text-green-500">{stats.activeUsers}</p>
              </div>
              <FaCheck className="w-8 h-8 text-green-500" />
            </div>
          </motion.div>

          <motion.div
            className="bg-black/20 backdrop-blur-lg rounded-xl p-6 border border-white/10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Admin Users</p>
                <p className="text-3xl font-bold text-purple-500">{stats.adminUsers}</p>
              </div>
              <FaUserShield className="w-8 h-8 text-purple-500" />
            </div>
          </motion.div>

          <motion.div
            className="bg-black/20 backdrop-blur-lg rounded-xl p-6 border border-white/10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Verified Users</p>
                <p className="text-3xl font-bold text-yellow-500">{stats.verifiedUsers}</p>
              </div>
              <FaEye className="w-8 h-8 text-yellow-500" />
            </div>
          </motion.div>
        </div>

        {/* Controls */}
        <motion.div
          className="bg-black/20 backdrop-blur-lg rounded-xl p-6 border border-white/10 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="relative">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search users by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-64 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <button
              onClick={fetchData}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
            >
              <FaRedo className="w-4 h-4" />
              <span>Refresh</span>
            </button>


          </div>
          
          <div className="mt-4 text-sm text-gray-400">
            Showing {filteredUsers.length} of {users.length} total users
          </div>
        </motion.div>

        {/* Users Table */}
        <motion.div
          className="bg-black/20 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">User</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Email</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Role</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Verified</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filteredUsers.map((userItem) => (
                  <tr key={userItem._id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center relative">
                          <span className="text-white font-medium text-sm">
                            {userItem.firstName[0]}{userItem.lastName[0]}
                          </span>
                          {userItem.role === 'admin' && (
                            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                              <FaCrown className="w-2 h-2 text-white" />
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="text-white font-medium">{userItem.firstName} {userItem.lastName}</p>
                          <p className="text-gray-400 text-xs">ID: {userItem._id.slice(-8)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-300">{userItem.email}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        userItem.role === 'admin' 
                          ? 'bg-red-500/20 text-red-300 border border-red-500/30' 
                          : userItem.role === 'moderator'
                          ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          : 'bg-gray-500/20 text-gray-300 border border-gray-500/30'
                      }`}>
                        {userItem.role.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        userItem.isActive 
                          ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
                          : 'bg-red-500/20 text-red-300 border border-red-500/30'
                      }`}>
                        {userItem.isActive ? 'ACTIVE' : 'INACTIVE'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        userItem.isEmailVerified 
                          ? 'bg-green-500/20 text-green-300' 
                          : 'bg-yellow-500/20 text-yellow-300'
                      }`}>
                        {userItem.isEmailVerified ? 'Verified' : 'Unverified'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-300 text-sm">
                      {userItem.lastLogin 
                        ? new Date(userItem.lastLogin).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : 'Never'}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => toggleUserStatus(userItem._id, userItem.isActive)}
                          className={`p-2 rounded-lg transition-colors ${
                            userItem.isActive 
                              ? 'bg-red-500/20 hover:bg-red-500/30 text-red-300' 
                              : 'bg-green-500/20 hover:bg-green-500/30 text-green-300'
                          }`}
                          title={userItem.isActive ? 'Deactivate User' : 'Activate User'}
                        >
                          {userItem.isActive ? <FaBan className="w-4 h-4" /> : <FaCheck className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => deleteUser(userItem._id, userItem.email)}
                          className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 transition-colors"
                          title="Delete User"
                          disabled={userItem._id === user?.id} // Prevent self-deletion
                        >
                          <FaTrash className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredUsers.length === 0 && !loading && (
            <div className="text-center py-12">
              <FaUsers className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">No users found</p>
              <p className="text-gray-500">Try adjusting your search or refresh the page</p>
              <button
                onClick={fetchData}
                className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
              >
                Retry Loading
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default AdminDashboard