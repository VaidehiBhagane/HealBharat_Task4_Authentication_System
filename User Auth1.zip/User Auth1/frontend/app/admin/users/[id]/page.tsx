'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { FaUser, FaEnvelope, FaPhone, FaCalendar, FaHistory, FaBan, FaCheck, FaEdit } from 'react-icons/fa'
import AdminLayout from '../../../../components/admin/AdminLayout'

interface User {
  _id: string
  firstName: string
  lastName: string
  email: string
  phoneNumber?: string
  role: string
  isActive: boolean
  isEmailVerified: boolean
  isPhoneVerified: boolean
  twoFactorEnabled: boolean
  provider: string
  lastLogin?: string
  loginAttempts: number
  createdAt: string
  updatedAt: string
}

interface ActivityLog {
  _id: string
  action: string
  details: any
  createdAt: string
  success: boolean
  ipAddress?: string
}

export default function UserDetailPage() {
  const params = useParams()
  const userId = params.id as string
  
  const [user, setUser] = useState<User | null>(null)
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([])
  const [loading, setLoading] = useState(true)
  const [logsLoading, setLogsLoading] = useState(false)

  useEffect(() => {
    if (userId) {
      fetchUserDetails()
      fetchUserLogs()
    }
  }, [userId])

  const fetchUserDetails = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${userId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.data.user)
      }
    } catch (error) {
      console.error('Error fetching user details:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUserLogs = async () => {
    setLogsLoading(true)
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${userId}/logs?limit=50`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setActivityLogs(data.data.logs)
      }
    } catch (error) {
      console.error('Error fetching user logs:', error)
    } finally {
      setLogsLoading(false)
    }
  }

  const handleUserStatusToggle = async () => {
    if (!user) return
    
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${userId}/status`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          isActive: !user.isActive,
          reason: !user.isActive ? 'Account activated by admin' : 'Account deactivated by admin'
        })
      })

      if (response.ok) {
        setUser({ ...user, isActive: !user.isActive })
      }
    } catch (error) {
      console.error('Error updating user status:', error)
    }
  }

  const handleResetPassword = async () => {
    if (!confirm('Are you sure you want to reset this user\'s password?')) return

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${userId}/reset-password`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ forceReset: true })
      })

      if (response.ok) {
        const data = await response.json()
        alert(`Password reset successful. New temporary password: ${data.data.temporaryPassword}`)
        fetchUserLogs() // Refresh logs
      }
    } catch (error) {
      console.error('Error resetting password:', error)
    }
  }

  const getActionBadgeColor = (action: string) => {
    switch (action) {
      case 'LOGIN':
        return 'bg-green-100 text-green-800'
      case 'LOGOUT':
        return 'bg-gray-100 text-gray-800'
      case 'LOGIN_FAILED':
        return 'bg-red-100 text-red-800'
      case 'PASSWORD_CHANGE':
        return 'bg-blue-100 text-blue-800'
      case 'PASSWORD_RESET_BY_ADMIN':
        return 'bg-orange-100 text-orange-800'
      case 'ACCOUNT_ACTIVATED':
        return 'bg-green-100 text-green-800'
      case 'ACCOUNT_DEACTIVATED':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </AdminLayout>
    )
  }

  if (!user) {
    return (
      <AdminLayout>
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">User Not Found</h2>
          <p className="text-gray-600">The requested user could not be found.</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">User Details</h1>
            <p className="text-gray-600">Detailed information about {user.firstName} {user.lastName}</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleUserStatusToggle}
              className={`px-4 py-2 rounded-lg transition-colors flex items-center space-x-2 ${
                user.isActive 
                  ? 'bg-red-600 hover:bg-red-700 text-white' 
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {user.isActive ? <FaBan className="w-4 h-4" /> : <FaCheck className="w-4 h-4" />}
              <span>{user.isActive ? 'Deactivate' : 'Activate'}</span>
            </button>
            <button
              onClick={handleResetPassword}
              className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
            >
              <FaEdit className="w-4 h-4" />
              <span>Reset Password</span>
            </button>
          </div>
        </div>

        {/* User Info Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Basic Information */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <FaUser className="w-5 h-5 mr-2 text-blue-600" />
              Basic Information
            </h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">
                    {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                  </span>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-gray-900">
                    {user.firstName} {user.lastName}
                  </h4>
                  <p className="text-gray-600">{user.email}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">User ID</label>
                  <p className="text-gray-900 font-mono text-sm">{user._id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Role</label>
                  <p className="text-gray-900">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      user.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.role}
                    </span>
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Phone Number</label>
                  <p className="text-gray-900">{user.phoneNumber || 'Not provided'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Provider</label>
                  <p className="text-gray-900 capitalize">{user.provider}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Account Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Status</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Account Status</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${user.isActive ? 'bg-green-400' : 'bg-red-400'}`} />
                  <span className={`text-sm font-medium ${user.isActive ? 'text-green-800' : 'text-red-800'}`}>
                    {user.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Email Verified</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  user.isEmailVerified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {user.isEmailVerified ? 'Verified' : 'Unverified'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Phone Verified</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  user.isPhoneVerified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {user.isPhoneVerified ? 'Verified' : 'Unverified'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">2FA Enabled</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  user.twoFactorEnabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {user.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Login Attempts</span>
                <span className={`text-sm font-medium ${
                  user.loginAttempts > 3 ? 'text-red-600' : 'text-gray-900'
                }`}>
                  {user.loginAttempts}
                </span>
              </div>
            </div>
          </motion.div>

          {/* Timestamps */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <FaCalendar className="w-5 h-5 mr-2 text-blue-600" />
              Timestamps
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Joined</label>
                <p className="text-gray-900">{new Date(user.createdAt).toLocaleString()}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Last Updated</label>
                <p className="text-gray-900">{new Date(user.updatedAt).toLocaleString()}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Last Login</label>
                <p className="text-gray-900">
                  {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'Never'}
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Activity Log */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg"
        >
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <FaHistory className="w-5 h-5 mr-2 text-blue-600" />
            Recent Activity
          </h3>
          
          {logsLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {activityLogs.length > 0 ? (
                activityLogs.map((log) => (
                  <div key={log._id} className="flex items-center justify-between p-3 border border-gray-100 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getActionBadgeColor(log.action)}`}>
                        {log.action.replace(/_/g, ' ')}
                      </span>
                      <span className="text-sm text-gray-600">
                        {new Date(log.createdAt).toLocaleString()}
                      </span>
                      {log.ipAddress && (
                        <span className="text-xs text-gray-500 font-mono">
                          {log.ipAddress}
                        </span>
                      )}
                    </div>
                    <div className={`w-2 h-2 rounded-full ${log.success ? 'bg-green-400' : 'bg-red-400'}`} />
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No activity logs available</p>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </AdminLayout>
  )
}