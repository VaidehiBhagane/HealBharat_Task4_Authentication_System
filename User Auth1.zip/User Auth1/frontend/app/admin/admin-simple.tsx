'use client';

import React from 'react';
import AdminPanel from '@/components/AdminPanel';

export default function AdminPage() {
  return <AdminPanel />;
}