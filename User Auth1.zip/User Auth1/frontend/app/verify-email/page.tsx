'use client'

import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { FaCheckCircle, FaTimesCircle, FaSpinner, FaEnvelope, FaArrowLeft } from 'react-icons/fa'

import { Button } from '@/components/ui/Button'

function EmailVerificationContent() {
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'verifying' | 'success' | 'error' | 'expired'>('pending')
  const [message, setMessage] = useState('')
  const [isResending, setIsResending] = useState(false)
  const [userEmail, setUserEmail] = useState('')
  const [firstName, setFirstName] = useState('')
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const token = searchParams.get('token')
    const email = searchParams.get('email')
    const name = searchParams.get('firstName')
    
    if (email) setUserEmail(email)
    if (name) setFirstName(name)
    
    if (token) {
      setVerificationStatus('verifying')
      verifyEmail(token)
    } else if (email) {
      setVerificationStatus('pending')
      setMessage(`We've sent a verification email to ${email}. Please check your inbox and click the verification link.`)
    } else {
      setVerificationStatus('error')
      setMessage('No verification information provided')
    }
  }, [searchParams])

  const verifyEmail = async (token: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/auth/verify-email/${token}`)
      const data = await response.json()

      if (data.success) {
        setVerificationStatus('success')
        setMessage(data.message)
        toast.success('Email verified successfully!')
        
        // Redirect to login after 3 seconds
        setTimeout(() => {
          router.push('/login?verified=true')
        }, 3000)
      } else {
        if (data.message.includes('expired')) {
          setVerificationStatus('expired')
        } else {
          setVerificationStatus('error')
        }
        setMessage(data.message)
        toast.error(data.message)
      }
    } catch (error) {
      console.error('Verification error:', error)
      setVerificationStatus('error')
      setMessage('Failed to verify email. Please try again.')
      toast.error('Verification failed')
    }
  }

  const resendVerification = async () => {
    const email = searchParams.get('email')
    if (!email) {
      toast.error('Email address is required to resend verification')
      return
    }

    setIsResending(true)
    try {
      const response = await fetch('http://localhost:5000/api/auth/resend-verification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()
      
      if (data.success) {
        toast.success('Verification email sent! Please check your inbox.')
        setMessage('A new verification email has been sent to your inbox.')
      } else {
        toast.error(data.message)
      }
    } catch (error) {
      console.error('Resend error:', error)
      toast.error('Failed to resend verification email')
    } finally {
      setIsResending(false)
    }
  }

  const getStatusIcon = () => {
    switch (verificationStatus) {
      case 'verifying':
        return <FaSpinner className="w-16 h-16 text-blue-500 animate-spin" />
      case 'success':
        return <FaCheckCircle className="w-16 h-16 text-green-500" />
      case 'error':
      case 'expired':
        return <FaTimesCircle className="w-16 h-16 text-red-500" />
      default:
        return <FaEnvelope className="w-16 h-16 text-gray-500" />
    }
  }

  const getStatusColor = () => {
    switch (verificationStatus) {
      case 'verifying':
        return 'text-blue-500'
      case 'success':
        return 'text-green-500'
      case 'error':
      case 'expired':
        return 'text-red-500'
      default:
        return 'text-gray-500'
    }
  }

  const getStatusTitle = () => {
    switch (verificationStatus) {
      case 'verifying':
        return 'Verifying Your Email...'
      case 'success':
        return 'Email Verified Successfully!'
      case 'expired':
        return 'Verification Link Expired'
      case 'error':
        return 'Verification Failed'
      default:
        return 'Email Verification'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Link */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-6"
        >
          <Link
            href="/login"
            className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
          >
            <FaArrowLeft className="mr-2" />
            Back to Login
          </Link>
        </motion.div>

        {/* Verification Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="backdrop-blur-md bg-white/10 rounded-2xl p-8 shadow-2xl border border-white/20 text-center"
        >
          {/* Status Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="flex justify-center mb-6"
          >
            {getStatusIcon()}
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className={`text-2xl font-bold mb-4 ${getStatusColor()}`}
          >
            {getStatusTitle()}
          </motion.h1>

          {/* Message */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-gray-300 mb-6 leading-relaxed"
          >
            {message || 'Please wait while we verify your email address...'}
          </motion.p>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="space-y-4"
          >
            {verificationStatus === 'success' && (
              <div className="space-y-4">
                <Button
                  onClick={() => router.push('/login')}
                  variant="gradient"
                  size="lg"
                  className="w-full"
                >
                  Continue to Login
                </Button>
                <p className="text-sm text-gray-400">
                  Redirecting automatically in a few seconds...
                </p>
              </div>
            )}

            {(verificationStatus === 'error' || verificationStatus === 'expired') && (
              <div className="space-y-4">
                <Button
                  onClick={resendVerification}
                  variant="gradient"
                  size="lg"
                  className="w-full"
                  disabled={isResending}
                  isLoading={isResending}
                >
                  {isResending ? 'Sending...' : 'Resend Verification Email'}
                </Button>
                
                <div className="text-center">
                  <Link
                    href="/signup"
                    className="text-blue-400 hover:text-blue-300 text-sm transition-colors"
                  >
                    Create a new account
                  </Link>
                </div>
              </div>
            )}

            {verificationStatus === 'verifying' && (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="animate-pulse text-blue-400">
                    This may take a few moments...
                  </div>
                </div>
                
                <Button
                  onClick={() => router.push('/login')}
                  variant="ghost"
                  size="lg"
                  className="w-full"
                >
                  Cancel and Go Back
                </Button>
              </div>
            )}
          </motion.div>

          {/* Help Text */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-8 pt-6 border-t border-white/10"
          >
            <p className="text-xs text-gray-400 mb-2">
              Didn't receive the email? Check your spam folder or try resending.
            </p>
            <p className="text-xs text-gray-500">
              Need help?{' '}
              <a
                href="mailto:support@localhost"
                className="text-blue-400 hover:text-blue-300 transition-colors"
              >
                Contact Support
              </a>
            </p>
          </motion.div>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-center mt-6 text-gray-400 text-sm"
        >
          <p>&copy; 2024 Auth System. All rights reserved.</p>
        </motion.div>
      </div>
    </div>
  )
}

export default function EmailVerificationPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <EmailVerificationContent />
    </Suspense>
  )
}
