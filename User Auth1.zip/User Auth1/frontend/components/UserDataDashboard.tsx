'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FiUsers, 
  FiSearch, 
  FiFilter, 
  FiDownload,
  FiEye,
  FiEdit,
  FiTrash2,
  FiCheck,
  FiX,
  FiMail,
  FiPhone,
  FiShield,
  FiCalendar,
  FiClock,
  FiChevronLeft,
  FiChevronRight,
  FiMoreHorizontal,
  FiRefreshCw,
  FiAlertTriangle,
  FiUser,
  FiActivity,
  FiSettings,
  FiLock
} from 'react-icons/fi';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import toast from 'react-hot-toast';

interface UserData {
  _id: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  role: 'user' | 'admin';
  isActive: boolean;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  provider: 'local' | 'google' | 'facebook';
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  loginAttempts: number;
  twoFactorEnabled: boolean;
  profilePicture?: string;
  bio?: string;
  preferences: {
    theme: string;
    language: string;
    notifications: {
      email: boolean;
      sms: boolean;
      push: boolean;
    };
  };
}

interface PaginationInfo {
  currentPage: number;
  totalPages: number;
  totalUsers: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
  limit: number;
}

interface DetailedUserProfile {
  user: UserData;
  activitySummary: Array<{
    _id: string;
    count: number;
    lastOccurrence: string;
  }>;
  loginHistory: Array<{
    action: string;
    createdAt: string;
    ipAddress?: string;
    userAgent?: string;
  }>;
  securityEvents: Array<{
    action: string;
    createdAt: string;
    details?: any;
  }>;
  stats: {
    totalActivities: number;
    loginCount: number;
    failedLoginCount: number;
  };
}

const UserDataDashboard = () => {
  const [users, setUsers] = useState<UserData[]>([]);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [viewingUser, setViewingUser] = useState<DetailedUserProfile | null>(null);
  
  // Filters and search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [currentPage, setCurrentPage] = useState(1);
  
  // UI states
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [bulkActionType, setBulkActionType] = useState('');

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: '20',
        search: searchTerm,
        status: statusFilter,
        role: roleFilter,
        sortBy,
        sortOrder
      });

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          'Content-Type': 'application/json'
        }
      });

      const result = await response.json();
      
      if (result.success) {
        setUsers(result.data.users);
        setPagination(result.data.pagination);
      } else {
        toast.error('Failed to fetch users');
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to fetch users');
    } finally {
      setLoading(false);
    }
  }, [currentPage, searchTerm, statusFilter, roleFilter, sortBy, sortOrder]);

  const fetchDetailedUser = async (userId: string) => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users/${userId}/detailed`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        }
      });

      const result = await response.json();
      
      if (result.success) {
        setViewingUser(result.data);
      } else {
        toast.error('Failed to fetch user details');
      }
    } catch (error) {
      console.error('Error fetching user details:', error);
      toast.error('Failed to fetch user details');
    }
  };

  const handleBulkAction = async (action: string) => {
    if (selectedUsers.length === 0) {
      toast.error('Please select users first');
      return;
    }

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users/bulk-update`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userIds: selectedUsers,
          action,
          data: action === 'update-role' ? { role: bulkActionType } : {}
        })
      });

      const result = await response.json();
      
      if (result.success) {
        toast.success(result.message);
        setSelectedUsers([]);
        setShowBulkActions(false);
        fetchUsers();
      } else {
        toast.error(result.message || 'Bulk action failed');
      }
    } catch (error) {
      console.error('Bulk action error:', error);
      toast.error('Bulk action failed');
    }
  };

  const handleUserStatusChange = async (userId: string, isActive: boolean) => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/users/${userId}/status`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isActive, reason: 'Admin action from dashboard' })
      });

      const result = await response.json();
      
      if (result.success) {
        toast.success(result.message);
        fetchUsers();
      } else {
        toast.error(result.message || 'Failed to update user status');
      }
    } catch (error) {
      console.error('Error updating user status:', error);
      toast.error('Failed to update user status');
    }
  };

  const exportUsers = async (format: 'csv' | 'json' = 'csv') => {
    try {
      const params = new URLSearchParams({
        format,
        status: statusFilter,
        role: roleFilter
      });

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/export/users?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        }
      });

      if (format === 'csv') {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `users-export-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        const result = await response.json();
        const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `users-export-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }

      toast.success('Users exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export users');
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const getStatusColor = (isActive: boolean, isEmailVerified: boolean) => {
    if (!isActive) return 'text-red-400 bg-red-400/10';
    if (!isEmailVerified) return 'text-yellow-400 bg-yellow-400/10';
    return 'text-green-400 bg-green-400/10';
  };

  const getStatusText = (user: UserData) => {
    if (!user.isActive) return 'Inactive';
    if (!user.isEmailVerified) return 'Unverified';
    return 'Active';
  };

  if (viewingUser) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-6"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setViewingUser(null)}
              className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
            >
              <FiChevronLeft className="w-4 h-4" />
              <span>Back to Users</span>
            </button>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {viewingUser.user.firstName} {viewingUser.user.lastName}
              </h2>
              <p className="text-gray-400">{viewingUser.user.email}</p>
            </div>
          </div>
        </div>

        {/* User Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Basic Information */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Basic Information</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Full Name:</span>
                <span className="text-white">{viewingUser.user.firstName} {viewingUser.user.lastName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Email:</span>
                <span className="text-white">{viewingUser.user.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Phone:</span>
                <span className="text-white">{viewingUser.user.phoneNumber || 'Not provided'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Role:</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  viewingUser.user.role === 'admin' ? 'bg-red-400/20 text-red-300' : 'bg-blue-400/20 text-blue-300'
                }`}>
                  {viewingUser.user.role.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Provider:</span>
                <span className="text-white capitalize">{viewingUser.user.provider}</span>
              </div>
            </div>
          </div>

          {/* Account Status */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Account Status</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Account Status:</span>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(viewingUser.user.isActive, viewingUser.user.isEmailVerified)}`}>
                  {getStatusText(viewingUser.user)}
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Email Verified:</span>
                <div className="flex items-center space-x-1">
                  {viewingUser.user.isEmailVerified ? (
                    <FiCheck className="w-4 h-4 text-green-400" />
                  ) : (
                    <FiX className="w-4 h-4 text-red-400" />
                  )}
                  <span className={viewingUser.user.isEmailVerified ? 'text-green-400' : 'text-red-400'}>
                    {viewingUser.user.isEmailVerified ? 'Verified' : 'Not Verified'}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Phone Verified:</span>
                <div className="flex items-center space-x-1">
                  {viewingUser.user.isPhoneVerified ? (
                    <FiCheck className="w-4 h-4 text-green-400" />
                  ) : (
                    <FiX className="w-4 h-4 text-red-400" />
                  )}
                  <span className={viewingUser.user.isPhoneVerified ? 'text-green-400' : 'text-red-400'}>
                    {viewingUser.user.isPhoneVerified ? 'Verified' : 'Not Verified'}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">2FA Enabled:</span>
                <div className="flex items-center space-x-1">
                  {viewingUser.user.twoFactorEnabled ? (
                    <FiShield className="w-4 h-4 text-green-400" />
                  ) : (
                    <FiX className="w-4 h-4 text-gray-400" />
                  )}
                  <span className={viewingUser.user.twoFactorEnabled ? 'text-green-400' : 'text-gray-400'}>
                    {viewingUser.user.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Activity Statistics */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Activity Statistics</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-2xl font-bold text-white">{viewingUser.stats.totalActivities}</div>
                <div className="text-sm text-gray-400">Total Activities</div>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-2xl font-bold text-green-400">{viewingUser.stats.loginCount}</div>
                <div className="text-sm text-gray-400">Successful Logins</div>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-2xl font-bold text-red-400">{viewingUser.stats.failedLoginCount}</div>
                <div className="text-sm text-gray-400">Failed Logins</div>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-2xl font-bold text-white">{viewingUser.user.loginAttempts}</div>
                <div className="text-sm text-gray-400">Login Attempts</div>
              </div>
            </div>
          </div>

          {/* Recent Login History */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Recent Login History</h3>
            <div className="space-y-2">
              {viewingUser.loginHistory.slice(0, 5).map((login, index) => (
                <div key={index} className="flex items-center justify-between py-2 px-3 bg-white/5 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${
                      login.action === 'LOGIN_SUCCESS' ? 'bg-green-400' : 'bg-red-400'
                    }`} />
                    <span className="text-sm text-gray-300">
                      {login.action.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400">
                    {new Date(login.createdAt).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-4">
          <Button
            onClick={() => handleUserStatusChange(viewingUser.user._id, !viewingUser.user.isActive)}
            variant="ghost"
            className={viewingUser.user.isActive ? 'bg-red-600/20 text-red-300 hover:bg-red-600/30' : 'bg-green-600/20 text-green-300 hover:bg-green-600/30'}
          >
            {viewingUser.user.isActive ? 'Deactivate User' : 'Activate User'}
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">User Database</h2>
          <p className="text-gray-400">Comprehensive view of all registered users</p>
        </div>
        <div className="flex space-x-3">
          <Button onClick={() => exportUsers('csv')} variant="ghost">
            <FiDownload className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button onClick={() => exportUsers('json')} variant="ghost">
            <FiDownload className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
          <Button onClick={fetchUsers} variant="default">
            <FiRefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Search</label>
            <Input
              type="text"
              placeholder="Search by name, email, phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && fetchUsers()}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="verified">Email Verified</option>
              <option value="unverified">Email Unverified</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Role</label>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
            >
              <option value="all">All Roles</option>
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Sort By</label>
            <select
              value={`${sortBy}-${sortOrder}`}
              onChange={(e) => {
                const [field, order] = e.target.value.split('-');
                setSortBy(field);
                setSortOrder(order);
              }}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
            >
              <option value="createdAt-desc">Newest First</option>
              <option value="createdAt-asc">Oldest First</option>
              <option value="firstName-asc">Name A-Z</option>
              <option value="firstName-desc">Name Z-A</option>
              <option value="email-asc">Email A-Z</option>
              <option value="lastLogin-desc">Recent Login</option>
            </select>
          </div>
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedUsers.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-600/20 border border-blue-500/30 rounded-2xl p-4"
        >
          <div className="flex items-center justify-between">
            <span className="text-blue-300">
              {selectedUsers.length} user{selectedUsers.length > 1 ? 's' : ''} selected
            </span>
            <div className="flex space-x-2">
              <Button onClick={() => handleBulkAction('activate')} size="sm" variant="ghost">
                Activate
              </Button>
              <Button onClick={() => handleBulkAction('deactivate')} size="sm" variant="ghost">
                Deactivate
              </Button>
              <Button onClick={() => handleBulkAction('verify-email')} size="sm" variant="ghost">
                Verify Email
              </Button>
              <Button onClick={() => setSelectedUsers([])} size="sm" variant="ghost">
                Clear Selection
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Users Table */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <FiRefreshCw className="w-8 h-8 text-blue-400 animate-spin" />
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-white/5">
                  <tr>
                    <th className="px-6 py-4 text-left">
                      <input
                        type="checkbox"
                        checked={selectedUsers.length === users.length && users.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedUsers(users.map(user => user._id));
                          } else {
                            setSelectedUsers([]);
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">User</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Contact</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Role</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Provider</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Last Login</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {users.map((user) => (
                    <tr key={user._id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <input
                          type="checkbox"
                          checked={selectedUsers.includes(user._id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedUsers([...selectedUsers, user._id]);
                            } else {
                              setSelectedUsers(selectedUsers.filter(id => id !== user._id));
                            }
                          }}
                          className="rounded border-gray-300"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white font-medium">
                              {user.firstName.charAt(0)}{user.lastName.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <div className="font-medium text-white">
                              {user.firstName} {user.lastName}
                            </div>
                            <div className="text-sm text-gray-400">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <FiMail className={`w-4 h-4 ${user.isEmailVerified ? 'text-green-400' : 'text-gray-400'}`} />
                            <span className="text-sm text-gray-300">{user.email}</span>
                          </div>
                          {user.phoneNumber && (
                            <div className="flex items-center space-x-2">
                              <FiPhone className={`w-4 h-4 ${user.isPhoneVerified ? 'text-green-400' : 'text-gray-400'}`} />
                              <span className="text-sm text-gray-300">{user.phoneNumber}</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          user.role === 'admin' ? 'bg-red-400/20 text-red-300' : 'bg-blue-400/20 text-blue-300'
                        }`}>
                          {user.role.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(user.isActive, user.isEmailVerified)}`}>
                          {getStatusText(user)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-300 capitalize">{user.provider}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-300">
                          {user.lastLogin 
                            ? new Date(user.lastLogin).toLocaleDateString()
                            : 'Never'
                          }
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => fetchDetailedUser(user._id)}
                            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                            title="View Details"
                          >
                            <FiEye className="w-4 h-4 text-gray-400" />
                          </button>
                          <button
                            onClick={() => handleUserStatusChange(user._id, !user.isActive)}
                            className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${
                              user.isActive ? 'text-red-400' : 'text-green-400'
                            }`}
                            title={user.isActive ? 'Deactivate' : 'Activate'}
                          >
                            {user.isActive ? <FiLock className="w-4 h-4" /> : <FiCheck className="w-4 h-4" />}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {pagination && pagination.totalPages > 1 && (
              <div className="flex items-center justify-between px-6 py-4 bg-white/5">
                <div className="text-sm text-gray-400">
                  Showing {((pagination.currentPage - 1) * pagination.limit) + 1} to {Math.min(pagination.currentPage * pagination.limit, pagination.totalUsers)} of {pagination.totalUsers} users
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => setCurrentPage(pagination.currentPage - 1)}
                    disabled={!pagination.hasPrevPage}
                    size="sm"
                    variant="ghost"
                  >
                    <FiChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="px-3 py-1 text-sm text-white">
                    {pagination.currentPage} of {pagination.totalPages}
                  </span>
                  <Button
                    onClick={() => setCurrentPage(pagination.currentPage + 1)}
                    disabled={!pagination.hasNextPage}
                    size="sm"
                    variant="ghost"
                  >
                    <FiChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default UserDataDashboard;