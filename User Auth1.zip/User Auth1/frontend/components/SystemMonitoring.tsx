'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  FiActivity, 
  FiServer, 
  FiDatabase, 
  FiMail, 
  FiSmartphone,
  FiUsers,
  FiShield,
  FiCheck,
  FiX,
  FiRefreshCw,
  FiTrash2,
  FiBarChart,
  FiClock,
  FiAlertTriangle,
  FiTrendingUp
} from 'react-icons/fi';
import toast from 'react-hot-toast';

interface HealthStatus {
  status: string;
  timestamp: string;
  services: {
    database: {
      status: string;
      responseTime: number;
    };
    email: {
      status: string;
      provider: string;
    };
    sms: {
      status: string;
      provider: string;
    };
  };
  stats: {
    totalUsers: number;
    activeUsers: number;
    verifiedUsers: number;
    adminUsers: number;
  };
}

interface SystemMetrics {
  users: {
    total: number;
    active: number;
    verified: number;
    phoneVerified: number;
    admins: number;
    registrations: {
      last24h: number;
      last7d: number;
      last30d: number;
    };
    logins: {
      last24h: number;
      last7d: number;
      last30d: number;
    };
  };
  security: {
    failedAttempts: number;
    lockedAccounts: number;
    pendingVerifications: number;
  };
  otp: {
    activeOTPs: number;
    expiredOTPs: number;
  };
}

const SystemMonitoring = () => {
  const [healthStatus, setHealthStatus] = useState<HealthStatus | null>(null);
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchHealthStatus = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/system/health`);
      const result = await response.json();
      
      if (result.success) {
        setHealthStatus(result.data);
      }
    } catch (error) {
      console.error('Failed to fetch health status:', error);
      toast.error('Failed to fetch system health');
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/system/metrics`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        }
      });
      const result = await response.json();
      
      if (result.success) {
        setMetrics(result.data);
      }
    } catch (error) {
      console.error('Failed to fetch metrics:', error);
      toast.error('Failed to fetch system metrics');
    }
  };

  const performCleanup = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/system/cleanup`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        }
      });
      const result = await response.json();
      
      if (result.success) {
        toast.success(`Cleanup completed: ${result.data.expiredOTPs} OTPs, ${result.data.cleanedUsers} users cleaned`);
        await Promise.all([fetchHealthStatus(), fetchMetrics()]);
      } else {
        toast.error('Cleanup failed');
      }
    } catch (error) {
      console.error('Cleanup error:', error);
      toast.error('Cleanup failed');
    } finally {
      setLoading(false);
    }
  };

  const refreshData = async () => {
    setLoading(true);
    try {
      await Promise.all([fetchHealthStatus(), fetchMetrics()]);
      setLastUpdated(new Date());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ok':
      case 'connected':
      case 'configured':
        return 'text-green-400';
      case 'degraded':
      case 'not-configured':
        return 'text-yellow-400';
      case 'error':
      case 'disconnected':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ok':
      case 'connected':
      case 'configured':
        return <FiCheck className="w-5 h-5" />;
      case 'degraded':
      case 'not-configured':
        return <FiAlertTriangle className="w-5 h-5" />;
      case 'error':
      case 'disconnected':
        return <FiX className="w-5 h-5" />;
      default:
        return <FiActivity className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">System Monitoring</h2>
          <p className="text-gray-400">Real-time system health and performance metrics</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={performCleanup}
            disabled={loading}
            className="flex items-center space-x-2 px-4 py-2 bg-yellow-600/20 hover:bg-yellow-600/30 text-yellow-300 rounded-lg transition-colors disabled:opacity-50"
          >
            <FiTrash2 className="w-4 h-4" />
            <span>Cleanup</span>
          </button>
          <button
            onClick={refreshData}
            disabled={loading}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 rounded-lg transition-colors disabled:opacity-50"
          >
            <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Last Updated */}
      {lastUpdated && (
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <FiClock className="w-4 h-4" />
          <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
        </div>
      )}

      {/* System Health Status */}
      {healthStatus && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-white flex items-center space-x-2">
              <FiServer className="w-6 h-6" />
              <span>System Health</span>
            </h3>
            <div className={`flex items-center space-x-2 ${getStatusColor(healthStatus.status)}`}>
              {getStatusIcon(healthStatus.status)}
              <span className="font-medium capitalize">{healthStatus.status}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Database Status */}
            <div className="bg-white/5 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <FiDatabase className="w-5 h-5 text-blue-400" />
                  <span className="font-medium text-white">Database</span>
                </div>
                <div className={`flex items-center space-x-1 ${getStatusColor(healthStatus.services.database.status)}`}>
                  {getStatusIcon(healthStatus.services.database.status)}
                </div>
              </div>
              <p className="text-sm text-gray-400">
                Response: {healthStatus.services.database.responseTime}ms
              </p>
            </div>

            {/* Email Service */}
            <div className="bg-white/5 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <FiMail className="w-5 h-5 text-green-400" />
                  <span className="font-medium text-white">Email</span>
                </div>
                <div className={`flex items-center space-x-1 ${getStatusColor(healthStatus.services.email.status)}`}>
                  {getStatusIcon(healthStatus.services.email.status)}
                </div>
              </div>
              <p className="text-sm text-gray-400 capitalize">
                {healthStatus.services.email.provider}
              </p>
            </div>

            {/* SMS Service */}
            <div className="bg-white/5 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <FiSmartphone className="w-5 h-5 text-purple-400" />
                  <span className="font-medium text-white">SMS</span>
                </div>
                <div className={`flex items-center space-x-1 ${getStatusColor(healthStatus.services.sms.status)}`}>
                  {getStatusIcon(healthStatus.services.sms.status)}
                </div>
              </div>
              <p className="text-sm text-gray-400 capitalize">
                {healthStatus.services.sms.provider}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Quick Stats */}
      {healthStatus && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Users', value: healthStatus.stats.totalUsers, icon: FiUsers, color: 'blue' },
            { label: 'Active Users', value: healthStatus.stats.activeUsers, icon: FiCheck, color: 'green' },
            { label: 'Verified Users', value: healthStatus.stats.verifiedUsers, icon: FiShield, color: 'purple' },
            { label: 'Admins', value: healthStatus.stats.adminUsers, icon: FiShield, color: 'red' },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl p-4"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm font-medium">{stat.label}</p>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                  </div>
                  <div className={`w-10 h-10 bg-${stat.color}-500/20 rounded-lg flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 text-${stat.color}-400`} />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Detailed Metrics */}
      {metrics && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6"
        >
          <h3 className="text-xl font-semibold text-white flex items-center space-x-2 mb-6">
            <FiBarChart className="w-6 h-6" />
            <span>Detailed Analytics</span>
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Activity */}
            <div className="space-y-4">
              <h4 className="text-lg font-medium text-white">User Activity</h4>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">New Registrations (24h)</span>
                  <span className="text-white font-semibold">{metrics.users.registrations.last24h}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">New Registrations (7d)</span>
                  <span className="text-white font-semibold">{metrics.users.registrations.last7d}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">New Registrations (30d)</span>
                  <span className="text-white font-semibold">{metrics.users.registrations.last30d}</span>
                </div>
                
                <hr className="border-white/10 my-4" />
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Logins (24h)</span>
                  <span className="text-white font-semibold">{metrics.users.logins.last24h}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Logins (7d)</span>
                  <span className="text-white font-semibold">{metrics.users.logins.last7d}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Phone Verified</span>
                  <span className="text-white font-semibold">{metrics.users.phoneVerified}</span>
                </div>
              </div>
            </div>

            {/* Security Metrics */}
            <div className="space-y-4">
              <h4 className="text-lg font-medium text-white">Security Status</h4>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Failed Login Attempts</span>
                  <span className={`font-semibold ${metrics.security.failedAttempts > 0 ? 'text-yellow-400' : 'text-green-400'}`}>
                    {metrics.security.failedAttempts}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Locked Accounts</span>
                  <span className={`font-semibold ${metrics.security.lockedAccounts > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {metrics.security.lockedAccounts}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Pending Verifications</span>
                  <span className="text-white font-semibold">{metrics.security.pendingVerifications}</span>
                </div>
                
                <hr className="border-white/10 my-4" />
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Active OTPs</span>
                  <span className="text-white font-semibold">{metrics.otp.activeOTPs}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Expired OTPs</span>
                  <span className="text-gray-400 font-semibold">{metrics.otp.expiredOTPs}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default SystemMonitoring;