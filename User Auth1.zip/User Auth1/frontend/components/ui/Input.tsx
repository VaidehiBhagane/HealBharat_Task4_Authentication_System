'use client'

import React, { forwardRef, InputHTMLAttributes, useState } from 'react'
import { motion, HTMLMotionProps } from 'framer-motion'
import { FaEye, FaEyeSlash } from 'react-icons/fa'
import { cn } from '@/lib/utils'

export interface InputProps extends Omit<HTMLMotionProps<'input'>, 'onAnimationStart'> {
  label?: string
  error?: string
  icon?: React.ReactNode
  iconPosition?: 'left' | 'right'
  variant?: 'glass' | 'solid'
  helperText?: string
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({
    className,
    type,
    label,
    error,
    icon,
    iconPosition = 'left',
    variant = 'glass',
    helperText,
    id,
    ...props
  }, ref) => {
    const [showPassword, setShowPassword] = useState(false)
    const [isFocused, setIsFocused] = useState(false)

    const inputId = id || label?.toLowerCase().replace(/\s+/g, '-')
    const isPassword = type === 'password'
    const inputType = isPassword && showPassword ? 'text' : type

    const baseClasses = 'w-full rounded-xl transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-0'
    
    const variants = {
      glass: 'glass-input text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400',
      solid: 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white',
    }

    const sizeClasses = icon ? 'px-12 py-3' : 'px-4 py-3'

    return (
      <motion.div 
        className="relative w-full"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {label && (
          <motion.label
            htmlFor={inputId}
            className={cn(
              "block text-sm font-medium mb-2 transition-colors duration-300",
              error ? "text-red-500" : "text-gray-700 dark:text-gray-300",
              isFocused && "text-blue-500"
            )}
            animate={{
              scale: isFocused ? 1.02 : 1,
            }}
            transition={{ duration: 0.2 }}
          >
            {label}
          </motion.label>
        )}
        
        <div className="relative">
          {icon && iconPosition === 'left' && (
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400 z-10">
              {icon}
            </div>
          )}
          
          <motion.input
            ref={ref}
            id={inputId}
            type={inputType}
            className={cn(
              baseClasses,
              variants[variant],
              sizeClasses,
              icon && iconPosition === 'left' && 'pl-12',
              icon && iconPosition === 'right' && 'pr-12',
              isPassword && 'pr-12',
              error && 'border-red-500 focus:ring-red-400',
              className
            )}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            whileFocus={{
              scale: 1.01,
            }}
            transition={{ duration: 0.2 }}
            {...props}
          />
          
          {icon && iconPosition === 'right' && !isPassword && (
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400">
              {icon}
            </div>
          )}
          
          {isPassword && (
            <motion.button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {showPassword ? <FaEyeSlash className="w-5 h-5" /> : <FaEye className="w-5 h-5" />}
            </motion.button>
          )}
          
          {isFocused && (
            <motion.div
              className="absolute inset-0 rounded-xl border-2 border-blue-400 pointer-events-none"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 0.3, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
            />
          )}
        </div>
        
        {error && (
          <motion.p
            className="mt-2 text-sm text-red-500"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {error}
          </motion.p>
        )}
        
        {helperText && !error && (
          <motion.p
            className="mt-2 text-sm text-gray-600 dark:text-gray-400"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {helperText}
          </motion.p>
        )}
      </motion.div>
    )
  }
)

Input.displayName = 'Input'

export { Input }