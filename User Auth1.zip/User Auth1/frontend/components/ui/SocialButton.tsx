'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaGoogle, FaFacebook, FaGithub } from 'react-icons/fa'
import { Button } from './Button'

export interface SocialButtonProps {
  provider: 'google' | 'facebook' | 'github'
  onClick: () => void
  isLoading?: boolean
  className?: string
}

const socialConfig = {
  google: {
    icon: FaGoogle,
    label: 'Continue with Google',
    className: 'bg-white hover:bg-gray-50 text-gray-800 border border-gray-300 shadow-md hover:shadow-lg',
    iconClassName: 'text-red-500'
  },
  facebook: {
    icon: FaFacebook,
    label: 'Continue with Facebook',
    className: 'bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg',
    iconClassName: 'text-white'
  },
  github: {
    icon: FaGithub,
    label: 'Continue with GitHub',
    className: 'bg-gray-900 hover:bg-gray-800 text-white shadow-md hover:shadow-lg',
    iconClassName: 'text-white'
  }
}

export function SocialButton({ 
  provider, 
  onClick, 
  isLoading = false, 
  className 
}: SocialButtonProps) {
  const config = socialConfig[provider]
  const Icon = config.icon

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <Button
        variant="ghost"
        size="lg"
        onClick={onClick}
        isLoading={isLoading}
        disabled={isLoading}
        className={`w-full relative overflow-hidden ${config.className} ${className}`}
      >
        <div className="flex items-center justify-center space-x-3">
          <Icon className={`w-5 h-5 ${config.iconClassName}`} />
          <span className="font-medium">{config.label}</span>
        </div>
        
        {/* Hover Effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
          initial={{ x: '-100%' }}
          whileHover={{ x: '100%' }}
          transition={{ duration: 0.6 }}
        />
      </Button>
    </motion.div>
  )
}

// Compound component for multiple social buttons
export function SocialLoginGroup({ 
  onGoogleClick, 
  onFacebookClick,
  onGithubClick,
  isLoading 
}: {
  onGoogleClick?: () => void
  onFacebookClick?: () => void
  onGithubClick?: () => void
  isLoading?: boolean
}) {
  return (
    <div className="space-y-3">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300 dark:border-gray-600" />
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-4 bg-white/80 dark:bg-gray-900/80 text-gray-500 dark:text-gray-400 backdrop-blur-sm rounded-full">
            Or continue with
          </span>
        </div>
      </div>
      
      <div className="grid gap-3">
        {onGoogleClick && (
          <SocialButton
            provider="google"
            onClick={onGoogleClick}
            isLoading={isLoading}
          />
        )}
        
        {onFacebookClick && (
          <SocialButton
            provider="facebook"
            onClick={onFacebookClick}
            isLoading={isLoading}
          />
        )}
        
        {onGithubClick && (
          <SocialButton
            provider="github"
            onClick={onGithubClick}
            isLoading={isLoading}
          />
        )}
      </div>
    </div>
  )
}