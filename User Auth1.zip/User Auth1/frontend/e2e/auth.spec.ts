import { test, expect } from '@playwright/test'

test.describe('Authentication E2E Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Clear any existing session
    await page.context().clearCookies()
    await page.context().clearPermissions()
  })

  test.describe('Landing Page', () => {
    test('should load landing page correctly', async ({ page }) => {
      await page.goto('/')
      
      // Check main elements
      await expect(page.getByText('AuthSystem')).toBeVisible()
      await expect(page.getByText('Secure Authentication')).toBeVisible()
      await expect(page.getByText('Get Started')).toBeVisible()
      
      // Check responsive design
      await page.setViewportSize({ width: 375, height: 667 }) // Mobile
      await expect(page.getByText('AuthSystem')).toBeVisible()
      
      await page.setViewportSize({ width: 1920, height: 1080 }) // Desktop
      await expect(page.getByText('AuthSystem')).toBeVisible()
    })

    test('should navigate to login and signup pages', async ({ page }) => {
      await page.goto('/')
      
      // Test login navigation
      await page.getByRole('link', { name: 'Login' }).click()
      await expect(page).toHaveURL('/login')
      
      await page.goBack()
      
      // Test signup navigation
      await page.getByRole('link', { name: 'Sign Up' }).click()
      await expect(page).toHaveURL('/signup')
    })
  })

  test.describe('Login Flow', () => {
    test('should display login form with glassmorphic design', async ({ page }) => {
      await page.goto('/login')
      
      // Check glassmorphic elements
      await expect(page.getByText('Welcome Back')).toBeVisible()
      await expect(page.getByText('Sign in to access your account')).toBeVisible()
      
      // Check form elements
      await expect(page.getByLabel('Email Address')).toBeVisible()
      await expect(page.getByLabel('Password')).toBeVisible()
      await expect(page.getByText('Remember me')).toBeVisible()
      await expect(page.getByText('Forgot Password?')).toBeVisible()
      await expect(page.getByRole('button', { name: 'Sign In' })).toBeVisible()
      
      // Check social login buttons
      await expect(page.getByText('Continue with Google')).toBeVisible()
      await expect(page.getByText('Continue with Facebook')).toBeVisible()
    })

    test('should validate form inputs', async ({ page }) => {
      await page.goto('/login')
      
      // Try to submit empty form
      await page.getByRole('button', { name: 'Sign In' }).click()
      
      // Should show validation errors
      await expect(page.getByText('Email is required')).toBeVisible()
      await expect(page.getByText('Password is required')).toBeVisible()
      
      // Test invalid email
      await page.getByLabel('Email Address').fill('invalid-email')
      await page.getByRole('button', { name: 'Sign In' }).click()
      await expect(page.getByText('Invalid email format')).toBeVisible()
      
      // Test short password
      await page.getByLabel('Email Address').fill('test@example.com')
      await page.getByLabel('Password').fill('123')
      await page.getByRole('button', { name: 'Sign In' }).click()
      await expect(page.getByText('Password must be at least 8 characters')).toBeVisible()
    })

    test('should handle login with invalid credentials', async ({ page }) => {
      await page.goto('/login')
      
      // Fill invalid credentials
      await page.getByLabel('Email Address').fill('nonexistent@example.com')
      await page.getByLabel('Password').fill('WrongPassword123!')
      await page.getByRole('button', { name: 'Sign In' }).click()
      
      // Should show error message
      await expect(page.getByText(/Invalid credentials|Login failed/)).toBeVisible({ timeout: 10000 })
    })

    test('should show password visibility toggle', async ({ page }) => {
      await page.goto('/login')
      
      const passwordInput = page.getByLabel('Password')
      const toggleButton = page.locator('[data-testid="password-toggle"]').or(
        page.locator('button').filter({ hasText: /👁️|eye/i })
      ).first()
      
      // Password should be hidden initially
      await expect(passwordInput).toHaveAttribute('type', 'password')
      
      // Click toggle to show password
      await passwordInput.fill('TestPassword123!')
      if (await toggleButton.isVisible()) {
        await toggleButton.click()
        await expect(passwordInput).toHaveAttribute('type', 'text')
        
        // Click again to hide
        await toggleButton.click()
        await expect(passwordInput).toHaveAttribute('type', 'password')
      }
    })

    test('should navigate to signup and forgot password', async ({ page }) => {
      await page.goto('/login')
      
      // Test forgot password link
      await page.getByText('Forgot Password?').click()
      await expect(page).toHaveURL('/forgot-password')
      
      await page.goBack()
      
      // Test signup link
      await page.getByText('Sign up here').click()
      await expect(page).toHaveURL('/signup')
    })
  })

  test.describe('Signup Flow', () => {
    test('should display signup form', async ({ page }) => {
      await page.goto('/signup')
      
      // Check form elements
      await expect(page.getByLabel('First Name')).toBeVisible()
      await expect(page.getByLabel('Last Name')).toBeVisible()
      await expect(page.getByLabel('Email Address')).toBeVisible()
      await expect(page.getByLabel('Password')).toBeVisible()
      await expect(page.getByLabel('Confirm Password')).toBeVisible()
      await expect(page.getByRole('button', { name: /Sign Up|Create Account/ })).toBeVisible()
    })

    test('should validate signup form', async ({ page }) => {
      await page.goto('/signup')
      
      // Try to submit empty form
      await page.getByRole('button', { name: /Sign Up|Create Account/ }).click()
      
      // Should show validation errors
      await expect(page.getByText('First name is required')).toBeVisible()
      
      // Test password requirements
      await page.getByLabel('First Name').fill('John')
      await page.getByLabel('Last Name').fill('Doe')
      await page.getByLabel('Email Address').fill('john.doe@example.com')
      await page.getByLabel('Password').fill('weak')
      await page.getByRole('button', { name: /Sign Up|Create Account/ }).click()
      
      await expect(page.getByText(/Password must contain/)).toBeVisible()
    })
  })

  test.describe('Social Login', () => {
    test('should initiate Google OAuth flow', async ({ page, context }) => {
      await page.goto('/login')
      
      // Mock the Google OAuth redirect
      const googleButton = page.getByText('Continue with Google')
      await expect(googleButton).toBeVisible()
      
      // Click should attempt to navigate to OAuth URL
      const [popup] = await Promise.all([
        context.waitForEvent('page'),
        googleButton.click()
      ])
      
      // Check if popup was opened or redirect occurred
      expect(popup || page.url().includes('google') || page.url().includes('auth')).toBeTruthy()
    })

    test('should initiate Facebook OAuth flow', async ({ page, context }) => {
      await page.goto('/login')
      
      const facebookButton = page.getByText('Continue with Facebook')
      await expect(facebookButton).toBeVisible()
      
      // Click should attempt to navigate to OAuth URL
      const [popup] = await Promise.all([
        context.waitForEvent('page'),
        facebookButton.click()
      ])
      
      expect(popup || page.url().includes('facebook') || page.url().includes('auth')).toBeTruthy()
    })
  })

  test.describe('Responsive Design', () => {
    const viewports = [
      { name: 'Mobile', width: 375, height: 667 },
      { name: 'Tablet', width: 768, height: 1024 },
      { name: 'Desktop', width: 1920, height: 1080 }
    ]

    viewports.forEach(viewport => {
      test(`should render correctly on ${viewport.name}`, async ({ page }) => {
        await page.setViewportSize({ width: viewport.width, height: viewport.height })
        await page.goto('/login')
        
        // Check that main elements are visible
        await expect(page.getByText('Welcome Back')).toBeVisible()
        await expect(page.getByLabel('Email Address')).toBeVisible()
        await expect(page.getByLabel('Password')).toBeVisible()
        await expect(page.getByRole('button', { name: 'Sign In' })).toBeVisible()
        
        // Check that social login buttons are accessible
        await expect(page.getByText('Continue with Google')).toBeVisible()
        
        // Test form interaction
        await page.getByLabel('Email Address').fill('test@example.com')
        await page.getByLabel('Password').fill('TestPassword123!')
        
        // Form should be functional
        await page.getByRole('button', { name: 'Sign In' }).click()
        // Should either show loading or error (since no real backend)
      })
    })
  })

  test.describe('Dark/Light Mode', () => {
    test('should toggle theme correctly', async ({ page }) => {
      await page.goto('/')
      
      // Find theme toggle button
      const themeToggle = page.locator('[aria-label="Toggle theme"]').or(
        page.locator('button').filter({ hasText: /🌙|☀️|moon|sun/i })
      ).first()
      
      if (await themeToggle.isVisible()) {
        // Check initial state
        const body = page.locator('body')
        const initialClass = await body.getAttribute('class')
        
        // Toggle theme
        await themeToggle.click()
        
        // Wait for theme change
        await page.waitForTimeout(500)
        
        const newClass = await body.getAttribute('class')
        expect(newClass).not.toBe(initialClass)
        
        // Toggle back
        await themeToggle.click()
        await page.waitForTimeout(500)
        
        const finalClass = await body.getAttribute('class')
        expect(finalClass).toBe(initialClass)
      }
    })
  })

  test.describe('Accessibility', () => {
    test('should have proper ARIA labels and keyboard navigation', async ({ page }) => {
      await page.goto('/login')
      
      // Check ARIA labels
      await expect(page.getByLabel('Email Address')).toBeVisible()
      await expect(page.getByLabel('Password')).toBeVisible()
      
      // Test keyboard navigation
      await page.keyboard.press('Tab')
      await page.keyboard.press('Tab')
      
      // Email field should be focused (after theme toggle and back button)
      const emailInput = page.getByLabel('Email Address')
      await expect(emailInput).toBeFocused()
      
      // Continue tabbing through form
      await page.keyboard.press('Tab')
      const passwordInput = page.getByLabel('Password')
      await expect(passwordInput).toBeFocused()
      
      // Test form submission with Enter key
      await emailInput.fill('test@example.com')
      await passwordInput.fill('TestPassword123!')
      await page.keyboard.press('Enter')
      
      // Should attempt to submit form
    })

    test('should have sufficient color contrast', async ({ page }) => {
      await page.goto('/login')
      
      // This would typically use axe-core for automated accessibility testing
      // For now, we'll check that text is visible
      await expect(page.getByText('Welcome Back')).toBeVisible()
      await expect(page.getByText('Sign in to access your account')).toBeVisible()
    })
  })

  test.describe('Performance', () => {
    test('should load pages within acceptable time', async ({ page }) => {
      const startTime = Date.now()
      await page.goto('/')
      const landingTime = Date.now() - startTime
      
      expect(landingTime).toBeLessThan(3000) // 3 seconds max
      
      const loginStartTime = Date.now()
      await page.goto('/login')
      const loginTime = Date.now() - loginStartTime
      
      expect(loginTime).toBeLessThan(3000) // 3 seconds max
    })

    test('should handle animations smoothly', async ({ page }) => {
      await page.goto('/login')
      
      // Check for smooth animations by monitoring frame rate
      // This is a basic test - in practice, you'd use more sophisticated performance monitoring
      await page.waitForTimeout(1000)
      
      const emailInput = page.getByLabel('Email Address')
      await emailInput.focus()
      await emailInput.fill('test@example.com')
      
      // Animation should complete without blocking
      await expect(emailInput).toHaveValue('test@example.com')
    })
  })
})