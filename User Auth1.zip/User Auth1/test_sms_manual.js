// Manual SMS Testing Script for Twilio
// This script helps you test SMS functionality manually

const axios = require('axios');

// Configuration
const BASE_URL = 'http://localhost:5000';
const TEST_PHONE = '+1234567890'; // Replace with your actual phone number for testing

console.log('📱 SMS Manual Testing Script');
console.log('============================\n');

async function testSMSEndpoints() {
    console.log('Available SMS Test Options:\n');
    
    console.log('1. Test Login OTP SMS');
    console.log('   Message: "Hi [Name]! Your Auth System login code is: 123456. This code expires in 10 minutes. Never share this code with anyone."\n');
    
    console.log('2. Test Registration OTP SMS');
    console.log('   Message: "Welcome [Name]! Your Auth System verification code is: 123456. Enter this code to complete your registration. Expires in 10 minutes."\n');
    
    console.log('3. Test Security Alert SMS');
    console.log('   Message: "Security Alert: [Name], a password change was performed on your Auth System account. If this wasn\'t you, please contact support immediately."\n');
    
    console.log('To test manually, follow these steps:');
    console.log('=====================================\n');
    
    console.log('STEP 1: Update your phone number in this script');
    console.log(`   - Current test phone: ${TEST_PHONE}`);
    console.log('   - Replace with your actual phone number (with country code)\n');
    
    console.log('STEP 2: Test SMS Service Status');
    console.log('   Run: testSMSServiceStatus()\n');
    
    console.log('STEP 3: Test individual SMS types');
    console.log('   Run: testLoginOTP()');
    console.log('   Run: testRegistrationOTP()');
    console.log('   Run: testSecurityAlert()\n');
    
    console.log('STEP 4: Check your phone for received messages');
    console.log('   - Check SMS delivery');
    console.log('   - Verify message content');
    console.log('   - Note delivery time\n');
}

// Test functions for manual execution
async function testSMSServiceStatus() {
    try {
        console.log('🔍 Checking SMS Service Status...');
        const response = await axios.get(`${BASE_URL}/api/system/health`);
        console.log('✅ Server Status:', response.data);
        
        // Check if SMS is configured
        if (response.data.services && response.data.services.sms) {
            console.log('📱 SMS Service:', response.data.services.sms);
        }
        
    } catch (error) {
        console.error('❌ Failed to check service status:', error.message);
        if (error.response) {
            console.error('   Status:', error.response.status);
            console.error('   Data:', error.response.data);
        }
    }
}

async function testLoginOTP() {
    try {
        console.log('🧪 Testing Login OTP SMS...');
        
        // Create test payload
        const testData = {
            phoneNumber: TEST_PHONE,
            firstName: 'TestUser',
            otp: '123456'
        };
        
        console.log(`📱 Sending Login OTP to: ${TEST_PHONE}`);
        console.log('💬 Message will be: "Hi TestUser! Your Auth System login code is: 123456. This code expires in 10 minutes. Never share this code with anyone."');
        
        // You'll need to create this endpoint or call the SMS service directly
        const response = await axios.post(`${BASE_URL}/api/test/sms/login-otp`, testData);
        console.log('✅ SMS sent successfully:', response.data);
        
    } catch (error) {
        console.error('❌ Failed to send Login OTP SMS:', error.message);
        if (error.response) {
            console.error('   Status:', error.response.status);
            console.error('   Data:', error.response.data);
        }
    }
}

async function testRegistrationOTP() {
    try {
        console.log('🧪 Testing Registration OTP SMS...');
        
        const testData = {
            phoneNumber: TEST_PHONE,
            firstName: 'TestUser',
            otp: '123456'
        };
        
        console.log(`📱 Sending Registration OTP to: ${TEST_PHONE}`);
        console.log('💬 Message will be: "Welcome TestUser! Your Auth System verification code is: 123456. Enter this code to complete your registration. Expires in 10 minutes."');
        
        const response = await axios.post(`${BASE_URL}/api/test/sms/registration-otp`, testData);
        console.log('✅ SMS sent successfully:', response.data);
        
    } catch (error) {
        console.error('❌ Failed to send Registration OTP SMS:', error.message);
        if (error.response) {
            console.error('   Status:', error.response.status);
            console.error('   Data:', error.response.data);
        }
    }
}

async function testSecurityAlert() {
    try {
        console.log('🧪 Testing Security Alert SMS...');
        
        const testData = {
            phoneNumber: TEST_PHONE,
            firstName: 'TestUser',
            action: 'password change'
        };
        
        console.log(`📱 Sending Security Alert to: ${TEST_PHONE}`);
        console.log('💬 Message will be: "Security Alert: TestUser, a password change was performed on your Auth System account. If this wasn\'t you, please contact support immediately."');
        
        const response = await axios.post(`${BASE_URL}/api/test/sms/security-alert`, testData);
        console.log('✅ SMS sent successfully:', response.data);
        
    } catch (error) {
        console.error('❌ Failed to send Security Alert SMS:', error.message);
        if (error.response) {
            console.error('   Status:', error.response.status);
            console.error('   Data:', error.response.data);
        }
    }
}

// Export functions for manual testing
module.exports = {
    testSMSServiceStatus,
    testLoginOTP,
    testRegistrationOTP,
    testSecurityAlert
};

// If running directly, show instructions
if (require.main === module) {
    testSMSEndpoints();
}