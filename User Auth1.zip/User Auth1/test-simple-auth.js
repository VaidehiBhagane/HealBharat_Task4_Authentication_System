#!/usr/bin/env node

/**
 * Simple Authentication System Test using built-in fetch
 */

const BASE_URL = 'http://localhost:5000';

// Test data
const testUser = {
  firstName: 'Test',
  lastName: 'User',
  email: 'testuser@example.com',
  password: 'TestPassword123!',
  phoneNumber: '+1234567890',
  bio: 'I am a test user for the authentication system.'
};

let userToken = '';
let userId = '';

console.log('🚀 Testing Authentication System\n');

async function testRegistration() {
  console.log('🧪 Testing User Registration...');
  
  try {
    const response = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testUser)
    });
    
    const result = await response.json();
    
    if (result.success) {
      userId = result.data.user._id;
      console.log('✅ User Registration - PASSED');
      console.log(`   User ID: ${userId}`);
    } else {
      console.log('❌ User Registration - FAILED:', result.message);
    }
  } catch (error) {
    console.log('❌ User Registration - ERROR:', error.message);
  }
  console.log('');
}

async function testLogin() {
  console.log('🧪 Testing User Login...');
  
  try {
    const response = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testUser.email,
        password: testUser.password
      })
    });
    
    const result = await response.json();
    
    if (result.success) {
      userToken = result.data.tokens.accessToken;
      console.log('✅ User Login - PASSED');
      console.log('   Access token received');
    } else {
      console.log('❌ User Login - FAILED:', result.message);
    }
  } catch (error) {
    console.log('❌ User Login - ERROR:', error.message);
  }
  console.log('');
}

async function testProfileRetrieval() {
  console.log('🧪 Testing Profile Retrieval...');
  
  try {
    const response = await fetch(`${BASE_URL}/api/auth/profile`, {
      headers: { Authorization: `Bearer ${userToken}` }
    });
    
    const result = await response.json();
    
    if (result.success) {
      const user = result.data.user;
      console.log('✅ Profile Retrieval - PASSED');
      console.log(`   Name: ${user.firstName} ${user.lastName}`);
      console.log(`   Email: ${user.email}`);
    } else {
      console.log('❌ Profile Retrieval - FAILED:', result.message);
    }
  } catch (error) {
    console.log('❌ Profile Retrieval - ERROR:', error.message);
  }
  console.log('');
}

async function testProfileUpdate() {
  console.log('🧪 Testing Profile Update...');
  
  try {
    const updateData = {
      firstName: 'Updated',
      lastName: 'TestUser',
      phoneNumber: '+1555123456',
      bio: 'Updated bio for testing profile updates.'
    };

    const response = await fetch(`${BASE_URL}/api/auth/profile`, {
      method: 'PATCH',
      headers: { 
        Authorization: `Bearer ${userToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updateData)
    });
    
    const result = await response.json();
    
    if (result.success) {
      const user = result.data.user;
      console.log('✅ Profile Update - PASSED');
      console.log(`   Updated Name: ${user.firstName} ${user.lastName}`);
      console.log(`   Updated Phone: ${user.phoneNumber}`);
    } else {
      console.log('❌ Profile Update - FAILED:', result.message);
    }
  } catch (error) {
    console.log('❌ Profile Update - ERROR:', error.message);
  }
  console.log('');
}

async function runTests() {
  await testRegistration();
  await testLogin();
  if (userToken) {
    await testProfileRetrieval();
    await testProfileUpdate();
  }
  
  console.log('🎯 Test Complete!');
  console.log('');
  console.log('🔗 ACCESS LINKS:');
  console.log('   Frontend: http://localhost:3001');
  console.log('   Login: http://localhost:3001/login');
  console.log('   Signup: http://localhost:3001/signup');
  console.log('   Dashboard: http://localhost:3001/dashboard (after login)');
  console.log('   Admin Panel: http://localhost:3001/admin (admin users only)');
  console.log('');
  console.log('✨ Your authentication system is ready!');
}

runTests().catch(error => {
  console.error('Test failed:', error);
});