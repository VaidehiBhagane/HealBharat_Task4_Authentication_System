# 🚀 Production-Ready Authentication System

A modern, full-stack authentication system with glassmorphic UI, built with Next.js, Express, MongoDB, and advanced security features.

![Auth System Demo](https://via.placeholder.com/800x400/1e293b/38bdf8?text=Glassmorphic+Auth+System)

## ✨ Features

### 🎨 Modern UI/UX
- **Glassmorphic Design**: Futuristic 3D glass effects with glowing accents
- **Responsive**: Mobile-first design that works on all devices
- **Dark/Light Mode**: Seamless theme switching with system preference detection
- **Smooth Animations**: Framer Motion powered interactions
- **Accessibility**: WCAG 2.1 AA compliant

### 🔐 Authentication & Security
- **Multiple Login Methods**: Email/Password, Google OAuth, Facebook OAuth
- **OTP Verification**: Email (Nodemailer) and SMS (Twilio/MSG91)
- **JWT Security**: Access & Refresh tokens with proper rotation
- **Password Security**: bcrypt hashing with salt rounds
- **Rate Limiting**: Brute force protection
- **Session Management**: Secure session handling with MongoDB
- **2FA Support**: Time-based OTP (TOTP) authentication

### 📱 User Management
- **Profile Management**: Update name, phone, bio, profile picture
- **Image Upload**: Cloudinary/S3 integration for profile pictures
- **Password Recovery**: Email reset links and OTP options
- **Account Locking**: Automatic lockout after failed attempts
- **Email Verification**: Secure email confirmation flow

### 🛡️ Security Features
- **Helmet.js**: Security headers protection
- **CORS**: Cross-origin resource sharing configuration
- **Input Validation**: Comprehensive form validation with Zod
- **SQL Injection Protection**: MongoDB with proper sanitization
- **XSS Protection**: Content Security Policy implementation

### 👑 Admin Panel
- **Comprehensive Dashboard**: Real-time system statistics and user analytics
- **Advanced User Management**: View, search, filter, and manage all users
- **Security Controls**: Activate/deactivate accounts, reset passwords
- **Activity Monitoring**: Complete audit logs and user activity tracking
- **Data Export**: CSV/JSON export for compliance and backup
- **Role-Based Access**: Strict admin authentication with CSRF protection
- **Rate Limiting**: Tiered rate limits for different admin operations

## 🏗️ Architecture

```
auth-system/
├── frontend/          # Next.js React application
├── backend/           # Express.js API server
├── docker-compose.yml # Production Docker setup
├── .env.example      # Environment variables template
└── README.md         # This file
```

### Frontend Stack
- **Next.js 14** with App Router
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Framer Motion** for animations
- **React Hook Form** with Zod validation
- **Axios** for API calls

### Backend Stack
- **Node.js** with Express.js
- **TypeScript** for type safety
- **MongoDB** with Mongoose ODM
- **Passport.js** for authentication strategies
- **JWT** for token management
- **Nodemailer** for email services
- **Twilio** for SMS services

## 🚦 Getting Started

### Prerequisites

- Node.js 18+ and npm
- MongoDB 4.4+
- Redis (optional, for sessions)
- Docker & Docker Compose (recommended)

### 🐳 Quick Start with Docker

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/auth-system.git
   cd auth-system
   ```

2. **Set up environment variables**
   ```bash
   # Backend
   cp backend/.env.example backend/.env
   
   # Frontend  
   cp frontend/.env.example frontend/.env.local
   ```

3. **Configure your environment variables** (see [Environment Setup](#environment-setup))

4. **Start with Docker Compose**
   ```bash
   # Development
   docker-compose -f docker-compose.dev.yml up -d
   
   # Production
   docker-compose up -d
   ```

5. **Access the applications**
   - Frontend: http://localhost:3000
   - Admin Panel: http://localhost:3000/admin
   - Backend API: http://localhost:5000
   - MongoDB: localhost:27017

### 🔧 Manual Setup

#### Backend Setup

1. **Navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start MongoDB** (if not using Docker)
   ```bash
   # Using MongoDB locally
   mongod
   
   # Or using MongoDB Atlas (cloud)
   # Update MONGODB_URI in .env
   ```

5. **Run the development server**
   ```bash
   npm run dev
   ```

#### Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your configuration
   ```

4. **Run the development server**
   ```bash
   npm run dev
   ```

### 👑 Admin Panel Setup

1. **Create an Admin User**
   
   After setting up the application, create your first admin user:
   
   ```bash
   # Method 1: Register normally, then update role in MongoDB
   # 1. Register at http://localhost:3000/register
   # 2. Update the user role in MongoDB:
   
   # Connect to MongoDB
   mongosh auth-system
   
   # Update user role to admin
   db.users.updateOne(
     { email: "your-admin@example.com" },
     { $set: { role: "admin" } }
   )
   ```

2. **Access the Admin Panel**
   - Navigate to: http://localhost:3000/admin
   - Login with your admin credentials
   - The system will verify admin role and grant access

3. **Admin Panel Features**
   - **Dashboard**: View system statistics and recent activity
   - **User Management**: List, search, filter, and manage users
   - **User Details**: View individual user profiles and activity
   - **Account Controls**: Activate/deactivate accounts, reset passwords
   - **Audit Logs**: Monitor all administrative actions
   - **Data Export**: Export user data in CSV or JSON format

   For detailed documentation, see [ADMIN_PANEL_DOCS.md](./ADMIN_PANEL_DOCS.md)

## ⚙️ Environment Setup

### Required Environment Variables

#### Backend (.env)

```env
# Database
MONGODB_URI=mongodb://localhost:27017/authsystem

# JWT Secrets (Generate strong secrets!)
JWT_ACCESS_SECRET=your-super-secret-access-key
JWT_REFRESH_SECRET=your-super-secret-refresh-key

# OAuth Configuration
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
FACEBOOK_APP_ID=your-facebook-app-id
FACEBOOK_APP_SECRET=your-facebook-app-secret

# Email Configuration
GMAIL_USER=your-email@gmail.com
GMAIL_PASSWORD=your-app-password

# SMS Configuration (choose one)
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=+1234567890

# Image Upload (choose one)
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

#### Frontend (.env.local)

```env
NEXT_PUBLIC_API_URL=http://localhost:5000
NEXT_PUBLIC_GOOGLE_CLIENT_ID=your-google-client-id
NEXT_PUBLIC_FACEBOOK_APP_ID=your-facebook-app-id
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=your-cloud-name
```

### 🔑 OAuth Setup

#### Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URIs:
   - `http://localhost:5000/api/auth/google/callback` (development)
   - `https://yourdomain.com/api/auth/google/callback` (production)

#### Facebook OAuth Setup

1. Go to [Facebook Developers](https://developers.facebook.com/)
2. Create a new app
3. Add Facebook Login product
4. Configure OAuth redirect URIs:
   - `http://localhost:5000/api/auth/facebook/callback`

### 📧 Email Configuration

#### Gmail Setup

1. Enable 2-Factor Authentication on your Gmail account
2. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
3. Use the generated password in `GMAIL_PASSWORD`

#### SendGrid Alternative

```env
SENDGRID_API_KEY=your-sendgrid-api-key
```

### 📱 SMS Configuration

#### Twilio Setup

1. Create account at [Twilio](https://www.twilio.com/)
2. Get Account SID and Auth Token from dashboard
3. Purchase a phone number

#### MSG91 Alternative

```env
MSG91_AUTH_KEY=your-msg91-key
MSG91_SENDER_ID=your-sender-id
```

### ☁️ Image Upload Setup

#### Cloudinary Setup

1. Create account at [Cloudinary](https://cloudinary.com/)
2. Get Cloud Name, API Key, and API Secret from dashboard
3. Create upload preset (unsigned for frontend uploads)

#### AWS S3 Alternative

```env
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_S3_BUCKET_NAME=your-bucket-name
AWS_REGION=us-east-1
```

## 📚 API Documentation

### Authentication Endpoints

#### POST `/api/auth/register`
Register a new user account.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe", 
  "email": "john@example.com",
  "password": "SecurePass123!"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Registration successful",
  "data": {
    "user": { "id": "...", "email": "john@example.com" },
    "tokens": {
      "accessToken": "jwt-token",
      "refreshToken": "refresh-token"
    }
  }
}
```

#### POST `/api/auth/login`
Authenticate user with email and password.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "SecurePass123!",
  "rememberMe": true
}
```

#### POST `/api/auth/logout`
Logout user and invalidate tokens.

#### POST `/api/auth/refresh`
Refresh access token using refresh token.

#### GET `/api/auth/google`
Initiate Google OAuth flow.

#### GET `/api/auth/facebook`
Initiate Facebook OAuth flow.

### User Profile Endpoints

#### GET `/api/user/profile`
Get current user profile.

#### PUT `/api/user/profile`
Update user profile information.

#### POST `/api/user/upload-avatar`
Upload user profile picture.

### OTP Endpoints

#### POST `/api/auth/send-otp`
Send OTP via email or SMS.

#### POST `/api/auth/verify-otp`
Verify OTP code.

## 🧪 Testing

### Backend Tests

```bash
cd backend
npm test                 # Run all tests
npm run test:watch      # Watch mode
npm run test:coverage   # Coverage report
```

### Frontend Tests

```bash
cd frontend
npm test                 # Run all tests
npm run test:e2e        # End-to-end tests
```

## 🚀 Deployment

### Production Build

1. **Build applications**
   ```bash
   # Backend
   cd backend && npm run build
   
   # Frontend
   cd frontend && npm run build
   ```

2. **Set production environment variables**
   ```bash
   # Update NODE_ENV to production
   NODE_ENV=production
   
   # Use strong, unique secrets
   JWT_ACCESS_SECRET=$(openssl rand -base64 64)
   JWT_REFRESH_SECRET=$(openssl rand -base64 64)
   ```

### Docker Production Deployment

```bash
# Build and run production containers
docker-compose up -d

# Check container status
docker-compose ps

# View logs
docker-compose logs -f
```

### Security Checklist for Production

- [ ] Change all default passwords and secrets
- [ ] Enable HTTPS with valid SSL certificates  
- [ ] Set up proper firewall rules
- [ ] Enable MongoDB authentication
- [ ] Configure rate limiting appropriately
- [ ] Set secure cookie options
- [ ] Enable CORS for specific domains only
- [ ] Set up monitoring and logging
- [ ] Regular security updates

## 🔧 Configuration

### Feature Flags

Enable/disable features via environment variables:

```env
# Backend
ENABLE_2FA=true
ENABLE_EMAIL_VERIFICATION=true
ENABLE_SMS_VERIFICATION=true
ENABLE_SOCIAL_LOGIN=true

# Frontend
NEXT_PUBLIC_ENABLE_SOCIAL_LOGIN=true
NEXT_PUBLIC_ENABLE_2FA=true
NEXT_PUBLIC_ENABLE_DARK_MODE=true
```

### Rate Limiting Configuration

```env
RATE_LIMIT_WINDOW_MS=900000     # 15 minutes
RATE_LIMIT_MAX_REQUESTS=100     # 100 requests per window
AUTH_RATE_LIMIT_MAX=5           # 5 auth attempts per window
```

### Security Configuration

```env
BCRYPT_SALT_ROUNDS=12           # Password hashing rounds
PASSWORD_RESET_EXPIRY_MINUTES=10 # Password reset token expiry
OTP_EXPIRY_MINUTES=10           # OTP code expiry
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow TypeScript best practices
- Write tests for new features
- Follow the existing code style
- Update documentation for API changes
- Ensure all tests pass before submitting PR

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Troubleshooting

### Common Issues

#### "Cannot connect to MongoDB"
- Ensure MongoDB is running
- Check MONGODB_URI in environment variables
- Verify network connectivity

#### "JWT token invalid"
- Check JWT secrets match between requests
- Verify token expiration settings
- Ensure clock synchronization

#### "OAuth callback error"
- Verify redirect URIs in OAuth provider settings
- Check client ID and secret configuration
- Ensure HTTPS in production

#### "Email not sending"
- Verify SMTP credentials
- Check firewall/security group settings
- Enable "Less secure app access" for Gmail (use App Passwords instead)

### Getting Help

- 📖 Check the [documentation](docs/)
- 🐛 Report bugs in [Issues](https://github.com/your-username/auth-system/issues)
- 💬 Ask questions in [Discussions](https://github.com/your-username/auth-system/discussions)

## 🏆 Credits

- UI Design inspired by modern glassmorphism trends
- Icons from [React Icons](https://react-icons.github.io/react-icons/)
- Animations powered by [Framer Motion](https://www.framer.com/motion/)

---

**Built with ❤️ using modern web technologies**

[⬆ Back to top](#-production-ready-authentication-system)